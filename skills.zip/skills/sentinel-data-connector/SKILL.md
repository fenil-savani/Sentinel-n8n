---
name: sentinel-data-connector
description: Build and fix Azure Sentinel data connectors per the team's development
  checklist — Python 3.12 upgrade, Log Ingestion API migration (HTTP Data Collector API EOL
  2026-09-14), reserved-keyword rename, ARM template params, Gov Cloud support, Managed
  Identity Key Vault, host.json bundle, checkpoint table storage, 9:30 timer stop, custom
  exceptions + status-code retry policy, User-Agent header, log format, 30MB/30KB ingestion
  limits, failed-data table, and the zip-update publishing matrix. Use when an MCP check
  (check_data_connector, check_arm_ttk) fails, or when building/repairing a connector, ARM
  template, or UI page.
---

# sentinel-data-connector

Build/fix data connectors per the team development checklist. Reference connector:
**Tenable VM** — https://github.com/Azure/Azure-Sentinel/tree/master/Solutions/Tenable%20App/Data%20Connectors/TenableVM

## Verify first (MCP)
`run_one_check("check_data_connector", <solution>)` and `run_one_check("check_arm_ttk", <solution>)`.

## Live test on Azure (dev loop)
Deploy & test against the workspace, then fix→redeploy→re-test (full loop: **sentinel-azure-devtest**):
`deploy_arm_template(template_path=<connector mainTemplate.json>, parameters={...}, mode="validate"→"create")`
→ `get_functionapp_status(name)` → `verify_table_ingestion(<Table>_CL)` / `get_connector_data(<Table>_CL)`.
Diagnose failures with `get_functionapp_traces(app_name=..., severity_min=3)` and
`get_functionapp_traces(contains="checkpoint")` (timeout/checkpoint logic). Fix here → redeploy → re-test.

### Trace-driven debugging recipe (deploy → run → find root cause → fix)
1. **Get the real Function App name** from the deployment — it's the `outputResources` id containing
   `/providers/Microsoft.Web/sites/<name>` (the template suffixes `FunctionName` with a uniqueString,
   so it's e.g. `vectra2jkr5tzdxiwik`, NOT just "Vectra"). `deploy_arm_template` now returns it as `function_apps`.
2. **Confirm it's running:** `get_functionapp_status(<name>)` → `state: Running`, `python|3.12`.
3. **Read the errors** (App Insights → workspace tables): query `AppExceptions` and `AppTraces | where SeverityLevel>=3`
   filtered by `AppRoleName has '<name>'`. "Running fine" but every function failing is normal — find the **inner
   exception**, usually thrown at `validate_connection()` before any data fetch (look for the Python traceback +
   `python exited with code 1`).
4. **Fix the root cause** (table below), **redeploy or restart** the Function App, then re-query traces to confirm clear.

### Common live deploy/runtime errors → fix
| Symptom (in traces / deploy) | Root cause | Fix |
|---|---|---|
| `Forbidden … does not have secrets list permission on key vault '<vault>'` at `load_tokens_from_keyvault` | The connector's identity (app registration `AzureClientID`/`AzureEntraObjectID`, **or** the Function App managed identity) lacks secret access on the vault it reads tokens from | Grant **get + list** secrets: RBAC `az role assignment create --assignee <objectId> --role "Key Vault Secrets User" --scope $(az keyvault show -n <vault> --query id -o tsv)`; or access policy `az keyvault set-policy -n <vault> --object-id <objectId> --secret-permissions get list`. Also confirm the vault actually holds the expected token secrets. |
| `python exited with code 1` on every function | A startup exception (often `validate_connection`) | Open `AppExceptions`/`AppTraces` for the inner traceback — fix that underlying error, not the exit code. |
| Deploy: `InvalidResourceLocation '[resourceGroup().location]'` | A param **value** is a literal ARM expression | Drop the `Location` param (use the template default) or set a real region (`"eastus"`). |

---

## 1. Python version → latest (currently 3.12)
1. Update/test Python packages on a **Linux VM** with Python 3.12 (Functions run on Linux).
2. Set the version in the **ARM template**: `"PYTHON_VERSION": "3.12"` and `"linuxFxVersion": "Python|3.12"`.
3. **Test the upgrade scenario** if updating an existing zip (see §13 publishing matrix).
4. Set the Python version in **Function App settings** too.

## 2. Log Ingestion API support (replace HTTP Data Collector API)
> **HTTP Data Collector API EOL: 2026-09-14** — https://learn.microsoft.com/en-us/previous-versions/azure/azure-monitor/logs/data-collector-api
If the connector still uses it, migrate (reach out to the client if adding support is required):
- Switch code to the **Log Ingestion API Python SDK** (drop `hmac`/`workspace_key`):
```python
from azure.monitor.ingestion import LogsIngestionClient
from azure.identity import ClientSecretCredential
creds = ClientSecretCredential(tenant_id=AZURE_TENANT_ID, client_id=AZURE_CLIENT_ID, client_secret=AZURE_CLIENT_SECRET)
client = LogsIngestionClient(endpoint=AZURE_DATA_COLLECTION_ENDPOINT, credential=creds)
client.upload(rule_id=DCR_RULE_ID, stream_name=DCR_STREAM_NAME, logs=data)
```
- Add the related ARM components (DCE + DCR — see §4).
- **Prepare the table schema** from API response + API docs + previously-ingested data. Automation helper: https://drive.google.com/file/d/19O_nVjIIvCUyezFvDc7tIpgTEiWbYNMR/view
- Update `requirements.txt` with pinned SDKs:
```
azure-monitor-ingestion
azure-identity
```
- **Reserved keywords** `type`, `time`, `title` — rename in `transformKql` and use the renamed key in the table. You may keep the reserved key in the DCR schema but rename it:
```kql
| project-rename DetectionType = ['type']
| project-rename EventTime = ['time']
| project-rename EventTitle = ['title']
```
- **Update everywhere the tables are used**: parsers, dashboards/workbooks, analytic rules, playbooks.
- Update the **Data Connector UI page**: parameter details + an "App registration" section for obtaining client id, client secret, and the **Entra object ID**.
- Update the **installation and usage guide**.

## 3. ARM template parameters
- Remove `WorkspaceId` and `WorkspaceKey`; add **WorkspaceName** and **WorkspaceLocation**.
- Add a **TableName** parameter with a max-length constraint of **52** (`"maxLength": 52`).
- All secrets `"type": "secureString"`; no hardcoded credentials.

## 4. ARM resources (DCE + DCR)
Add a Data Collection Endpoint and a Data Collection Rule with `streamDeclarations`,
`destinations.logAnalytics`, and `dataFlows` (`transformKql`, `outputStream`
`Custom-<TableName>_CL`). Grant the function app's managed identity **Monitoring Metrics
Publisher** (`3913510d-42f4-4e42-8a64-420c390055eb`) on the DCR.

## 5. Azure Gov Cloud support
**HTTP Data Collector API:** use `.us` instead of `.com` in the Log Analytics URI; derive from the ARM **Scope** variable.
**Log Ingestion API:** use the scope to pick the Government authority:
```python
if ".us" in scope:
    creds = ClientSecretCredential(
        client_id=AZURE_CLIENT_ID, client_secret=AZURE_CLIENT_SECRET,
        tenant_id=AZURE_TENANT_ID, authority=AzureAuthorityHosts.AZURE_GOVERNMENT)
else:
    creds = ClientSecretCredential(
        client_id=AZURE_CLIENT_ID, client_secret=AZURE_CLIENT_SECRET, tenant_id=AZURE_TENANT_ID)
azure_client = LogsIngestionClient(azure_data_collection_endpoint, credential=creds, credential_scopes=[scope])
ms_sentinel_obj = MicrosoftSentinel(azure_client)
ms_sentinel_obj.post_data(sub_chunk, log_type, dcr_rule_id)
```
- Add a **Deploy to Azure Gov Cloud** button in the UI page with a **separate shortened URL**.
- Reference: Tenable VM (link above).

## 6. Managed Identity for Key Vault
- Prefer Key Vault via **Managed Identity** (no App registration steps needed).
  Reference: https://github.com/Azure/Azure-Sentinel/blob/master/Solutions/Vectra%20XDR/Data%20Connectors/VectraDataConnector/SharedCode/keyvault_secrets_management.py
- In the guide (Azure portal), instruct adding the **function app object ID** in the Key Vault access (instead of the Entra app id used for app registration).

## 7. Gov Cloud support for Key Vault
Via the scope parameter, detect `.us` and use `vault.usgovcloudapi.net` instead of `vault.azure.net`.
Reference: https://learn.microsoft.com/en-us/azure/azure-government/compare-azure-government-global-azure

## 8. host.json bundle version
Ensure the Functions extension bundle is current: `"[4.*, 5.0.0)"`.

## 9. Checkpoint storage logic
Prefer **Azure Table Storage** over file checkpoints (avoids file-corruption issues).
Reference: https://github.com/Azure/Azure-Sentinel/tree/master/Solutions/Armis
Order: **ingest first, store checkpoint only after success** (prevents data loss/duplication).

## 10. Logging & observability
- Add a `User-Agent` header in **every** API call (identifies platform + version calling which API).
- **No sensitive information** in logs.
- Large/verbose logs that should not surface to end users → log at **DEBUG** level.
- The Data Connector UI page must have the **correct table name and status query** so the
  connector shows **Connected** (`IsConnectedQuery` / `lastDataReceivedQuery` on `<Table>_CL`).
- **Consistent log format** — every log line starts with: `{Data Connector Name} {Method Name}`.

## 11. Connector code quality
- **Modularized** code structure (split into focused modules, not a monolith).
- **Timer-trigger 9:30 stop:** Azure timer functions auto-timeout at 10 min — force-stop at **9:30 (570s)**.
  Check the timeout condition in **every for/while loop**, and store checkpoints correctly when stopping (avoid duplication).
```python
MAX_EXECUTION_SECONDS = 570  # 9.5 min
start_time = time.time()
def is_timeout_approaching(): return (time.time() - start_time) >= MAX_EXECUTION_SECONDS
for record in records:
    if is_timeout_approaching(): save_checkpoint(last_processed_id); break
    process_record(record)
```
- **Failed-data handling:** if needed, store ingestion-failed data in a separate custom table.
- **Exceptions & status codes** — no general exceptions; always **custom exceptions** (multiple classes per use case). Always handle: `TimeoutError`, `JSONDecodeError`, `ConnectionError`, `RequestException`.
  Status-code policy (tune per API/SDK docs):
  - Handle **400, 401, 403, 404, 409, 429, 500**.
  - **Retry** on **401** (≈4 retries) and **429, 500** (with backoff).
  - **Raise** on **400, 403, 404, 409**.
- **Ingestion limits:** MS Sentinel max **30 MB per API call**; HTTP Collector API max **30 KB per column**. Chunk accordingly:
```python
MAX_PAYLOAD_BYTES = 30 * 1024 * 1024
def chunk_data(data, max_size_bytes=MAX_PAYLOAD_BYTES):
    chunks, current, size = [], [], 0
    for r in data:
        rs = len(str(r).encode("utf-8"))
        if size + rs > max_size_bytes:
            if current: chunks.append(current)
            current, size = [r], rs
        else: current.append(r); size += rs
    if current: chunks.append(current)
    return chunks
```
- Verify **grammar** across the code; **sonar** and **flake8** checks pass; every function has **comments + docstring**.

## 12. Connector UI page details
- Correct `id`/`title` (append "(using Azure Functions)"), `descriptionMarkdown`, `permissions`
  (read/write/delete on `Microsoft.OperationalInsights/workspaces`), App Registration steps
  (client id, secret, Entra object id), CopyableLabel for Workspace ID, table name ≤52.
- Both deploy buttons (`aka.ms` shortened URLs, configured by MS after merge):
```json
{"parameters": {"linkType": "OpenDeploymentBlade", "buttonText": "Deploy to Azure", "linkUri": "https://aka.ms/sentinel-<SolutionName>-azuredeploy"}, "type": "InstallAgent"},
{"parameters": {"linkType": "OpenDeploymentBlade", "buttonText": "Deploy to Azure Government", "linkUri": "https://aka.ms/sentinel-<SolutionName>-azuredeploy-gov"}, "type": "InstallAgent"}
```

## 13. Zip-update publishing matrix
Every zip must contain the **Python packages and all required folders/files** for each component.

| Scenario | Client publishing steps? | Required actions |
|---|---|---|
| **Update existing** data connector zip (no UI-page change) | **No** | Changes must be **non-breaking** (auto-updates for existing users). Run the **upgrade test**: take the existing solution from GitHub, swap in the updated zip — no issues. |
| **New** data connector zip (no UI-page change) | **No** | Add a **new shortened URL** in `WEBSITE_RUN_FROM_PACKAGE` (ARM). End users must **re-configure** the connector to see updates. |
| **New/updated zip + Data Connector UI page change** | **Yes** | Add a new shortened URL (if new zip). End users must **install the latest solution from Content Hub** and reconfigure. Create a **new package zip with bumped version** and follow all new-package-version steps. |

## 14. Link-mapping verification (post-merge)
Whenever any link changes — `WEBSITE_RUN_FROM_PACKAGE` in ARM, or the Deploy to
Azure / Azure Gov buttons in the UI page — after the PR is merged, confirm the
**Microsoft team mapped the shortened URL correctly**; if not, reach out to them.
