---
name: sentinel-azure-devtest
description: Iterative Azure dev+test loop for Sentinel artifacts — deploy to a live workspace,
  run real tests, verify results, and on failure diagnose → fix the code → redeploy → re-test
  until it passes. Drives the sentinel-pr-review MCP Azure tools (deploy_arm_template,
  create_scheduled_rule, trigger_playbook, preview_rule_query, get_functionapp_traces,
  test_asim_schema/data, get_connector_data, list_incidents, get_playbook_runs, run_kql_query…).
  Use for live development/testing of data connectors, parsers, ASIM parsers, analytic rules,
  playbooks, and workbooks against Azure. Trigger: "test on azure", "deploy and verify",
  "dev test loop", "create the rule and check incidents".
---

# sentinel-azure-devtest

The live loop: **CREATE/DEPLOY → TEST → VERIFY → (fail) DIAGNOSE → FIX → REDEPLOY → re-test**.
Requires `az login` + the configured target (AZURE_SUBSCRIPTION_ID / AZURE_RESOURCE_GROUP / SENTINEL_WORKSPACE_NAME). All tools are MCP tools.

## The loop
1. **CREATE / DEPLOY** the artifact to the workspace.
   - `deploy_arm_template(..., mode="validate")` → then `mode="create"` (safe-first).
   - Analytic rule shortcut: `create_scheduled_rule(...)`.
2. **TEST** — exercise it live (table below).
3. **VERIFY** — check the expected outcome (rows present? run Succeeded? incident created? schema passes?).
4. **On FAILURE → DIAGNOSE** (traces / run history / query error), **FIX** the code via the domain skill, **REDEPLOY**, and go back to step 2.
5. Repeat until VERIFY passes. Remove throwaway test artifacts when done.

## Per-artifact recipes

### Data connector
- Deploy: `deploy_arm_template(template_path=<connector mainTemplate.json>, parameters_file=<params with secrets>, mode="validate"→"create")`. Secrets go in `parameters_file` (Key Vault reference preferred), never inline.
- **Get the real Function App name** from the deploy result `function_apps` (or the `outputResources` `/sites/` id) — templates suffix `FunctionName` uniquely (e.g. `vectra2jkr5tzdxiwik`), so don't assume the param value.
- Test/verify: `get_functionapp_status(name)` (Running?) → `get_connector_data(table)` / `verify_table_ingestion(table)`.
- Diagnose: `get_functionapp_traces(app_name=<name>, severity_min=3)` and check `AppExceptions`. "Running but every function failing" is common — find the **inner exception**, usually at `validate_connection()` (e.g. Key Vault `Forbidden … secrets list permission` ⇒ grant the app/MI `get`+`list` on the vault). See sentinel-data-connector "Common live deploy/runtime errors → fix".
- Fix → **sentinel-data-connector** → rebuild zip / update ARM / grant permission → redeploy or restart → re-check traces.

### Custom parser
- Deploy: parser function deployed with the solution (or saved-search). 
- Test/verify: `test_parser(parser_name, limit)` → rows with expected typed columns; `run_kql_query` for edge cases.
- Diagnose: KQL error in result → missing `column_ifexists` / schema mismatch / no `union` empty table.
- Fix → **sentinel-custom-parser** → redeploy → re-test.

### ASIM parser
- Test/verify: `test_asim_schema(parser, schema)` (all mandatory fields) → `test_asim_data(parser, schema)` (types/enums).
- Diagnose: tester rows list the failing field/check.
- Fix → **sentinel-asim-parser** → redeploy → re-run testers.

### Analytic rule (→ incident)
- Create: `create_scheduled_rule(display_name, query, create_incident=True, enabled=True, ...)`.
- Verify config: `rule_creates_incident(rule_id)` → `createsIncident: true`.
- Verify it would fire: `preview_rule_query(rule_id)` → rows ⇒ will trigger.
- Verify actual incidents (after the rule's `queryFrequency` run): `list_incidents()` / `get_incident_count()`.
- Fix → **sentinel-analytics-rules** (query/threshold/createIncident) → recreate → re-verify.
- NOTE: enabling ≠ instant incident; it runs on schedule. `preview_rule_query` is the instant signal.

### Playbook (Logic App)
- Deploy: `deploy_arm_template(template_path=<azuredeploy.json>, parameters={PlaybookName:...}, mode=create)`.
- Verify exists: `list_playbooks()` / `get_playbook(name)`.
- Test: `trigger_playbook(name, trigger_name="manual", body={...})`.
- Verify result: `get_playbook_runs(name)` → status Succeeded / error message.
- Diagnose: run error + `get_functionapp_traces` if it calls the connector. Common: **unauthorized API connections** (authorize once in portal).
- Fix → **sentinel-playbook** → redeploy → re-trigger.

### Workbook
- Deploy: `deploy_arm_template(... workbook ARM ...)`; confirm `list_workbooks()`.
- Test/verify: run each panel's KQL via `get_workbook_data(query)` → returns data, no error, within 10k-row/100-series limits.
- Fix → **sentinel-workbook** → redeploy. Visual checks (centering/legends/drill-down/preview PNGs) are portal-only.

## Cross-cutting tools
- `run_kql_query` / `export_kql_query` — ad-hoc validation; download sample data (CSV/JSON) for parser/schema work.
- `verify_connector_status`, `list_data_connectors`, `list_analytic_rules`, `list_incidents`.

## Safety
- Deploys default to `validate`; pass `mode="create"` to actually deploy.
- `create_scheduled_rule` and `trigger_playbook` are MUTATING and **disabled by default** — confirm with the user, then set `SENTINEL_ALLOW_MUTATIONS=1` in the MCP env. `create_scheduled_rule` also refuses to silently overwrite an existing rule at the deterministic id; pass an explicit `rule_id` to confirm the target. Name test artifacts clearly (e.g. `Test - …`) and clean them up after.
- `template_uri` is restricted to Azure-Sentinel raw GitHub unless `SENTINEL_ALLOW_REMOTE_TEMPLATES=1`; `template_path` must live under the configured repo / solutions root.
- `run_kql_query` / `get_workbook_data` / `export_kql_query` block remote-fetch KQL operators (`externaldata`, `http_request`) unless `SENTINEL_ALLOW_REMOTE_KQL=1`. `export_kql_query` writes only inside the cache `exports/` dir (filename is reduced to a safe basename).
- Solution **Package** templates need `workspace=<name>` + `workspace-location` params and deploy into the workspace's resource group.
- **Deploy param gotchas** (validate catches these fast): extra params not in the template → `InvalidTemplate`; a param whose *value* is an ARM expression like `[resourceGroup().location]` → `InvalidResourceLocation` (use a real region or drop it); a typo'd resource-id (RG/workspace) → "resource group … does not exist" / `LinkedAuthorizationFailed`; missing required param. Always `mode="validate"` first.
- **Secrets:** pass via `parameters_file` (Key Vault reference best); never inline `parameters` (exposed on CLI/transcript). Rotate any secret that leaks into logs/chat. Any vault referenced via a KV reference **must** have `enabledForTemplateDeployment=true` — `deploy_arm_template` strictly enforces this and blocks the deploy otherwise (Portal: Access configuration → "Azure Resource Manager for template deployment"; or `az keyvault update -n <vault> --enabled-for-template-deployment true`). KV references are **per-parameter** (one secret → one param), so a single whole-params-blob secret can't be referenced — split secret params into individual vault secrets, or fetch the blob locally without printing values + delete after.
