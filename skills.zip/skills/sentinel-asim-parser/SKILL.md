---
name: sentinel-asim-parser
description: Build and fix Azure Sentinel ASIM (Advanced SIEM Information Model) normalized
  parsers — the 3-level hierarchy (ASim<Schema> union · im<Schema> filtering · vim<Schema><Vendor>
  vendor filtering) under ASIM/ and repo-root Parsers/ASim*. Covers YAML keys (Parser.Title/
  Version/LastUpdated, Product, Normalization.Schema/Version, ParserName, EquivalentBuiltInParser,
  ParserParams, ParserQuery, Parsers list), the standard normalization fields (EventVendor/
  EventProduct/EventSchema/EventSchemaVersion), filtering parameters, field aliases, naming
  conventions, schema list, and ASimSchemaTester/ASimDataTester validation. Use for ASIM
  parsers; for single-vendor solution parsers use sentinel-custom-parser instead.
---

# sentinel-asim-parser

ASIM normalized parsers — multi-vendor, schema-normalized, parameterized, with filtering.
Located under `ASIM/` (schemas, testers) and repo-root `Parsers/ASim<Schema>/`.

> For single-vendor **custom** parsers under `Solutions/<Name>/Parsers`, use
> **sentinel-custom-parser** — different YAML and query model.

## Verify first (MCP)
- `run_local_validation(path="Parsers/ASim<Schema>")` — official harness, all TS validators (fast). .NET
  (kql/detection/non-ascii) run automatically now (the MCP puts `dotnet` on PATH). It runs repo-wide and
  **can't scope KQL to your files**, so ignore failures whose Template Id isn't your parser — many are
  local-engine false positives (missing schema cache).
- `run_one_check("check_asim_parser", <solution>)` — offline structure (requires `ParserName` + `EquivalentBuiltInParser`).
- `check_asim_sample_data(parser_path="Parsers/ASim<Schema>")` — **run this every ASIM PR** (offline, ~1s).

## CI failure playbook (the two that bite ASIM PRs)
These are the checks `run_all_checks` doesn't fully reproduce; reproduce/prevent them with:

1. **"Run ASim Template Validation" fails → sample-data file naming.** The CI tester expects each vendor
   parser's sample data at `Sample Data/ASIM/{EventVendor}_{EventProduct}_{Schema}_IngestedLogs.csv`
   (vendor + product spelled with their real spaces, e.g. `Google_Google Threat Intelligence_AlertEvent_IngestedLogs.csv`).
   A name like `GoogleThreatIntelligence_AlertEvent_IngestedLogs.csv` (missing vendor prefix) fails.
   - **Detect offline:** `check_asim_sample_data(...)` — derives the expected name from the parser's
     `EventVendor`/`EventProduct`/`EventSchema` and checks the file exists.
   - **Fix:** rename the CSV to the expected name (`git mv`). The full CI script is network/commit-coupled
     (`run_asim_template_test` needs an `upstream` remote + a pushed commit + `pip install requests pyyaml tabulate`).

2. **"KqlValidations" fails → custom source table has no registered schema.** CI scopes KQL to your PR files;
   if a parser reads a custom table (e.g. `RelevanceSystemAlerts_CL`) that has no schema under
   `.script/tests/KqlvalidationsTests/CustomTables/<table>.json`, the KQL validator can't resolve its columns.
   - **Fix (automated):** `generate_custom_table_schema("<Table>_CL")` — pulls the live `getschema` from the
     workspace and writes the CustomTables JSON. (Siblings like `SentinelOne_CL.json` confirm the pattern.)
   - Then re-run KQL; your parser's Template Id should no longer appear in the failures.

## Live test on Azure (dev loop)
Deploy the parser, then run the ASIM testers: `test_asim_schema(parser_name, schema)` (all mandatory
fields/types) → `test_asim_data(parser_name, schema)` (enums/values on recent data). The tester rows name
the failing field/check → fix here → redeploy → re-run the testers. Full loop: **sentinel-azure-devtest**.

## The 3-level hierarchy (per schema)
| Level | Prefix | Role | EquivalentBuiltInParser |
|---|---|---|---|
| Union | `ASim<Schema>` | unions all vendor normalizers (full results) | `_ASim_<Schema>` |
| Filtering (unified) | `im<Schema>` | unions all `vim` vendor filtering parsers, takes filter params | `_Im_<Schema>` |
| Vendor filtering | `vim<Schema><Vendor>` | one source, pre/post filtering + normalization | `_Im_<Schema>_<Vendor>` |
| Vendor normalizer | `ASim<Schema><Vendor>` | one source, full normalization (no filter params) | `_ASim_<Schema>_<Vendor>` |

Folder layout: `Parsers/ASim<Schema>/Parsers/*.yaml` + `ARM/`, `Tests/`, `CHANGELOG`, `README.md`.
Schemas: Authentication, AuditEvent, DhcpEvent, Dns, FileEvent, NetworkSession, ProcessEvent,
RegistryEvent, UserManagement, WebSession (+ curated: AlertEvent, AssetEntity, etc.).

## YAML structure
### Vendor filtering parser — `vim<Schema><Vendor>.yaml`
```yaml
Parser:
  Title: DNS activity ASIM filtering parser for <Vendor>
  Version: "0.4.0"
  LastUpdated: <Mon DD, YYYY>
Product:
  Name: <Vendor Product>
Normalization:
  Schema: Dns
  Version: "0.1.7"
References:
  - Title: ASIM DNS Schema
    Link: https://aka.ms/ASimDnsDoc
  - Title: ASIM
    Link: https://aka.ms/AboutASIM
ParserName: vimDns<Vendor>
EquivalentBuiltInParser: _Im_Dns_<Vendor>
ParserParams:                     # filtering params — schema-specific set
  - { Name: starttime, Type: datetime, Default: 'datetime(null)' }
  - { Name: endtime,   Type: datetime, Default: 'datetime(null)' }
  - { Name: srcipaddr, Type: string,   Default: '*' }
  - { Name: domain_has_any, Type: dynamic, Default: 'dynamic([])' }
  - { Name: responsecodename, Type: string, Default: '*' }
  - { Name: eventtype, Type: string, Default: 'Query' }
  - { Name: disabled,  Type: bool,   Default: 'false' }
ParserQuery: |
  let parser=(starttime:datetime=datetime(null), endtime:datetime=datetime(null),
              srcipaddr:string='*', /* ... */ disabled:bool=false) {
    <SourceTable>
    | where not(disabled)
    // pre-filtering (cheap, pre-parse): time, ip, domain_has_any
    | where (isnull(starttime) or TimeGenerated >= starttime)
    | where (isnull(endtime)   or TimeGenerated <= endtime)
    | where (srcipaddr=='*' or has_ipv4(msg_s, srcipaddr))
    | parse msg_s with "..." SrcIpAddr:string ":" SrcPortNumber:int " - " /* ... */
    // post-filtering (now fields exist)
    | where (responsecodename=='*' or DnsResponseCodeName has responsecodename)
    | extend
        EventVendor = "<Vendor>",
        EventProduct = "<Product>",
        EventSchema = "Dns",
        EventSchemaVersion = "0.1.7",
        EventCount = int(1),
        EventStartTime = TimeGenerated,
        EventType = 'Query'
    | extend                       // backward-compat aliases
        Domain = DnsQuery, Src = SrcIpAddr, IpAddr = SrcIpAddr, Dvc = DvcId
  };
  parser(starttime, endtime, srcipaddr, /* ... */ disabled)
```
### Unified filtering parser — `im<Schema>.yaml`
`ParserName: im<Schema>`, `EquivalentBuiltInParser: _Im_<Schema>`, same `ParserParams`, and a
`ParserQuery` that unions every `vim<Schema><Vendor>(params)` plus the empty placeholder, then
calls `Generic(...)`. Include a `Parsers:` list of the `_Im_<Schema>_<Vendor>` references.
### Union parser — `ASim<Schema>.yaml`
`ParserName: ASim<Schema>`, `EquivalentBuiltInParser: _ASim_<Schema>`, `ParserParams` usually just
`pack` (bool), and a `ParserQuery` doing `union isfuzzy=true vimDnsEmpty, ASimDns<Vendor>(...), ...`.
Include a `Parsers:` list of `_ASim_<Schema>_<Vendor>` references.

## Required normalization fields (every vendor parser)
`EventVendor`, `EventProduct`, `EventSchema`, `EventSchemaVersion`, `EventCount`,
`EventStartTime`/`EventEndTime`, `EventType`, plus the schema's mandatory fields. Set
`EventSchemaVersion` to the exact `Normalization.Version`. Add the **alias** block for backward
compatibility (e.g. `Src`, `Dst`, `Dvc`, `Domain`, `IpAddr`).

## Conventions & rules
- **Naming**: `ASim<Schema>` / `im<Schema>` / `vim<Schema><Vendor>` / `ASim<Schema><Vendor>`;
  `EquivalentBuiltInParser` = `_ASim_<Schema>[_<Vendor>]` or `_Im_<Schema>[_<Vendor>]`.
- **Versions**: bump `Parser.Version` on change; `Normalization.Version` matches the schema you target.
- **`disabled` param** + empty placeholder parser (`vim<Schema>Empty`) so sources can be turned off via the `ASimDisabledParsers` watchlist.
- **Filtering parameters** must actually filter (push predicates before `parse`/`extend` where possible).
- Schema definitions live in `ASIM/schemas/` (`Class: Mandatory/Recommended/Optional`); align field names/types exactly.

## Adding a new vendor parser to the schema (union parser update checklist)
When a new `ASim<Schema><Vendor>.yaml` + `vim<Schema><Vendor>.yaml` pair is added, **both** union
parsers under `Parsers/ASim<Schema>/Parsers/` must be updated or CI test 3 & 4 will fail
("Parser entry not found in union parser under ParserQuery/Parsers property").

### `ASim<Schema>.yaml` (union, no filter params)
1. Add `_ASim_<Schema>_<Vendor>` to the `Parsers:` list.
2. Add a line to `ParserQuery` union block:
   ```
   ASimAlertEvent<Vendor> (disabled=(ASimBuiltInDisabled or ('ExcludeASimAlertEvent<Vendor>' in (DisabledParsers))))
   ```
   Add `, pack=pack` if the vendor ASim parser accepts `pack`.
3. Bump `Parser.Version` (patch) and update `LastUpdated`.

### `im<Schema>.yaml` (filtering union, all filter params)
1. Add `_Im_<Schema>_<Vendor>` to the `Parsers:` list.
2. Add a line to `ParserQuery` union block passing **all** filter params:
   ```
   vim<Schema><Vendor> (starttime=starttime, endtime=endtime, ipaddr_has_any_prefix=ipaddr_has_any_prefix,
     hostname_has_any=hostname_has_any, username_has_any=username_has_any,
     attacktactics_has_any=attacktactics_has_any, attacktechniques_has_any=attacktechniques_has_any,
     threatcategory_has_any=threatcategory_has_any, alertverdict_has_any=alertverdict_has_any,
     eventseverity_has_any=eventseverity_has_any,
     disabled=(vimBuiltInDisabled or ('ExcludevimAlertEvent<Vendor>' in (DisabledParsers))))
   ```
   Add `, pack=pack` if the vim parser accepts `pack`. Omit params the vendor parser doesn't support
   (but keep them in the signature — they're just unused inside the vendor parser).
3. Bump `Parser.Version` (patch) and update `LastUpdated`.

### Changelogs — update both
Both `CHANGELOG/ASim<Schema>.md` **and** `CHANGELOG/im<Schema>.md` need a new version entry at the top:
```markdown
## Version <new-version>

- (<YYYY-MM-DD>) Included <Vendor> <Product> alerts in results - [PR #](https://github.com/Azure/Azure-Sentinel/pull/)
```
Leave the PR number blank (just `#`) — fill it in once the PR is opened. The CHANGELOG folder also
contains per-vendor changelogs (e.g. `ASimAlertEvent<Vendor>.md`, `vimAlertEvent<Vendor>.md`) — those
are updated separately when the vendor parser itself changes, not when it's added to the union parser.

> **CI test names that catch this:** "Parser entry not found in union parser under ParserQuery property"
> (test 3) and "Parser entry not found in union parser under Parsers property" (test 4) from
> `VerifyASimParserTemplate.py`. Both must pass before merging.

## Validation
- **Offline (MCP)**: `check_asim_parser` enforces presence of `ParserName` + `EquivalentBuiltInParser`.
- **Live (workspace)**: deploy the parser, then run the ASIM testers via the MCP live tools:
  `run_kql_query("<parser> | getschema | invoke ASimSchemaTester('<Schema>')")` and
  `run_kql_query("<parser> | where TimeGenerated >= ago(30m) | invoke ASimDataTester('<Schema>')")`.
  Testers + schema CSV: `ASIM/dev/ASimTester/` (`ASimSchemaTester.json`, `ASimDataTester.json`, `ASimTester.csv`).
- Add per-schema tests under `Parsers/ASim<Schema>/Tests/`; exclusions in `ASIM/dev/ASimTester/ExclusionListForASimTests.csv`.
