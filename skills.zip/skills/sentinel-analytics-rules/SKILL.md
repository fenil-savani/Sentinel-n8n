---
name: sentinel-analytics-rules
description: Fix Azure Sentinel analytic (detection) rule issues — rule YAML structure,
  UUID that must never change after creation, MITRE tactics/techniques format,
  requiredDataConnectors/connectorId/dataTypes, severity, query trigger thresholds and KQL
  hygiene, ARM template generation, and ValidConnectorIds.json. Use when an MCP check
  (check_analytic_rules, check_analytic_id, check_kql) fails or when authoring a detection rule.
---

# sentinel-analytics-rules

Remediation for analytic/detection rules.

## Verify first (MCP)
Run `run_one_check("check_analytic_rules", <solution>)` (scoped, fast — schema + connector-id)
and `run_one_check("check_analytic_id", <solution>)` (UUID-change guard). Deep KQL:
`run_one_check("check_kql", <solution>)`.

Also run `check_detection_version_bumped()` — modified `Detections/`/`Analytic Rules/` YAMLs must bump
`version:` (mirrors the CI "check that the version was updated" check); never change the `id`.

## Live test on Azure (dev loop)
Create & verify a rule against the workspace (full loop: **sentinel-azure-devtest**):
`create_scheduled_rule(display_name, query, create_incident=True, enabled=True, query_frequency, ...)`
→ `rule_creates_incident(rule_id)` (confirm `createsIncident: true`)
→ `preview_rule_query(rule_id)` (rows ⇒ it would fire NOW)
→ after the `queryFrequency` run: `list_incidents()` / `get_incident_count()` (incidents actually created).
Enabling ≠ instant incident — it runs on schedule; `preview_rule_query` is the instant signal. Fix the
query/threshold/`create_incident` here → recreate → re-verify. Or deploy the solution's rule ARM via
`deploy_arm_template`.

## Team analytics-rule checklist
1. **Tactics & Techniques present** in the template (`tactics:` + `techniques:` with valid values).
2. **requiredDataConnectors + connectorId present** in the template (with matching `dataTypes`).
3. **Query works** — validate by actually running it (`run_kql_query("<the rule query>")` against the
   workspace, or paste into the Logs blade) so it returns without error and produces expected columns.
4. **No static URLs/credentials in mainTemplate** — use parameters/variables.

## Common CI failures → fix
**Detection Validations — "Id of file … has changed"** — e.g. *"Found <uuid-A> and <uuid-B>. Error: Id
of file 'Solutions/.../Analytic Rules/<Rule>.yaml' has changed, please make sure you do not change any
file id."*
Cause: the rule's `id` (UUID) was modified instead of (or along with) the `version`.
Fix: **revert the `id` to its original UUID** (recover via `git log --follow -p <file>` or `git show
<base>:<path>`) and instead **bump the `version`**. The UUID is permanent once published; only `version`
changes. This is what the MCP `check_analytic_id` guards.

## Analytics rule fixes
### Rule YAML template — `Analytic Rules/<RuleName>.yaml`
```yaml
id: <new-uuid>            # python -c "import uuid; print(uuid.uuid4())" — NEVER change
name: <Descriptive Detection Name>
description: |
  Detects <threat/behavior> in <data source>. Fires when <condition>, indicating <scenario>.
severity: Medium          # Low | Medium | High | Informational
status: Available
requiredDataConnectors:
  - connectorId: <ConnectorId>     # from the connector UI page / Data Connectors/<x>.json id
    dataTypes: [ <TableName>_CL ]
queryFrequency: 1h
queryPeriod: 1h
triggerOperator: gt
triggerThreshold: 0
tactics: [ InitialAccess ]          # real MITRE tactics that apply
techniques: [ T1078 ]               # real MITRE technique IDs
query: |
  <TableName>_CL
  | where TimeGenerated > ago(1h)
  | where EventType == "Threat"
  | project TimeGenerated, SourceIp, DestinationIp, EventType, Severity
entityMappings:
  - entityType: IP
    fieldMappings: [ { identifier: Address, columnName: SourceIp } ]
version: 1.0.0
kind: Scheduled
```
### UUID — generate once, never change. The ARM template `contentId` must equal the YAML `id` (don't mint a new one).
### Severity — Informational / Low / Medium / High.
### MITRE format
```yaml
tactics: [ InitialAccess, Execution, Persistence, PrivilegeEscalation, DefenseEvasion,
           CredentialAccess, Discovery, LateralMovement, Collection, CommandAndControl,
           Exfiltration, Impact ]      # only those that apply
techniques: [ T1078, T1190, T1059.006 ]
```
Look up at https://attack.mitre.org.
### requiredDataConnectors — `connectorId` from `Data Connectors/<x>.json` `id`; table name matches connector's exactly (case-sensitive). No hardcoded values in query (use `isnotempty()`/watchlists); always end with explicit `project` (include `Type`); explicit `join kind=inner (...) on key`.
### ARM template — auto-generate via `Tools\Create-Azure-Sentinel-Solution\V3\createSolutionV3.ps1`, or:
```json
{ "type": "Microsoft.SecurityInsights/alertRules", "apiVersion": "2023-02-01",
  "name": "[concat(resourceGroup().id, '/providers/Microsoft.SecurityInsights/alertRules/', '<uuid-from-yaml>')]",
  "kind": "Scheduled",
  "properties": { "displayName": "<Rule Name>", "severity": "Medium", "enabled": true,
    "query": "<KQL>", "queryFrequency": "PT1H", "queryPeriod": "PT1H",
    "triggerOperator": "GreaterThan", "triggerThreshold": 0,
    "tactics": ["InitialAccess"], "techniques": ["T1078"] } }
```
Note: YAML `gt`/`1h` → ARM `GreaterThan`/`PT1H` (ISO-8601).
### ValidConnectorIds.json — if schema validation rejects the connector id, add it to
`.scripts/tests/detectiontemplateschemavalidation/ValidConnectorIds.json` (sorted, unique).
For a missing custom-table schema, create the schema file (see **sentinel-packaging**).
