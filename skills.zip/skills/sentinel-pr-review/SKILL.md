---
name: sentinel-pr-review
description: Orchestrator for reviewing an Azure Sentinel solution PR locally. Takes a
  solution name, runs the real Microsoft CI validations via the sentinel-pr-review MCP,
  reports PASS/FAIL per category, and routes each failure to the matching domain fix
  skill (sentinel-data-connector, sentinel-custom-parser, sentinel-asim-parser, sentinel-analytics-rules,
  sentinel-playbook, sentinel-workbook, sentinel-packaging, sentinel-process-ops).
  Optionally validates live data in the Sentinel workspace. Trigger: "review sentinel PR",
  "check this solution", "validate <SolutionName>".
---

# sentinel-pr-review (orchestrator)

Review an Azure Sentinel solution PR by running the real CI validators locally
(through the MCP) and turning every failure into an actionable fix.

## Input
- **Solution name** (required). If not in the prompt, ask for it.
- Flags: `--live` (also run workspace data checks), `--fix` (apply fixes after review).

## Tool-call etiquette (no "stuck" surprises) — REQUIRED
The MCP tools are `az`/validator-backed and run synchronously with **no progress output**, and the
**first call needs a permission prompt** — so always set expectations:
1. **Before each MCP call, say** which tool you're calling and the **expected duration**, e.g.
   *"Running `run_all_checks` (≈30–90s; .NET checks dominate)…"*. This is why a call can *look* frozen.
2. **First call may prompt for permission** — tell the user: if the `mcp__sentinel-pr-review__*` prompt
   appears, click **Allow** (or *Allow for session*); a denied prompt **stops** the call (it's not stuck).
   To avoid repeats they can allowlist the server in `/permissions` or settings.json.
3. **After each call, report its `duration_ms`** from the result (and the tool's timeout if it hit one —
   node checks 600s, .NET 2400s, deploys 1800s).
4. Prefer **`run_all_checks`** (one call) over many `run_one_check` calls to minimise prompts/waits.

**Rough durations** to quote: node checks ~5–20s (first includes a one-time `tsc` build); analytic-rule
schema ~40s; non-ASCII ~60s (repo-wide); `check_kql` **minutes** (slow, excluded by default); ARM-TTK
~10–30s; live/Azure tools ~5–15s (az cold start). If `run_all_checks` will take a while, say so up front.

## Workflow
1. **Bootstrap once** — call MCP `bootstrap` (compiles validators). If it warns about
   `npm ci`, tell the user to run it in the repo.
2. **Discover** — `detect_pr_scope(solution_name)`. Note `categories_present`.
   - **If `exists` is false:** the input isn't a `Solutions/<name>` solution. Before erroring, check if it's a
     **standalone ASIM parser** PR (name like `ASim<Schema>`, or changes under `Parsers/ASim*` / `ASIM/`) and if
     so use the **ASIM branch** below — do NOT run `run_all_checks` (the solution pipeline doesn't apply and
     would kick off slow repo-wide checks → looks "stuck"). Only if it's neither solution nor ASIM, stop and say so.

   **ASIM-only branch (no Solutions/ folder):** ASIM parsers live at repo-root `Parsers/ASim*` / `ASIM/`, not
   under `Solutions/`. Validate directly, then route fixes to **sentinel-asim-parser**:
   - **Primary:** `run_local_validation(path="Parsers/ASim<Schema>")` (e.g. `Parsers/ASimAlertEvent`) — official
     harness, ~2s, covers yaml/json/id-change/etc. natively.
   - Offline ASIM structure: `run_one_check("check_asim_parser", "<ASimSchema>")` (required-property check).
   - **Sample-data naming (catches the common "Run ASim Template Validation" CI fail):**
     `check_asim_sample_data(parser_path="Parsers/ASim<Schema>")` — offline, ~1s. Fix = rename CSV to
     `{EventVendor}_{EventProduct}_{Schema}_IngestedLogs.csv`.
   - **KqlValidations fail = missing custom-table schema:** if a parser reads `<Table>_CL`, ensure
     `.script/tests/KqlvalidationsTests/CustomTables/<Table>_CL.json` exists — generate it with the live tool
     `generate_custom_table_schema("<Table>_CL")`. See **sentinel-asim-parser** "CI failure playbook".
   - Live (workspace): `test_asim_schema(<parser>, <schema>)` then `test_asim_data(<parser>, <schema>)`.
   - Do **not** call `run_all_checks`; `check_kql`/`check_non_ascii` are repo-wide + slow — only if explicitly asked.
3. **Run checks.** Two engines:
   - **Preferred — official local harness:** `run_local_validation(solution_name=...)` (or `path=...` for
     standalone content like ASIM: `path="Parsers/ASimDns"`; or `diff_base="master"` for changed-files only).
     This runs Microsoft's `.script/local-validation/validate.js` (same code as CI, native local discovery,
     no shim) and covers all 12 TS validators in one fast call (~2s). Slow .NET/ARM-TTK skipped by default
     (`include_slow=True` to add). Use this as the primary check.
   - **`run_all_checks(solution_name)`** — the per-category fan-out (Node checks via shim + .NET + ARM-TTK +
     packaging). Use when you want the scoped .NET analytic-rule/ARM-TTK/packaging checks too.
   `run_all_checks` covers:
   Data Connector, Parser, ASIM parser, Analytic Rules, Playbook, Workbook, Solution
   Metadata, Logo, Sample Data, Content branding, Doc links, Package (packaging + ARM-TTK).
   The slow repo-wide KQL check is excluded by default — pass `include_slow=True` or run
   `run_one_check("check_kql", solution)` explicitly.
   - **Extra CI pipelines not in the harness** (`list_ci_extra_checks` to enumerate):
     - `scan_secrets()` — trufflehog secret scan (mirrors ScanSecrets.yaml; needs the `trufflehog` binary).
     - `check_detection_version_bumped()` — modified Detections/Analytic-Rules YAMLs must bump `version:`
       (mirrors "check that the version was updated").
     - `check_asim_sample_data(parser_path)` — ASIM sample-data file naming (offline, ~1s).
     - `run_ps_validator("hyperlink"|"classic-app-insights"|"field-types")` — the package-automation
       PowerShell validators; these run against your **last commit** (`git diff HEAD^ HEAD`).
       Path-gated in CI: hyperlink/classic-app-insights on `Solutions/**`, field-types on `**/Package/mainTemplate.json`.
     - `run_asim_template_test()` / `run_asim_filtering_test()` — the official ASIM Python testers
       (runAsimSchemaAndDataTesters.yaml). Network/commit-coupled: need `pip install requests pyyaml tabulate`,
       a pushed commit + `upstream` remote; filtering test also needs `az login` + workspace. For a quick
       offline ASIM check prefer `check_asim_parser`; for live data prefer `test_asim_data`.
4. **Report** — render a roll-up table (category → check → status → detail), then list
   findings (file, line, message) for each FAIL/WARN. A WARN on a `dotnet` check means a
   required .NET runtime is missing.
5. **Fix** — for each finding, read its `fix_skill` field and invoke the mapped domain
   skill below. With `--fix`, apply edits then re-run the affected check via
   `run_one_check` and confirm PASS. Without `--fix`, present fixes and ask first.
6. **Live data (`--live`)** — if a workspace is configured: `verify_table_ingestion`,
   `verify_connector_status`, `run_kql_query`. Fold into the report.
7. **Summary** — overall verdict (counts) + prioritized remaining failures.

## Fix-skill routing (MCP `fix_skill` → this repo's skills)
| MCP check(s) | Domain skill |
|---|---|
| check_data_connector, check_arm_ttk | **sentinel-data-connector** |
| check_non_ascii, check_kql (custom parsers) | **sentinel-custom-parser** |
| check_asim_parser (ASIM normalized parsers) | **sentinel-asim-parser** |
| check_analytic_rules, check_analytic_id, check_kql | **sentinel-analytics-rules** |
| check_playbook | **sentinel-playbook** |
| check_workbook_metadata, check_workbook_template | **sentinel-workbook** |
| check_packaging, check_solution_metadata, check_logo, check_sample_data | **sentinel-packaging** |
| check_content_branding, check_doc_links, JSON/YAML syntax, PR-level | **sentinel-process-ops** |
| final gate before release | **sentinel-final-signoff** |

## Live dev/test on Azure
For *building and testing* artifacts against a live workspace (not just PR review), use the
**sentinel-azure-devtest** skill — the deploy→test→verify→fix→redeploy loop. It drives the
Azure tools: `deploy_arm_template`, `create_scheduled_rule`, `rule_creates_incident`,
`preview_rule_query`, `trigger_playbook`, `get_playbook_runs`, `test_asim_schema`/`test_asim_data`,
`get_connector_data`, `get_functionapp_traces`, `list_incidents`, `run_kql_query`/`export_kql_query`.
Each domain skill has a "Live test on Azure" section with its specific recipe.

## Notes
- The MCP returns a normalized result per check `{status, summary, findings[]}` where each
  finding carries `fix_skill` + `fix_hint`. Trust that routing.
- The MCP overlays a local git-diff shim onto the repo's `gitHubWrapper.js` only for the
  duration of each check and restores it — the repo is never left dirty.
- For GitHub/GitLab PR-level checks, use the GitLab MCP / `gh` CLI as needed.
