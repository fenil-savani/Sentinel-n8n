---
name: sentinel-custom-parser
description: Build and fix Azure Sentinel CUSTOM (solution/vendor) parsers — the single-source
  KQL functions under Solutions/<Name>/Parsers (YAML keys id / Function.Title/Version/
  LastUpdated / Category / FunctionName / FunctionAlias / FunctionQuery). Covers safe field
  access (column_ifexists), all-fields-optional, TimeGenerated coalesce, union-with-empty-
  datatable, explicit projection, no hardcoded URLs/creds, DCR stream alignment, Log
  Ingestion API updates, and testing with typed sample data. Use for custom parsers; for
  ASIM normalized parsers use sentinel-asim-parser instead.
---

# sentinel-custom-parser

Custom (vendor/solution) parsers — one KQL function per log source, under
`Solutions/<SolutionName>/Parsers/`. Reference: Corelight solution parsers.

> For **ASIM** normalized parsers (`ASim*`/`im*`/`vim*` under `ASIM/` and repo-root
> `Parsers/`), use **sentinel-asim-parser** — different YAML and query model.

## Verify first (MCP)
`run_one_check("check_non_ascii", <solution>)`; deep KQL: `run_one_check("check_kql", <solution>)` (slow, repo-wide).

## Live test on Azure (dev loop)
Deploy the parser with the solution, then `test_parser(parser_name, limit=10)` → confirm rows with the
expected typed columns; use `run_kql_query`/`export_kql_query` for edge cases and sample data. A KQL error
in the result ⇒ missing `column_ifexists` / schema mismatch / no `union` empty table → fix here →
redeploy → re-test. Full loop: **sentinel-azure-devtest**.

## Team parser checklist
1. **All necessary fields parsed** — every field needed downstream is projected.
2. **Updated for Log Ingestion API** — on migration, update table/column names (drop `_s`/`_t`/`_d`; align with the DCR `streamDeclarations`).
3. **All fields optional** — `column_ifexists(...)` for every field so a missing field never fails parsing.
4. **Test with typed test data** — validate against data containing all fields, each with the expected type.
5. **Union with empty datatable** — so dashboards don't error when the table is empty.
6. **No static URLs/credentials in mainTemplate** — use parameters/variables (see **sentinel-data-connector** §3).

## Common CI failures → fix
**KQL Validation `KS204`** — e.g. *"The name 'ContrastADRIncidents_CL' does not refer to any known
table, tabular variable or function. Code: 'KS204', Severity: 'Error'"*.
Cause: the custom table's schema isn't registered, so the validator doesn't know the table used in
the parser / analytic rule / workbook.
Fix: add a schema file at **`.script/tests/kqlvalidationtests/CustomTables/<Table>_CL.json`** using the
**exact** table name and **all required schema fields** (see **sentinel-packaging** for the JSON shape).

## Custom parser YAML structure
`Solutions/<SolutionName>/Parsers/<source>.yaml`:
```yaml
id: <new-uuid>                 # python -c "import uuid; print(uuid.uuid4())" — never change
Function:
  Title: <Source Log Type> Parser
  Version: "1.0.0"             # bump on update; id stays fixed
  LastUpdated: <YYYY-MM-DD>
Category: Microsoft Sentinel Parser
FunctionName: <vendor>_<logtype>      # e.g. corelight_dns — snake_case, no spaces
FunctionAlias: <vendor>_<logtype>     # same as FunctionName
FunctionQuery: |
  let <vendor>_<logtype> = view () {
      union isfuzzy=true <Table>_CL, <Table>_red_CL, dummy_table
      | extend EventVendor = "<Vendor>", EventProduct = "<Product>", EventType = "<logtype>"
      | extend SrcIp = tostring(column_ifexists("id_orig_h_s", ""))
      | project TimeGenerated, EventVendor, EventProduct, EventType, SrcIp /*, ... all fields */, Type
      | union (datatable(TimeGenerated:datetime, EventVendor:string, SrcIp:string)[])
  };
  <vendor>_<logtype>
```

## KQL fixes
### Safe field access (all fields optional)
```kql
| extend EventType = tostring(column_ifexists("type", ""))      // not: = type
| extend EventTime = todatetime(column_ifexists("time", ""))
| extend EventCount = toint(column_ifexists("count", 0))
| extend RawDetails = todynamic(column_ifexists("details", "{}"))
| extend Severity = coalesce(tostring(column_ifexists("severity","")), tostring(column_ifexists("level","")), "Informational")
```
### TimeGenerated coalesce fallback
```kql
| extend TimeGenerated = coalesce(todatetime(column_ifexists("EventTime","")), todatetime(column_ifexists("time","")), now())
```
### Union with empty datatable (consistent schema when no data)
```kql
| project TimeGenerated, EventType, SrcIp
| union (datatable(TimeGenerated:datetime, EventType:string, SrcIp:string)[])
```
### Explicit projection (no `project *`); always include `Type`. No hardcoded values:
```kql
| where SrcIp !in (toscalar(_GetWatchlist('ExcludedIPs') | project SearchKey))   // not literal IPs
| where TimeGenerated > ago(90d)                                                  // not datetime(2024-01-01)
```
- Align column names exactly with the ARM template `streamDeclarations`; drop `_s`/`_t`/`_d` suffixes (HTTP Collector API only).
- Use lookup `datatable`s for enum mapping; `union isfuzzy=true` across the source table variants; `join` reference parsers for context.

## Metadata
- **UUID** (`id`): generate once, never change; only bump `Function.Version`.
- **FunctionName/Alias**: `<vendor>_<logtype>` (e.g. `corelight_http`); consistent across files.
- **Category**: `Microsoft Sentinel Parser`. Document renamed reserved keywords (`type`→`DetectionType`, `time`→`EventTime`) and avoid circular parser references.
