---
name: sentinel-process-ops
description: Fix Azure Sentinel solution process & operations concerns — environment setup
  & prerequisites, testing/QA (pytest coverage, flake8, bandit, QA sign-off), GitHub & PR
  process (branching, commits, gh PR, local pipeline runner, CI-failure fixes),
  documentation (install/user/release-notes/README), deployment (rollback, App Insights,
  release tags), and project management (Jira/Confluence/sprints/status emails). Use for the
  non-asset workflow steps around a Sentinel PR.
---

# sentinel-process-ops

Remediation for the process/ops steps around a Sentinel solution PR.

## Verify first (MCP)
Run `run_one_check("check_content_branding", <solution>)`, `run_one_check("check_doc_links", <solution>)`,
and `run_one_check("check_json_yaml_syntax", <solution>)`. For PR-level checks use the GitLab MCP / `gh` CLI.

## Setup & prerequisites
```powershell
winget install --id Microsoft.Powershell --source winget   # PS7; $PSVersionTable.PSVersion
Install-Module powershell-yaml -Scope CurrentUser -Force
code --install-extension msazurermtools.azurerm-vscode-tools
# Node LTS (node --version); Python 3.12 with PATH (py -3.12 --version)
```
Create missing folders: `Analytic Rules`, `Playbooks`, `Workbooks`, `Data Connectors`, `Release Notes`,
`Logos`, `Data`, `Sample Data/Custom`, `.scripts/tests/kqlvalidationtests/CustomTables`,
`.scripts/tests/detectiontemplateschemavalidation`. README references the Jira ticket + Confluence page.

## Testing & QA
```bash
pip install pytest pytest-cov pytest-mock
pytest --cov=connector --cov-report=term-missing --cov-fail-under=80
flake8 . --max-line-length=120 --statistics --count
autopep8 --in-place --recursive --max-line-length 120 .
bandit -r . -l -ii
```
Cover success/401/429/timeout/empty/User-Agent; coverage ≥80%; performance (10k recs <60s, ≤30MB chunks);
backward-compat + invalid-creds tests. HTTPS only, never `verify=False`; no hardcoded secrets. Produce
`QA/TestResults_v1.0.md` (date, tester, env, results, known issues, QA-lead sign-off).

## GitHub & PR process
- Never on `main`: `git checkout -b feature/<solution>-<version>`; stay current via `git fetch origin && git rebase origin/main`.
- Commit `<type>(<scope>): <desc>` with body explaining *why* + `Fixes: JIRA-123`.
```bash
gh pr create --title "feat: Add <Solution> Data Connector vX" --body "<summary/testing/related/checklist>" --reviewer "r1,r2"
git push --force-with-lease   # never plain --force
```
- **Local pipeline before pushing:** create `.script/localPipelineRunner.mjs` (set `SOLUTION`) importing the repo's `*Validator.js` and running them against `Solutions/<SOLUTION>` with a PASS/FAIL summary + `exit(1)`; run then delete (never commit). *(The sentinel-pr-review MCP now does this — prefer `run_all_checks`.)*
- CI-fail fixes: dataConnector `permissions.resourceProvider` exact (case-sensitive); KQL → add CustomTables schema JSON; **never change a detection `id` UUID** (only bump `version`); JSON/YAML parse errors; logo remove `xlink:href` & <500KB; solutionValidator add `name`/`version`/`description`; ARM `az deployment group validate`.
- Post-merge: merge-notification email; Jira → Done w/ PR link. Broken `aka.ms` → contact MS Sentinel team; verify `curl -sI`.

## Documentation
Standard set: **Installation Guide** (prereqs, App Registration → Deploy button → verify ingestion `<Table>_CL | limit 10`, troubleshooting); **User Guide** (sample KQL, field reference, best practices); **Release Notes** `Release Notes/ReleaseNotes_v1.0.md` (version/date/features/known issues/upgrade); **Architecture** (Source API → Function App Py3.12 → Log Ingestion API → DCR → `<Table>_CL`); **README.md** (Deploy button, components, support); Content Hub install steps.

## Deployment
- Gate: all checks pass, docs complete, documented **Security Review Sign-off** (no hardcoded creds, HTTPS, secureString, Key Vault, no PII in logs, bandit 0 HIGH, approver/date).
- **Rollback** (`Deployment/RollbackProcedure.md`): redeploy previous template / stop Function App / revert `WEBSITE_RUN_FROM_PACKAGE`; verify `<Table>_CL | where TimeGenerated > ago(1h) | summarize count()`.
- **App Insights** in ARM + Function App settings:
```json
{ "type": "Microsoft.Insights/components", "apiVersion": "2020-02-02", "name": "[variables('appInsightsName')]",
  "location": "[parameters('WorkspaceLocation')]", "kind": "web",
  "properties": { "Application_Type": "web", "WorkspaceResourceId": "[resourceId('Microsoft.OperationalInsights/workspaces', parameters('WorkspaceName'))]" } }
```
Add a failure metric alert. Release: `git tag -a v1.0.0 -m ... && git push origin v1.0.0`; `gh release create v1.0.0`. Submit to Microsoft for marketplace review.

## Project management
- Jira/board/Confluence links in README; log hours per ticket; separate support ticket per customer issue.
- Confluence page (Overview, Architecture, ADRs, Known Issues, Sprint History, Contacts). `sprint_plan.md` (goal, stories, retro). Dedicated "Support Sprint - <Month> <Year>".
- Templates: weekly status email (On Track/At Risk/Blocked + completed/in-progress/blockers + links); MOM (attendees/decisions/action items); **QAC sign-off email** (unit/coverage, integration, security, cross-cloud, perf → "APPROVED FOR RELEASE", QA Lead/date). Support tracking sheet (Date|Ticket|Issue|Root Cause|Resolution|Time|Status).
