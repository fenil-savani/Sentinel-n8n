# Sentinel PR Review — Skills

9 domain-aligned skills (merged from the original 36 `*-verify`/`*-fix` command files).
Verification is now done by the **sentinel-pr-review MCP**; these skills focus on
**remediation** (fixes) plus a short pointer to the MCP check that verifies each domain.

## Skills
| Skill | Covers (old modules) | Verifies via MCP |
|---|---|---|
| **sentinel-pr-review** | orchestrator (was review-sentinel-pr) | `run_all_checks` / `detect_pr_scope` |
| **sentinel-data-connector** | m02 python · m04 ARM · m09 UI · m11 ingestion | `check_data_connector`, `check_arm_ttk` |
| **sentinel-custom-parser** | m03 parser · m05 metadata (Solutions/*/Parsers) | `check_non_ascii`, `check_kql` |
| **sentinel-asim-parser** | ASIM normalized parsers (ASIM/ · Parsers/ASim*) | `check_asim_parser`, `check_kql` |
| **sentinel-analytics-rules** | m06 | `check_analytic_rules`, `check_analytic_id`, `check_kql` |
| **sentinel-playbook** | m07 | `check_playbook` |
| **sentinel-workbook** | m08 | `check_workbook_metadata`, `check_workbook_template` |
| **sentinel-packaging** | m10 | `check_packaging`, `check_solution_metadata`, `check_logo`, `check_sample_data` |
| **sentinel-process-ops** | m01 setup · m12 QA · m13 PR · m14 docs · m15 deploy · m16 PM | `check_content_branding`, `check_doc_links`, syntax |
| **sentinel-azure-devtest** | live dev+test loop (deploy→test→verify→fix→redeploy) | all Azure tools: deploy/trigger/create-rule/traces/testers |
| **sentinel-final-signoff** | final-signoff verify+fix | full suite + live-data + sign-off gate |

## Activating in Claude Code
Claude Code discovers skills under a `.claude/skills/` directory. To use these:
- **Option A (symlink):** point `~/.claude/skills` (or the project's `.claude/skills`) at this folder, e.g.
  ```powershell
  New-Item -ItemType SymbolicLink -Path "$env:USERPROFILE\.claude\skills" -Target "C:\Users\devendra.chavda\Desktop\Sentinel-work\Automation\sentinel-pr-review\skills"
  ```
- **Option B (copy):** copy these 9 folders into `~/.claude/skills/`.

Each skill is `skills/<name>/SKILL.md` with `name` + `description` frontmatter, so it
shows up as an invocable skill. Start with `/sentinel-pr-review <SolutionName>`.
