---
name: sentinel-workbook
description: Fix Azure Sentinel workbook issues — workbook JSON structure (version
  Notebook/1.0, globally-unique fromTemplateId), empty parameters (no stored user values),
  time-range parameter, panel patterns (pie/tile/grid), metadata YAML, and preview images
  (Black/White PNG). Use when an MCP check (check_workbook_metadata, check_workbook_template)
  fails or when building/repairing a workbook.
---

# sentinel-workbook

Remediation for workbooks.

## Verify first (MCP)
Run `run_one_check("check_workbook_metadata", <solution>)` and
`run_one_check("check_workbook_template", <solution>)`.

## Live test on Azure (dev loop)
Deploy the workbook ARM (`deploy_arm_template`), confirm with `list_workbooks()`, then test each panel's
KQL via `get_workbook_data(query, timespan_hours)` → returns data, no error, within 10k-row/100-series
limits. Fix here → redeploy → re-test. Visual checks (centering/legends/drill-down/preview PNGs) are
portal-only. Full loop: **sentinel-azure-devtest**.

## Deploying a workbook to a workspace (ARM)
A workbook is a `Microsoft.Insights/workbooks` resource. Deploy it with `deploy_arm_template`:
```jsonc
{ "type": "microsoft.insights/workbooks", "apiVersion": "2022-04-01",
  "name": "[parameters('workbookId')]",          // a STABLE GUID (uuid5 of a fixed string → idempotent updates)
  "location": "[parameters('location')]", "kind": "shared",
  "properties": {
    "displayName": "Relevance System Alerts",
    "serializedData": "<the workbook JSON, json.dumps'd into a string>",
    "version": "1.0",
    "sourceId": "<Log Analytics workspace resource id>",   // scopes queries + lists it in that workspace
    "category": "sentinel"                                  // shows under Sentinel → Workbooks → My workbooks
  } }
```
- Build the workbook JSON programmatically, then `serializedData = json.dumps(workbook)` — far easier than hand-editing escaped JSON. A reusable generator lives at `tools/build_relevance_workbook.py`.
- Validate → create like any template; preview PNGs are still portal-only.

## Panel design techniques (used in the Relevance workbook)
- **Clean enum labels** — strip API prefixes in KQL so charts read well:
  `summarize Count=count() by Severity = replace_string(severityAnalysis_severityLevel, "SEVERITY_LEVEL_", "")`.
- **KPI tile strip from one query** — `union` several `summarize | extend Metric=..., o=N`, `order by o`, render
  `visualization:"tiles"` with `tileSettings.titleContent=Metric`, `leftContent=Count`.
- **Side-by-side panels** — set `content.customWidth` ("33"/"50") on adjacent query items.
- **Time binding** — type-4 `TimeRange` parameter + `| where TimeGenerated {TimeRange}` in each query; give
  `selectableValues` + a default `durationMs`.
- **Grid polish** — `gridSettings.filter:true`, `sortBy` desc, `formatters` (e.g. icon thresholds on Severity),
  and cap with `take 10000`.

## Workbook QA checklist
### General
- **Use parsers in panels** wherever possible; any repeated/complex query belongs in a **parser**, not inline in panels.
- **Empty parameters before saving** — no stored values in the template except **default values** (see *Empty parameters* below).
- **Consistent nomenclature** across the whole workbook (e.g. "Time", "# / Number of", "Count of") — uniform for time, counts, and labels.
- **Drill-down tooltip** — every parent panel with drill-down shows a tooltip telling the user to click a row for details.
- **Panel features enabled on every panel**: "open last run query" + "refresh". Grid panels also: **search filter, refresh icon, export button, open-last-query button**. Drill-down panels also need a **"Clear Selection"** button.
- **Drill-down respects the parent's time range** — child data matches the time range applied on the parent panel.
- **Chart limits** — charts are capped at **100 series** and **10,000 data points**; design queries to stay within these.

### Grid
- **Search filter works on all columns** of the grid.
- **Default sort descending** on a chosen field.
- **Top 10,000 rows** shown (no pagination) when data is large — `| top 10000 by <field> desc`.
- **Export to Excel** button present on every grid panel.

### Pie
- Show only the **top 10**; club the rest under an **"Others"** label.

### Tile (single value)
- Value size **appropriate and centered**; verify the **highest possible value** renders correctly; tile has a **border**.

### Bar chart
- A **label against each bar**.

### Line chart
- **Legends not truncated**; **source values on X-axis, average values on Y-axis**.

### All charts (pie/bar/line)
- **Every series has a legend** — none skipped.

### Legends
- **Sorted by data count**, matching the chart's sort order.
- **Uniform label format** throughout the workbook (may vary slightly by chart type).

### mainTemplate
- No static URLs/credentials when generating `mainTemplate.json` (use parameters/variables).

## Workbook fixes
### JSON structure
```json
{ "version": "Notebook/1.0", "items": [], "fromTemplateId": "<globally-unique-uuid>",
  "name": "<WorkbookName>",
  "$schema": "https://github.com/Microsoft/Application-Insights-Workbooks/blob/master/schema/workbook.json" }
```
`fromTemplateId` must be globally unique — `python -c "import uuid; print(uuid.uuid4())"`.

### Empty parameters (no stored user values)
```json
// Bad:  "value": { "durationMs": 7776000000 }      // remove stored value
// Good: time param with selectableValues, user picks at runtime:
{ "id": "TimeRange", "version": "KqlParameterItem/1.0", "name": "TimeRange", "type": 4, "isRequired": true,
  "typeSettings": { "selectableValues": [ {"durationMs":300000},{"durationMs":3600000},
      {"durationMs":86400000},{"durationMs":604800000},{"durationMs":2592000000},{"durationMs":7776000000} ] } }
```
Add a time-range parameter (type 9 parameters item) as the first item with `allowCustom: true`.

### Panels
```kql
// Pie (top 10 + "Others"):
<TableName>_CL | where TimeGenerated {TimeRange}
| summarize Count=count() by Category | order by Count desc
| extend Rank=row_number() | extend CategoryDisplay=iff(Rank<=10, Category, "Others")
| summarize TotalCount=sum(Count) by CategoryDisplay | sort by TotalCount desc
```
- Tile: `"visualization": "tiles"`, `tileSettings.showBorder: true`.
- Grid: `gridSettings.filter: true`, `sortBy` (`sortOrder` 1=asc,2=desc), `exportOptions.csvDownloadFileName`. Always cap at 10,000 rows (`top 10000 by TimeGenerated desc`).

### Metadata YAML — `Workbooks/<WorkbookName>.yaml`
```yaml
id: <unique-uuid>
name: <WorkbookDisplayName>
description: |
  Visibility into <Solution> data in Microsoft Sentinel: trends, threat analysis, investigation.
category: Security
version: 1.0.0
fromTemplateId: <globally-unique-uuid>
previewImagesFileNames: [ <WorkbookName>Black.png, <WorkbookName>White.png ]
dataTypes: [ <TableName>_CL ]
dataConnectorsDependencies: [ <ConnectorId> ]
```

### Preview images
Deploy to a test workspace, open at 100% zoom: light mode → `<WorkbookName>White.png`, dark mode →
`<WorkbookName>Black.png`. PNG ≥ 800×600, < 2MB. Register both in the YAML `previewImagesFileNames`.

## Playbook-trigger workbooks (input → run playbook → show result)
When a workbook page's job is "take an input, fire a Logic App, then show that specific result" (CVE lookup,
IOC rescan, URL/file scan) — not just visualize pre-existing data — use this pattern (seen in Censys and GTI):

### ArmAction submit button
```json
{ "type": 11, "content": { "version": "LinkItem/1.0", "style": "paragraph", "links": [
  { "linkTarget": "ArmAction", "linkLabel": "Scan URL", "style": "primary", "linkIsContextBlade": true,
    "armActionContext": {
      "path": "/subscriptions/{SubscriptionId}/resourceGroups/{ResourceGroup}/providers/Microsoft.Logic/workflows/<PlaybookName>/triggers/manual/run?api-version=2016-10-01",
      "body": "{\n  \"url\": \"{ScanUrl}\"\n}", "httpMethod": "POST",
      "description": "# Explain the action before the user confirms.", "runLabel": "Scan URL" } } ] },
  "conditionalVisibilities": [ /* one isNotEqualTo per required input param, so the button only renders once all are filled */ ] }
```
`<PlaybookName>` in the path is literally the Logic App resource name — i.e. the playbook's `PlaybookName`
ARM parameter default, not a display label. Verify it matches `azuredeploy.json` exactly.

### Gated "has it landed yet" status tile + detail panel
Don't make the user guess whether ingestion finished — show a tile that flips text once data exists, then
gate the detail panel on that text:
```kql
// status tile (last 24h, filtered by the same input the user just submitted)
let dummy_table = datatable(TimeGenerated:datetime, <keyCol>:string) [];
union isfuzzy=true dummy_table,
(<Table> | where TimeGenerated > ago(24h) | where <keyCol> contains '{InputParam}')
| summarize count()
| extend status = case(count_ == 0, "Click on refresh icon to check data availability", "Click here to populate data.")
| project status
```
Tile settings: `visualization:"tiles"`, `exportFieldName`/`exportParameterName: "status"`, `tileSettings.titleContent.columnMatch:"status"`.
Wrap the detail panel in a `type:12` group with `conditionalVisibilities: [{parameterName:"status", comparison:"isEqualTo", value:"Click here to populate data."}]`
so the table is invisible until data actually exists — don't render an empty/error grid while waiting.
Detail panel gets the **latest response only** via `top 1 by TimeGenerated desc` then `arg_max(TimeGenerated, *) by <keyCol>`.

- **Use `contains`, not `=~`/`==`, when matching free-text input against a stored value that may have a
  prefix/suffix the user won't type** (e.g. input `example.com` vs. stored `http://example.com`). `contains`
  is case-insensitive by default in KQL — no extra `tolower()` needed. Exact match silently "finds nothing"
  even though the row exists, which reads as a bug, not a query design choice.
- Reuse the parameter name `status` per-tab/per-group; each `NotebookGroup` is its own scope so it's safe to
  repeat across tabs of the same workbook.

## Hardening panel KQL against schema drift
When a panel queries a **raw ingestion table** (not a parser function) whose columns come from a DCR transform
with nested `parse_json`/`todynamic` chains, wrap every referenced column in `column_ifexists("col", default)`
before use, even though the table's ARM-defined schema "should" already have that column:
```kql
| extend attributes_url = tostring(column_ifexists("attributes_url", ""))
```
This is cheap insurance against a hard "column not found" semantic error if the table was created by an older
version of the ARM template, or a column briefly lags behind an ingestion schema change. Prefer querying a
**parser function** (view) over the raw `_CL` table wherever one exists — parsers already do this
`column_ifexists` hardening once, centrally, instead of repeating it in every panel.

## Description-panel writing convention (multi-page action workbooks)
For a page whose purpose is "trigger playbook, view result" (not passive dashboarding), structure the intro
markdown as: **page title** → **Purpose** (one line, name the concrete playbook and what it fetches) →
**Setup** (numbered: which params to fill) → **Run** (numbered: click button → confirm in panel → what the
playbook does) → **View Results** (numbered: refresh → status tile flips → gated detail panel → full-history
grid below) → **Important Notes** (timing caveats, matching behavior, where to check playbook run history).
Keep this identical in shape across every tab of the same workbook — users learn the pattern once. Avoid
generic tooltips like "click a row below for details" unless the grid actually has `exportParameterName`
drill-down wired — otherwise it's a broken promise; describe what the grid *actually* shows instead.
