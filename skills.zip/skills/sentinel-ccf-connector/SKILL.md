---
name: sentinel-ccf-connector
description: Build and validate Azure Sentinel Codeless Connector Framework (CCF) data
  connectors — the four components (output table, DCR, connector definition UI, data
  connection rules), the RestApiPoller / GCP / StorageAccountBlobContainer / Push connector
  kinds, auth types (Basic, APIKey, OAuth2, JWT, ServicePrincipal, Push), request/response/paging
  config, dcrConfig, securestring handling, the 5-resource ARM template structure, solution
  packaging (createSolutionV3.ps1), and deploy/verify. Use when building, fixing, or reviewing a
  CCF (codeless / agentless / SaaS) connector — folders named *_ccf / *_ccp / *_CCF — as opposed to
  an Azure-Functions Python connector (use sentinel-data-connector for those).
---

# sentinel-ccf-connector

Build/fix/validate **Codeless Connector Framework (CCF)** connectors. CCF connectors are fully
SaaS — no Azure Function, no service install — Sentinel either *polls* the source API or the source
*pushes* to a DCE. Content embedded here is from the Microsoft Learn CCF docs (as of 2026-05); links
are kept only as deep-reference pointers.

> **CCF vs Function-App connector:** if the connector folder contains Python + `host.json` +
> `function_app.py`, it's a classic Azure-Functions connector → use **sentinel-data-connector**.
> If the folder (usually `*_ccf` / `*_ccp` / `*_CCF`) contains `*_ConnectorDefinition.json` +
> `*_PollerConfig.json`/`*_PollingConfig.json` + a DCR/table, it's CCF → use this skill.

## Reference connectors in this repo (read these first)
Under `C:\Users\devendra.chavda\Desktop\Azure-Sentinel\Solutions`:
- **Pull / RestApiPoller, APIKey, multi-datatype:** `UniFi Site Manager (CCF)\Data Connectors\UnifiSiteManagerLogs_ccf\` (`*_ConnectorDefinition.json` + `*_PollerConfig.json`) — cleanest reference.
- **Pull / RestApiPoller:** `Darktrace\Data Connectors\ccf\`, `Mulesoft\Data Connectors\MulesoftLogs_CCF\`, `Microsoft 365 Audit General and DLP\Data Connectors\M365AuditGeneral_CCF\`, `Akamai Guardicore\Data Connectors\AkamaiGuardicoreLogs_ccp\`, `QualysVM\...\QualysVMHostLogs_ccp\`.
- **Full stitched `_ArmTemplate.json`:** `Utimaco Enterprise Secure Key Manager\Data Connectors\sentinel-connectors\UtimacoESKM_CCF\`.
- **Push CCF:** `Pathlock_TDnR\Data Connectors\Pathlock_TDnR_PUSH_CCP\`.
- The assembled output for any solution is always in `<Solution>\Package\mainTemplate.json`.
MS-maintained `RestApiPoller` examples: Ermes Browser Security, Palo Alto Prisma Cloud CWPP, Sophos
Endpoint Protection, Workday, Atlassian Jira (`_ccpv2`), Okta SSO (`OktaNativePollerConnectorV2`).

## Verify first (MCP)
`run_one_check("check_data_connector", <solution>)` and `run_one_check("check_arm_ttk", <solution>)`.
For CCF **Push** connectors the arm-ttk step is *expected to fail* — packaging succeeded if the three
"valid Json file" messages appear (createUiDefinition.json, mainTemplate.json, testParameters.json).
Live deploy/verify loop: **sentinel-azure-devtest** (`deploy_arm_template` → enable connector in the
gallery → `verify_table_ingestion(<Table>_CL)` / `get_connector_data`).

---

## The four components of a (pull) CCF connector
Build each, then splice the JSON into the ARM template.
1. **Output table definition** — the custom `_CL` table (skip if you only land in standard tables).
2. **Data Collection Rule (DCR)** — what to collect, how to transform (`transformKql`), where to send.
3. **Data connector user interface** — `dataConnectorDefinitions`, `kind: Customizable`.
4. **Data connection rules** — the `dataConnectors` resource (`kind: RestApiPoller` / `GCP` / `StorageAccountBlobContainer` / `Push`).

### Prerequisites / before you build
- **DCE:** a DCR requires a Data Collection Endpoint in the same region. Only one DCE per workspace
  DCR deployment is needed; every DCR for that workspace reuses it. (CCF creates the DCR on connect if absent.)
- **Know your data shape:** sample enough API output to design the table + stream columns.
- Verify your source's **HTTP request/response shape, auth type, and pagination** are all supported
  (see tables below) *before* coding. E.g. cert-signed-token auth is **not** supported by CCF.
- Test the raw API first with a **local/offline** tool (VS Code REST client, PowerShell
  `Invoke-RestMethod`, Bruno, curl). Never paste secrets into a cloud-synced tool.

---

## Component 1 — Output table definition
Custom log table names **must** end with `_CL`. Include `TimeGenerated` (datetime). Column types:
`string, int, long, real, bool, datetime, dynamic, guid`. Use table API version `2022-10-01`
(pull) or `2025-07-01`+ (push). Either land everything in one custom table, or split (custom table
for some events, a standard table like `ASimFileEventLogs`/`CommonSecurityLog` for the rest).

```json
{
  "name": "ExampleConnectorAlerts_CL",
  "apiVersion": "2022-10-01",
  "type": "Microsoft.OperationalInsights/workspaces/tables",
  "properties": {
    "schema": {
      "name": "ExampleConnectorAlerts_CL",
      "columns": [
        { "name": "TimeGenerated", "type": "datetime" },
        { "name": "SourceIP", "type": "string" },
        { "name": "DestIP",   "type": "string" },
        { "name": "Message",  "type": "string" },
        { "name": "Priority", "type": "int" }
      ]
    }
  }
}
```

---

## Component 2 — Data Collection Rule (DCR)
One DCR per data connector. `streamDeclarations` keys **must** start with `Custom-`. `dataFlows` route
each input stream to an `outputStream` via `transformKql` (`"source"` = pass-through). `outputStream`
is `Custom-<TableName>_CL` for a custom table, or `Microsoft-<StandardTable>` for a standard one.
DCR resource type `Microsoft.Insights/dataCollectionRules`, apiVersion `2021-09-01-preview`.

A single stream can fan out to multiple tables (one `dataFlows` entry each):
```json
"streamDeclarations": {
  "Custom-ExampleConnectorInput": {
    "columns": [
      { "name": "ts", "type": "datetime" }, { "name": "eventType", "type": "string" },
      { "name": "srcIp", "type": "string" }, { "name": "destIp", "type": "string" },
      { "name": "message", "type": "string" }, { "name": "priority", "type": "string" },
      { "name": "fileType", "type": "string" }, { "name": "fileSizeBytes", "type": "int" },
      { "name": "disposition", "type": "string" }
    ]
  }
},
"destinations": { "logAnalytics": [ { "workspaceResourceId": "[variables('workspaceResourceId')]", "name": "myDest" } ] },
"dataFlows": [
  {
    "streams": [ "Custom-ExampleConnectorInput" ], "destinations": [ "myDest" ],
    "transformKql": "source | where eventType == \"Alert\" | project TimeGenerated = ts, SourceIP = srcIp, DestIP = destIp, Message = message, Priority = priority",
    "outputStream": "Custom-ExampleConnectorAlerts_CL"
  },
  {
    "streams": [ "Custom-ExampleConnectorInput" ], "destinations": [ "myDest" ],
    "transformKql": "source | where eventType == \"File\" | project-rename TimeGenerated = ts, SrcIpAddr = srcIp, DstIpAddr = destIp, FileContentType = fileType, FileSize = fileSizeBytes",
    "outputStream": "Microsoft-ASimFileEventLogs"
  }
]
```
- `dataCollectionEndpointId` links the DCR to its DCE.
- Find the DCR **immutableId** in the create response (or via the DCR GET API) — the poller needs it.
- `outputStream` is required only when the transform changes the schema; for `Custom-Text-*` AMA file
  collection the pattern is `streamDeclarations: Custom-Text-<Table>` + `dataFlows.outputStream: Custom-<Table>`.

---

## Component 3 — Data connector user interface (`dataConnectorDefinitions`)
`type: Microsoft.SecurityInsights/dataConnectorDefinitions`, apiVersion `2022-09-01-preview`,
**`kind: Customizable`**. Built via the Data Connector Definition API. Key rules:
- `connectivityCriteria.type` = `HasDataConnectors` for pull polling connectors; use
  `IsConnectedQuery` (with a KQL value returning `IsConnected`) for production/push connectors.
- `instructionSteps` include the credential input controls and a button: `ConnectionToggleButton`
  (pull — triggers connection deployment) or `DeployPushConnectorButton` (push).
- `graphQueriesTableName` / `graphQueries` / `sampleQueries` / `dataTypes[].lastDataReceivedQuery`
  all reference your `_CL` table(s).
- `id` must be unique and is referenced by the connection rule's `connectorDefinitionName`.

Credential-prompt controls in `instructions` (these set up the ARM params the connection rule reads):
- `Textbox` (`type: password`/`text`, `name`) — e.g. an API key.
- `OAuthForm` (`UsernameLabel`, `PasswordLabel`, `connectButtonLabel`, `disconnectButtonLabel`).
- `CopyableLabel` (push — `fillWith: ["TenantId"|"ApplicationId"|"ApplicationSecret"|"DataCollectionEndpoint"|"DataCollectionRuleId"]`, or fixed `value`).
- `Markdown` — formatted instructions.

```json
"instructionSteps": [
  { "title": "1. Get API key", "description": "Steps to obtain the key..." },
  { "title": "2. Connect",
    "instructions": [
      { "type": "Textbox", "parameters": { "label": "API Key", "type": "password", "name": "apiKey", "placeholder": "Enter key" } },
      { "type": "ConnectionToggleButton", "parameters": { "connectLabel": "Connect", "disconnectLabel": "Disconnect" } }
    ]
  }
]
```

---

## Component 4 — Data connection rules (`dataConnectors`)
`type: Microsoft.SecurityInsights/dataConnectors`. Four kinds:

| kind | Use when | Notes |
|---|---|---|
| `RestApiPoller` | Sentinel polls a REST API | Full control of auth/request/response/paging. |
| `GCP` | Google Cloud Pub/Sub source | Paging + response preconfigured; only build table + DCR. |
| `StorageAccountBlobContainer` | Azure Storage Blob source | Response config + queue request; only build table + DCR. |
| `Push` | Your app pushes events to a DCE | Real-time; deployment creates Entra app + DCR + DCE + table. |

Top-level `RestApiPoller` properties: `connectorDefinitionName`, `dataType`, `dcrConfig`,
`auth`, `request`, `response`, `paging`, `isActive`. (`etag` empty on create; required-matching on update.)

### dcrConfig (all pull kinds)
```json
"dcrConfig": {
  "dataCollectionEndpoint": "[[parameters('dcrConfig').dataCollectionEndpoint]",
  "dataCollectionRuleImmutableId": "[[parameters('dcrConfig').dataCollectionRuleImmutableId]",
  "streamName": "Custom-<TableName>_CL"
}
```
`streamName` must equal a `streamDeclaration` key in the DCR (prefix `Custom-`).

> **Escape syntax (not a typo):** in the connection-rule JSON, parameters are written
> `"[[parameters('apiKey')]"` — **double `[[`** — so the value resolves from the connector UI/ARM
> param at deploy time rather than at template compile. Applies to every `[[parameters(...)]` in `auth`/`request`/`dcrConfig`.

### Authentication configuration
Supported: **Basic, APIKey, OAuth2, JWT** (pull); **ServicePrincipal** (Storage Blob); **Push**.
OAuth2 does **not** support client-certificate credentials. Always pass secrets via `securestring`
parameters, never hard-coded.

**Basic** — `{ "type": "Basic", "UserName": "[[parameters('username')]", "Password": "[[parameters('password')]" }`

**APIKey**
| Field | Req | Default | Meaning |
|---|---|---|---|
| `ApiKey` | yes | — | secret value |
| `ApiKeyName` | no | `Authorization` | header name carrying the key |
| `ApiKeyIdentifier` | no | `token` | string prepended to the key |
| `IsApiKeyInPostPayload` | no | `false` | send key in POST body, not header |
```json
"auth": { "type": "APIKey", "ApiKey": "[[parameters('apiKey')]", "ApiKeyName": "X-API-Key", "ApiKeyIdentifier": "Bearer" }
```
(Defaults give header `Authorization: token <key>`. `ApiKeyName: ""` → header value with no name prefix.)

**OAuth2** (`authorization_code` or `client_credentials`). Key fields: `ClientId`, `ClientSecret`,
`GrantType`, `TokenEndpoint`, `Scope`; for `authorization_code` also `AuthorizationCode`,
`AuthorizationEndpoint`, `RedirectUri` (must be
`https://portal.azure.com/TokenAuthorize/ExtensionName/Microsoft_Azure_Security_Insights`). Optional
`TokenEndpointHeaders`/`TokenEndpointQueryParameters`/`AuthorizationEndpointHeaders`/`...QueryParameters`.
```json
"auth": {
  "type": "OAuth2", "ClientId": "[[parameters('appId')]", "ClientSecret": "[[parameters('appSecret')]",
  "GrantType": "client_credentials", "TokenEndpoint": "https://login.microsoftonline.com/{{tenantId}}/oauth2/v2.0/token",
  "TokenEndpointHeaders": { "Content-Type": "application/x-www-form-urlencoded" }, "scope": "openid offline_access some_scope"
}
```

**JwtToken** — get a token from `TokenEndpoint` (username/password), then extract via `JwtTokenJsonPath`.
Key fields: `userName`/`password` as `{key,value}` objects (or `UserToken`), `TokenEndpoint`,
`IsCredentialsInHeaders` (true=basic-auth header, false=POST body), `IsJsonRequest`,
`JwtTokenJsonPath` (e.g. `$.access_token`), `JwtTokenInResponseHeader`/`JwtTokenHeaderName`,
`TokenEndpointHttpMethod`, `RequestTimeoutInSeconds` (default 100, max 180). Limitation: needs
username/password (no API-key/custom-header token requests). Auth header for the resulting JWT is always `Authorization`.

### Request configuration
| Field | Req | Default | Meaning |
|---|---|---|---|
| `ApiEndpoint` | yes | — | full URL to pull from |
| `HttpMethod` | | `GET` | `GET`/`POST` |
| `QueryWindowInMin` | | `5` | **fixed** window size: `end = start + QueryWindowInMin` (NOT "to now"); also the advance step. Only time knob — no separate trigger interval. min 1. See **Time windows & checkpointing**. |
| `RateLimitQPS` | | — | calls/sec for the initial request (not paginated calls) |
| `PaginatedCallsPerSecond` | | — | throttle for pagination (0…1000); usually = `RateLimitQPS` |
| `RateLimitConfig` | | — | adaptive throttling from response headers (see below) |
| `RetryCount` | | `3` | 1…6 |
| `TimeoutInSeconds` | | `20` | 1…180 |
| `QueryTimeFormat` | | ISO 8601 UTC | or `UnixTimestamp`/`UnixTimestampInMills`/custom (`yyyy-MM-dd`…) |
| `Headers` / `QueryParameters` | | — | key/value objects |
| `IsPostPayloadJson` | | `false` | POST body is JSON |
| `StartTimeAttributeName` + `EndTimeAttributeName` | pair | — | two time params (start required-with end) |
| `QueryTimeIntervalAttributeName` (+ `...Prepend`, `...Delimiter`) | | — | single combined time-range param |
| `QueryParametersTemplate` | | — | advanced/POST-body templated query |
| `InitialCheckpointTimeUtc` | | — | first-poll start time. **Silently ignored** unless: no checkpoint yet AND a start-time param exists w/o end-time AND the connector is NOT cursor/token-paginated. See **Time windows & checkpointing** — it does NOT work for most cursor-paged TI APIs. |

Built-in replacement tokens: `{_QueryWindowStartTime}`, `{_QueryWindowEndTime}` (both in
`queryParameters` and `queryParametersTemplate`); `{_APIKeyName}`, `{_APIKey}` (template only).
Always add a `User-Agent` header. `RateLimitConfig` example (adjusts rate from `429`/limit headers):
```json
"rateLimitConfig": {
  "evaluation": { "checkMode": "OnlyWhen429" },
  "extraction": { "source": "CustomHeaders", "headers": {
    "limit":     { "name": "X-RateLimit-Limit", "format": "Integer" },
    "remaining": { "name": "X-RateLimit-Remaining", "format": "Integer" },
    "reset":     { "name": "X-RateLimit-RetryAfter", "format": "UnixTimeSeconds" } } },
  "retryStrategy": { "useResetOrRetryAfterHeaders": true }
}
```

### Response configuration
| Field | Req | Meaning |
|---|---|---|
| `EventsJsonPaths` | yes | JSONPath(s) to the events array, e.g. `["$.data[*]"]`, `["$.value"]`, `["$"]` |
| `format` | yes | `json` / `csv` / `xml` (Storage Blob also `parquet`) |
| `SuccessStatusJsonPath` + `SuccessStatusValue` | | ingest only when status path == value |
| `IsGzipCompressed` | | response is gzip |
| `CompressionAlgo` | | `multi-gzip` / `deflate` (for plain gzip use `IsGzipCompressed:true` instead) |
| `CsvDelimiter` / `HasCsvHeader` (def true) / `HasCsvBoundary` / `CsvEscape` (def `"`) | | CSV parsing (RFC 4180) |
| `ConvertChildPropertiesToArray` | | source returns an object-of-properties instead of an event list |
```json
"response": { "eventsJsonPaths": [ "$.data[*]" ], "format": "json" }
```

### Paging configuration
Pick by what the API offers:
| `pagingType` | When |
|---|---|
| `LinkHeader` / `PersistentLinkHeader` / `NextPageUrl` | API gives next/prev page **links** |
| `NextPageToken` / `PersistentToken` | API gives a **token/cursor** |
| `Offset` | API takes a skip/offset param |
| `CountBasedPaging` | API takes a page-number/count param |

`Persistent*` variants store the cursor server-side across query windows (only one query can run to
avoid cursor race conditions). Common fields across types: `PageSize`, `PageSizeParameterName`,
`PagingInfoPlacement` (`QueryString`/`RequestBody`), `PagingQueryParamOnly` (drop all non-paging params).
```json
"paging": { "pagingType": "LinkHeader", "linkHeaderTokenJsonPath": "$.metadata.links.next" }
"paging": { "pagingType": "NextPageToken", "nextPageTokenJsonPath": "$.nextToken", "nextPageParaName": "nextToken" }
"paging": { "pagingType": "Offset", "offsetParaName": "offset", "pageSize": 50, "pagingQueryParamOnly": true, "pagingInfoPlacement": "QueryString" }
"paging": { "pagingType": "CountBasedPaging", "pageNumberParaName": "page", "pageSize": 10, "zeroBasedIndexing": true, "hasNextFlagJsonPath": "$.hasNext", "totalResultsJsonPath": "$.totalResults", "pageNumberJsonPath": "$.pageNumber", "pageCountJsonPath": "$.pageCount" }
```

### Full RestApiPoller connection example
```json
{
  "name": "MyPoller", "apiVersion": "2023-02-01-preview",
  "type": "Microsoft.SecurityInsights/dataConnectors", "kind": "RestApiPoller",
  "properties": {
    "connectorDefinitionName": "[[parameters('connectorDefinitionName')]",
    "dataType": "MyTable_CL",
    "dcrConfig": { "dataCollectionEndpoint": "[[parameters('dcrConfig').dataCollectionEndpoint]", "dataCollectionRuleImmutableId": "[[parameters('dcrConfig').dataCollectionRuleImmutableId]", "streamName": "Custom-MyTable_CL" },
    "auth": { "type": "APIKey", "ApiKey": "[[parameters('apiKey')]", "ApiKeyName": "X-API-Key" },
    "request": { "apiEndpoint": "https://api.example.com/v1/logs", "httpMethod": "GET", "queryWindowInMin": 5, "rateLimitQPS": 10, "retryCount": 3, "timeoutInSeconds": 60, "headers": { "Accept": "application/json", "User-Agent": "Sentinel-MyConnector" } },
    "response": { "eventsJsonPaths": [ "$.data[*]" ], "format": "json" },
    "paging": { "pagingType": "NextPageToken", "nextPageTokenJsonPath": "$.nextToken", "nextPageParaName": "nextToken" },
    "isActive": true
  }
}
```

---

## GCP connection rule (`kind: GCP`)
Paging/response preconfigured — you only author the **table** and **DCR**. Configure GCP Pub/Sub +
workload-identity federation separately (Terraform scripts in the repo). Start from
`DataConnectors/Templates/Connector_GCP_CCP_template.json`.
```json
{ "kind": "GCP", "properties": {
  "connectorDefinitionName": "[[parameters('connectorDefinitionName')]",
  "dcrConfig": { "streamName": "[variables('streamName')]", "dataCollectionEndpoint": "[[parameters('dcrConfig').dataCollectionEndpoint]", "dataCollectionRuleImmutableId": "[[parameters('dcrConfig').dataCollectionRuleImmutableId]" },
  "dataType": "[variables('dataType')]",
  "auth": { "serviceAccountEmail": "[[parameters('GCPServiceAccountEmail')]", "projectNumber": "[[parameters('GCPProjectNumber')]", "workloadIdentityProviderId": "[[parameters('GCPWorkloadIdentityProviderId')]" },
  "request": { "projectId": "[[parameters('GCPProjectId')]", "subscriptionNames": [ "[[parameters('GCPSubscriptionName')]" ] }
} }
```

## Azure Storage Blob connection rule (`kind: StorageAccountBlobContainer`)
Author **table** + **DCR** only. Auth is `{ "type": "ServicePrincipal" }` — relies on a
Microsoft multitenant app (AzureCloud appId `4f05ce56-95b6-4612-9d98-a45c8cc33f9f`); tenant admin
must consent and the ARM template assigns blob-read + queue-contribute roles. Start from
`DataConnectors/Templates/Connector_StorageBlob_CCF_template.json`.
```json
{ "kind": "StorageAccountBlobContainer", "properties": {
  "connectorDefinitionName": "[[parameters('connectorDefinitionName')]",
  "dcrConfig": { "streamName": "[variables('streamName')]", "dataCollectionEndpoint": "[[parameters('dcrConfig').dataCollectionEndpoint]", "dataCollectionRuleImmutableId": "[[parameters('dcrConfig').dataCollectionRuleImmutableId]" },
  "auth": { "type": "ServicePrincipal" },
  "request": {
    "QueueUri": "[[concat('https://', variables('storageAccountName'), '.queue.core.windows.net/', variables('queueName'))]",
    "DlqUri":   "[[concat('https://', variables('storageAccountName'), '.queue.core.windows.net/', variables('dlqName'))]"
  },
  "response": { "EventsJsonPaths": [ "$" ], "format": "json" }
} }
```
`response.format` may be `json`/`csv`/`xml`/`parquet`.

---

## Push CCF connector (`kind: Push`) — preview
Event-driven: **your app POSTs to the DCE**; no polling endpoint to host. Deployment auto-creates an
Entra app (+ secret), DCR, DCE, custom table, and role assignments; the UI then surfaces Tenant ID /
App ID / Secret / DCE URI / DCR immutable ID / Stream name for the sender to configure.

Four artifacts in `Data Connectors/<Name>_ccf/`: `table.json`, `DCR.json`, `connectorDefinition.json`,
`dataConnector.json`. Table apiVersion `2025-07-01`; DCR stream `Custom-<Name>`, output `Custom-<Name>_CL`.
- Connector definition: `kind: Customizable`, button `DeployPushConnectorButton`,
  `connectivityCriteria: IsConnectedQuery`, `CopyableLabel`s with `fillWith` for the credentials.
- Data connector (`dataConnector.json`):
```json
{
  "name": "MyPushConnector", "apiVersion": "2024-09-01",
  "type": "Microsoft.SecurityInsights/dataConnectors", "kind": "Push",
  "properties": {
    "connectorDefinitionName": "MyPushDefinitionId",
    "dcrConfig": { "streamName": "Custom-MyStream", "dataCollectionEndpoint": "[[parameters('dcrConfig').dataCollectionEndpoint]", "dataCollectionRuleImmutableId": "[[parameters('dcrConfig').dataCollectionRuleImmutableId]" },
    "auth": { "type": "Push", "AppId": "[[parameters('auth').appId]", "ServicePrincipalId": "[[parameters('auth').servicePrincipalId]" },
    "request": { "RetryCount": 1 },
    "response": { "eventsJsonPaths": [ "$" ] }
  }
}
```
Sender flow: get OAuth2 token (`scope=https://monitor.azure.com//.default`, client_credentials) →
`POST {dce}/dataCollectionRules/{immutableId}/streams/{streamName}?api-version=2023-01-01` with the
JSON event array. Requires Entra app-registration + secret permission, and Monitoring Metrics
Publisher on the DCR. **Never hardcode the secret** in the sender — Key Vault / managed identity / env.

---

## Solution folder + packaging
Standard layout (no spaces in folder name):
```
Solutions/<SolutionName>/
├── Data/Solution_<SolutionName>.json     # Name (==folder), Author, Logo(svg), Data Connectors[], BasePath(abs), Version, Metadata, TemplateSpec:true, Is1PConnector:false
├── SolutionMetadata.json                 # at root: publisherId, offerId, firstPublishDate, providers, categories, support
├── ReleaseNotes.md
└── Data Connectors/<Name>_ccf/           # the component JSONs (definition + poller/table/DCR)
```
- `publisherId`/`offerId` must match between the two metadata files; real values, not placeholders (see **sentinel-packaging**).
- Package: `Tools/Create-Azure-Sentinel-Solution/V3/createSolutionV3.ps1` → emits `Package/mainTemplate.json` (+ createUiDefinition.json, testParameters.json). Solution version ≥ `3.0.0`.

## Manual ARM template structure (the 5 resources)
If hand-assembling `mainTemplate.json` instead of using the packager, the `resources` array holds 5
deployment resources wrapping the 4 components:
1. **contentTemplates** (parent, `contentKind: DataConnector`) → `mainTemplate` with: `metadata`, **dataCollectionRules**, **tables**.
2. **dataConnectorDefinitions** (`kind: Customizable`) — the UI (Component 3).
3. **metadata** (`kind: DataConnector`).
4. **contentTemplates** (`contentKind: ResourcesDataConnector`) → `mainTemplate` with params
   (`connectorDefinitionName`, `workspace`, `dcrConfig`, + your secret params), `metadata`, and the
   **RestApiPoller/Push/GCP/Storage** connection rule (Component 4).
5. **contentPackages** (`kind: Solution`).

Recommended template params: `location` (default `[resourceGroup().location]`, kept only to satisfy
arm-ttk `Location-Should-Not-Be-Hardcoded` — use `workspace-location` for real placement),
`workspace-location`, `subscription`, `resourceGroupName`, `workspace`. Useful vars:
`workspaceResourceId`, `_solutionId`, `_solutionVersion`(≥3.0.0), `_solutionTier`("Community" for
custom), the per-component contentIds/template names, `_logAnalyticsTableId1`.

## Secure confidential input (recap)
1. **Prompt:** add an input control (`Textbox`/`OAuthForm`) in the connector definition `instructions`.
2. **Store:** declare the matching ARM param as `securestring` (e.g. `Password`, `apikey`).
3. **Use:** reference it in `auth` with the escaped `[[parameters('...')]` syntax — the value never
   persists readably in deployment history.

## Deploy & verify
1. Delete any test DCR/custom table you created manually first (the deploy recreates them — cleaner verify).
2. Deploy `mainTemplate.json` as a custom template (Azure portal → *Deploy a custom template* → *Build your own template* → load file).
3. Open the connector in the Sentinel **data connector gallery**, enter credentials, **Connect** — this creates the DCR + custom table.
4. Confirm the DCR resource exists in the resource group and the `_CL` table in the workspace.
5. **Data can take up to ~30 min** to start ingesting (push: 5–10 min). Validate with
   `verify_table_ingestion(<Table>_CL)` / a KQL `summarize max(TimeGenerated)`.
- **Network isolation:** if the source must allowlist callers, the CCF egress service tag is **`Scuba`** (resolve current IPs via the Service Tag Discovery API).

## Time windows & checkpointing (read before promising historical backfill)
- The query window is **fixed-size**: `{_QueryWindowEndTime}` = `{_QueryWindowStartTime}` +
  `queryWindowInMin` (never "start → now"). `queryWindowInMin` is the only time knob — there is no
  separate trigger/recurrence interval, and windows can't vary per-poll. The checkpoint advances
  `next.start = prev.end` automatically and can't be read/edited; clear it only by disconnecting.
- **`InitialCheckpointTimeUtc` is silently ignored unless ALL hold:** (1) no checkpoint persisted yet
  (gone after the first poll / any prior connect — disconnect to re-test); (2) a start-time anchor
  with **no** end-time param (adding `{_QueryWindowEndTime}-`/`EndTimeAttributeName` disables it);
  (3) the connector is **not** cursor/token-paginated. **#3 is the killer** — for any cursor-paged API
  (most TI APIs) the user start time is ignored and poll 1 defaults to a ~1h look-back.
- **Cursor/token APIs cannot do BOTH custom-start backfill AND auto-advancing polls in CCF:**
  - *Live feed:* `{_QueryWindowStartTime}+ {_QueryWindowEndTime}-` token window → poll 1 starts ~1h ago
    (can't seed it), poll 2+ advance cleanly. ✅ live, ❌ backfill.
  - *Custom-start:* seed the start into a real param (e.g. epoch in `filter` via `concat`) +
    `pagingType: PersistentToken` (Vectra's pattern). Works only if the API returns a **resumable
    token even with no new data** (Vectra `next_checkpoint` does; many cursor APIs return none at
    end-of-data → every later poll re-pulls from the fixed start → duplicates). Plain
    `NextPageToken`/`LinkHeader` cursors are NOT persisted across runs.
  - No "run once then stop" mode exists (`isActive` is static).
  - **Resolution:** one-time **backfill script** → Logs Ingestion API (DCE/DCR) for history +
    CCF in token-window mode for live. Dedup at read time: `summarize arg_max(TimeGenerated, *) by Id`.
- **Diagnose start-time from DATA, not the URL:** the connectivity-check probe always uses a now/look-back
  window and never consults `InitialCheckpointTimeUtc`. Confirm with `<Table>_CL | summarize min(<ts>)`.

## Common gotchas
- Missing the **double-`[[`** escape on parameters → params resolve at compile time and break the connector.
- **`[[parameters('x')]` only resolves as the ENTIRE value of a field.** Embedded in a longer literal
  it's sent verbatim (`%5B%5Bparameters...` in the URL). Wrap the whole value in one ARM expression:
  `"[[concat('...prefix ', parameters('x'))]"`.
- **The packager (`createCCPConnector.ps1`) sets each UI Textbox param's `defaultValue` to the param
  NAME** — at deploy the connectivity check uses these (placeholder filter → 400, default `apiKey` →
  401). For an **optional** textbox add `"validations": { "required": false }` → packager emits
  `defaultValue: ""`. `Package/mainTemplate.json` is **regenerated** — fix source, not the package.
- **arm-ttk "Template Should Not Contain Blanks":** empty `""` in a resource body (e.g.
  `"ApiKeyIdentifier": ""`) → omit the property. (Empty `defaultValue:""` on a *parameter* is fine.)
- **APIKey with no prefix** (e.g. `x-apikey: <key>`): set `ApiKeyName`, **omit** `ApiKeyIdentifier`
  (default `token` wrongly yields `<header>: token <key>`; don't set `""` — arm-ttk blank rule).
- **DCR `transformKql` is a restricted KQL subset** — no `unixtime_seconds_todatetime()`. Convert
  epochs with `datetime(1970-01-01) + tolong(x) * 1s`.
- **`StartTimeAttributeName` requires `EndTimeAttributeName`** (which disables `InitialCheckpointTimeUtc`),
  and both emit *separate* params — useless for APIs needing the time inside one combined filter string.
- `streamName` in `dcrConfig` ≠ a `Custom-`-prefixed key in `streamDeclarations` → no ingestion.
- `outputStream` not matching `Custom-<Table>_CL` (or a valid `Microsoft-<StandardTable>`) → drops/errors.
- Table name missing `_CL`, or no `TimeGenerated` column.
- `connectorDefinitionName` (connection rule) ≠ connector definition `id`.
- Choosing a paging type the API doesn't actually support (verify against the response shape).
- For **Push**: arm-ttk failure is expected; don't "fix" it — confirm the 3 valid-JSON messages instead.
