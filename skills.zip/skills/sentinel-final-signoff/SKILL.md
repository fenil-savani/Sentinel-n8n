---
name: sentinel-final-signoff
description: Master release gate for an Azure Sentinel solution — run as the last step before
  any PR, release, or milestone. Runs the full MCP check suite, enforces the 15 critical
  items, the live-data checks, and the 5 required sign-offs, then routes every FAIL to its
  domain fix skill. Nothing ships until all FAILs are 0, all 15 critical items PASS, and all
  required sign-offs are obtained. Trigger: "final sign-off", "release gate", "ready to ship?".
---

# sentinel-final-signoff

Master gate. No release proceeds until FAILs = 0, all 15 critical items PASS, and all required
sign-offs are obtained.

## Step 1 — Run the full suite (MCP)
`run_all_checks(<solution>, include_slow=True)`. Then `verify_table_ingestion` /
`verify_connector_status` if a workspace is configured. Any FAIL ⇒ BLOCKED.

## Step 2 — 15 critical items
| # | Item | Expected |
|---|------|----------|
| 1 | Python 3.12 in ARM | `"PYTHON_VERSION":"3.12"` + `linuxFxVersion: Python\|3.12` |
| 2 | HTTP Data Collector API removed | no `ods.opinsights.azure.com`/`WorkspaceKey`/shared-key in `*.py` |
| 3 | Reserved keywords renamed | `project-rename` DetectionType/EventTime/EventTitle in parser + DCR |
| 4 | No hardcoded creds in ARM | no literal password/secret/apikey in mainTemplate.json |
| 5 | Timer stops at 570s | `570`/`MAX_EXECUTION_SECONDS`/`is_timeout_approaching` in `*.py` |
| 6 | Ingestion chunking (30MB) | `chunk`/`30*1024*1024`/`MAX_PAYLOAD` present |
| 7 | Analytics rule UUID unchanged | `git diff HEAD~1 "Analytic Rules/"` shows no `id:` change |
| 8 | Playbook secrets secureString | `"type":"secureString"` in `Playbooks/*.json` |
| 9 | Workbook parameters empty | no stored `value`/`durationMs` in `Workbooks/*.json` |
| 10 | Gov Cloud .us support | `AZURE_GOVERNMENT`/`usgovcloudapi`/`AzureAuthorityHosts` in `*.py` |
| 11 | KQL schema files present | `.scripts/tests/kqlvalidationtests/CustomTables/*.json` exist |
| 12 | Connector ID in ValidConnectorIds.json | rule `connectorId` present |
| 13 | Publisher/Offer ID real | not empty/placeholder in solutionMetadata.json |
| 14 | Connector UI status query | `IsConnectedQuery`/`lastDataReceivedQuery` in `Data Connectors/*.json` |
| 15 | aka.ms short URLs mapped | commercial + Gov URLs return HTTP 200 |

## Step 3 — Live-data checks (workspace)
```kql
<Table>_CL | where TimeGenerated > ago(1h) | summarize Count=count()                 // FAIL if 0
<Table>_CL | summarize Last=max(TimeGenerated) | project IsConnected = Last > ago(30d) // FAIL if false
<Table>_CL | take 1 | getschema | where ColumnName in ("type","time","title")          // FAIL if any rows
```
```bash
grep -rn "checkpoint\|upsert_entity\|save_checkpoint" . --include="*.py"     # FAIL if none
grep -rn "570\|MAX_EXECUTION_SECONDS\|is_timeout_approaching" . --include="*.py"
```

## Step 4 — 5 required sign-offs
Development Lead · QA Lead (+ QAC email) · Security Reviewer · Product Owner · Customer/Stakeholder.
Each signs APPROVED or BLOCKED:[reason] with name + date. Missing any ⇒ FAIL.

## Step 5 — Remediation routing (FAIL → domain skill)
| FAIL area | Skill |
|---|---|
| Python connector, ARM, DCR, secureString, UI page, ingestion, Gov Cloud, timeout, chunking | **sentinel-data-connector** |
| Custom parser KQL, optional fields, union empty table, reserved keywords, parser YAML UUID/version | **sentinel-custom-parser** |
| ASIM normalized parsers (ASim/im/vim), normalization fields, schema testers | **sentinel-asim-parser** |
| Analytics rules, MITRE, UUID changed, connector ID | **sentinel-analytics-rules** |
| Playbook JSON, Key Vault, User-Agent, _URL block names | **sentinel-playbook** |
| Workbook panels, parameters, preview images | **sentinel-workbook** |
| Solution package, logo, publisher/offer ID, sample data, KQL schemas | **sentinel-packaging** |
| Setup, tests/coverage/flake8/bandit/QAC, PR/CI, docs, rollback/monitoring/release, Jira/Confluence | **sentinel-process-ops** |

Rule: any module with FAILs = BLOCKED. Apply the matching skill, re-run `run_all_checks`, repeat.
WARNs acceptable only if documented with justification.
