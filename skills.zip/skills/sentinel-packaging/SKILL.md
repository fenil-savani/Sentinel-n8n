---
name: sentinel-packaging
description: Fix Azure Sentinel solution metadata and packaging issues — folder structure,
  solutionMetadata.json (real publisherId/offerId, not placeholders), logo SVG (<500KB, no
  xlink:href), sample CSV, KQL custom-table schema JSON, ValidConnectorIds.json, and running
  createSolutionV3.ps1. Use when an MCP check (check_packaging, check_solution_metadata,
  check_logo, check_sample_data) fails or when assembling the solution package.
---

# sentinel-packaging

Remediation for solution metadata + packaging.

## Verify first (MCP)
Run `run_one_check("check_packaging", <solution>)`, `run_one_check("check_solution_metadata", <solution>)`,
`run_one_check("check_logo", <solution>)`, `run_one_check("check_sample_data", <solution>)`,
and `run_one_check("check_arm_ttk", <solution>)` (validates the generated Package templates).

## Package creation — end to end
Reference: https://github.com/Azure/Azure-Sentinel/tree/master/Tools/Create-Azure-Sentinel-Solution

### Prerequisites
- **PowerShell 7.1+** (upgrade from 5.1 if needed), **Node.js**, and `Install-Module powershell-yaml`.
- VSCode + **Azure Resource Manager (ARM) Tools** extension (language support + template validation).

### Required solution layout (`Solutions/<SolutionName>/`)
- Component folders: **Analytic Rules, Playbooks, Workbooks, Data Connectors, Release Notes, Data** (+ Logos).
- **`Data/`** folder contains: **`SolutionMetadata.json`** and **`Solution_<Name>.json`** (e.g. `Solution_Infobloxv2.json`).
- The Function App UI page (e.g. `Infoblox_API_FunctionApp.json`) lives under the Data Connector folder.
- `Solution_<Name>.json` lists the **paths of all components**, plus `Name`, `Author`, **logo URL (GitHub master branch)**, `Description` (ask client), `BasePath`, `Version`, and `Metadata: SolutionMetadata.json`.
- **`Data/` and `Package/` must stay inside the solution folder** (never outside).

### Run (PowerShell 7, from the Azure-Sentinel repo root)
```powershell
.\Tools\Create-Azure-Sentinel-Solution\V3\createSolutionV3.ps1
# When prompted, give the path to Solution_<Name>.json, e.g.
#   ...\Azure-Sentinel\Solutions\Infoblox\Data
```

### Ask the client (collect before packaging)
- **publisherId** and **offerId** — *critical*, real values (not placeholders).
- **Logo** (SVG) + its size/format limitations.
- Solution **Description**.

### Component-specific package items
- **Data Connector**: a **zip**, the **UI page JSON**, and the **ARM template** must be present.
- **Workbook metadata** (see **sentinel-workbook**): key, logo, **dataTypeDependencies** (all tables used),
  **dataConnectorDependencies** (connector id from the UI page), **previewImagesFileNames** (Black + White),
  title, template relative path, workbook name, provider, and a **globally-unique `fromTemplateId`**.
- **Sample data**: `Sample Data/Custom/` with all sample CSVs.
- **Schemas**: `.script/tests/kqlvalidationtests/CustomTables/` — add every custom table schema.
- **Analytic rule connector ids**: `.script/tests/detectiontemplateschemavalidation/ValidConnectorIds.json` — add ids from the rule YAMLs.
- **Logos**: add the SVG (ref: https://github.com/Azure/Azure-Sentinel/tree/master/DataConnectors).
- **Package**: the Function App UI page's deploy link must be a proper `aka.ms` URL (e.g. `https://aka.ms/sentinel-<Name>-azuredeploy`).
- **Release Notes**: present and current.

> **Automation:** where applicable, build an automation script (like **Vectra** / **Dataminr**) that
> auto-completes all deployment/packaging steps. Internal reference (Notion): the team's
> "Steps to create package" page.

## Packaging fixes
### Folder structure
```powershell
$solution = "Solutions/<SolutionName>"
"Data Connectors","Analytic Rules","Playbooks","Workbooks","Release Notes","Logos" |
  ForEach-Object { New-Item -ItemType Directory -Path "$solution/$_" -Force | Out-Null }
```
### solutionMetadata.json — `publisherId`/`offerId` must be real (no TODO/TBD/xxx/your/<)
```json
{ "publisherId": "<from-microsoft>", "offerId": "<from-microsoft>",
  "firstPublishDate": "2026-05-22", "lastPublishDate": "2026-05-22",
  "providers": ["<SolutionName>"],
  "categories": { "domains": ["Security - Threat Protection"], "verticals": [] },
  "icon": "https://raw.githubusercontent.com/Azure/Azure-Sentinel/master/Solutions/<SolutionName>/Logos/<SolutionName>.svg" }
```
Get IDs from Partner Center → Marketplace offers → your offer → Overview.
### Logo SVG (<500KB)
`Logos/<SolutionName>.svg`, ≤500KB. Remove `xmlns:xlink`, replace `xlink:href`→`href`. Reference via raw GitHub master URL (valid after merge).
### Sample CSV — `Sample Data/Custom/<TableName>_CL.csv`, ≥5 rows, all schema fields, realistic, no PII.
### KQL schema — `.scripts/tests/kqlvalidationtests/CustomTables/<TableName>_CL.json`
```json
{ "Name": "<TableName>_CL", "Properties": { "Schema": { "Name": "<TableName>_CL", "Columns": [
    {"Name":"TimeGenerated","Type":"DateTime"}, {"Name":"DetectionType","Type":"String"},
    {"Name":"SourceIpAddress","Type":"String"}, {"Name":"Severity","Type":"String"},
    {"Name":"RawData","Type":"Dynamic"}, {"Name":"Type","Type":"String"} ] } } }
```
### ValidConnectorIds.json — append connector id (sorted, unique) to
`.scripts/tests/detectiontemplateschemavalidation/ValidConnectorIds.json`.
### createSolutionV3.ps1 (PowerShell 7)
```powershell
cd Solutions
..\Tools\Create-Azure-Sentinel-Solution\V3\createSolutionV3.ps1
# prompt: Solutions/<SolutionName>/solution_<SolutionName>.json
```
| Error | Fix |
|---|---|
| File not found | fix relative path in `solution_<Name>.json` |
| Invalid JSON | `python -m json.tool <file>` |
| UUID already exists | remove duplicate analytic-rule UUID |
| Missing required field | add to solutionMetadata.json / component YAML |
