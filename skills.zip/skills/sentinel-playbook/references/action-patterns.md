# Action Patterns Reference

> Parent skill: [sentinel-playbooks](../SKILL.md)

Production-validated patterns for every action type encountered in Sentinel playbooks. Copy and adapt these — do not invent new patterns.

---

## Failure Path — Terminate as Failed

### When to use

Add a `Terminate` (status `Failed`) whenever an action fails and continuing the playbook would be meaningless or misleading. Without it, Logic Apps marks the run as `Succeeded` even when a critical action failed — the run history will show green but nothing actually happened.

Common cases:
- An HTTP call to a third-party API fails (auth error, 4xx/5xx response)
- A Key Vault secret fetch fails
- A required parse or prerequisite check fails

### Pattern

The action that fails is followed by one or more cleanup/notification actions (optional), then a `Terminate`. The pattern is:

```json
"<Notification_or_Cleanup_Action>": {
  "runAfter": { "<Failed_Action>": ["Failed", "TimedOut"] },
  "type": "<whatever is appropriate — Http, ApiConnection, Compose, etc.>",
  "inputs": { }
},
"Terminate_-_<FailureName>": {
  "runAfter": { "<Notification_or_Cleanup_Action>": ["Succeeded", "Failed"] },
  "type": "Terminate",
  "inputs": {
    "runStatus": "Failed",
    "runError": {
      "code": "<ShortErrorCode>",
      "message": "<Descriptive message — include relevant dynamic values such as status codes or IDs>"
    }
  }
}
```

If there is no cleanup/notification action before the Terminate, wire it directly to the failed action:

```json
"Terminate_-_<FailureName>": {
  "runAfter": { "<Failed_Action>": ["Failed", "TimedOut"] },
  "type": "Terminate",
  "inputs": {
    "runStatus": "Failed",
    "runError": {
      "code": "<ShortErrorCode>",
      "message": "<Descriptive message>"
    }
  }
}
```

### runAfter discipline — critical rule

The `Terminate`'s `runAfter` must list **only the statuses under which its preceding action actually ran**.

- If the preceding action is a notification/cleanup that runs only on failure: wire it to `["Failed", "TimedOut"]` on the upstream action, then wire Terminate to `["Succeeded", "Failed"]` on the notification. This ensures:
  - `"Succeeded"` — notification posted; Terminate ends the run as Failed
  - `"Failed"` — notification itself failed; Terminate still ends the run as Failed
- **Never include `"Skipped"`** in a Terminate's `runAfter` when the preceding action can be skipped on the success path. If `"Skipped"` is listed, the Terminate fires even when everything succeeded (because the error-path action was skipped), marking successful runs as Failed.

### Success path is unaffected

The Terminate and its preceding notification are siblings of the success-path actions — they do not replace them. On the success path the failure-path actions are skipped and the Terminate never runs.

---

## InitializeVariable — Placement Rule

`InitializeVariable` actions **must** be placed at the **top-level `actions` block** of the workflow definition, before any `Condition`, `Foreach`, `Until`, or `Switch`. Logic Apps enforces this at the engine level — placing them inside any branching or looping construct causes an `InvalidVariableInitialization` deployment error.

**Correct structure:**
```json
"actions": {
  "Initialize_variable_-_MyVar": {
    "runAfter": {},
    "type": "InitializeVariable",
    "inputs": { "variables": [{ "name": "MyVar", "type": "array", "value": [] }] }
  },
  "Condition_-_Check_Something": {
    "runAfter": { "Initialize_variable_-_MyVar": ["Succeeded"] },
    "type": "If",
    "expression": { }
  }
}
```

**Wrong — causes `InvalidVariableInitialization` at deploy:**
```json
"Condition_-_Check_Something": {
  "runAfter": {},
  "type": "If",
  "actions": {
    "Initialize_variable_-_MyVar": { }
  }
}
```

---

## Key Vault Secret Fetch — Third-Party Credentials

Never accept third-party API keys, client IDs, or client secrets as ARM parameters. Always store them in Key Vault and fetch at runtime via `Get_Secret` actions. This applies to every integration requiring credentials.

**Determine the correct Key Vault secret names** by declaring them as plain `string` ARM parameters (the names are not sensitive — only the values are). The values never appear in the template.

**Pattern — fetch two secrets then use them:**

```json
"Get_Secret_-_ClientId": {
  "runAfter": {},
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['keyvault']['connectionId']" } },
    "method": "get",
    "path": "@{concat('/secrets/', encodeURIComponent(parameters('ClientIdSecretName')), '/value')}"
  }
},
"Get_Secret_-_ClientSecret": {
  "runAfter": { "Get_Secret_-_ClientId": ["Succeeded"] },
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['keyvault']['connectionId']" } },
    "method": "get",
    "path": "@{concat('/secrets/', encodeURIComponent(parameters('ClientSecretSecretName')), '/value')}"
  }
}
```

Access the value downstream: `@body('Get_Secret_-_ClientId')?['value']`

**ARM parameters (secret names only — never the credential values):**
```json
"ClientIdSecretName": {
  "type": "string",
  "metadata": { "description": "Name of the Key Vault secret containing the client_id." }
},
"ClientSecretSecretName": {
  "type": "string",
  "metadata": { "description": "Name of the Key Vault secret containing the client_secret." }
}
```

**Required post-deployment step:** Grant the Logic App MSI the `Key Vault Secrets User` role on the Key Vault.

---

## Alert Custom Details Extraction

Custom Details are key-value pairs from the Sentinel Analytics Rule. They live **per alert** inside `properties.additionalData['Custom Details']` as a JSON-encoded string. The correct pattern is a two-level loop: outer loop over alerts, inner ParseJson + access.

> **Do NOT** try to read custom details from `triggerBody()?['object']?['properties']?['additionalData']`. That path does not contain analytics rule custom details — it is for entity-level fields only (e.g. `MdatpDeviceId` on Host entities). Accessing it returns null and causes ParseJson to fail with "Required property 'content' expects a value but got null".

```json
"For_each_-_Alert": {
  "runAfter": { "<previous_action>": ["Succeeded"] },
  "type": "Foreach",
  "foreach": "@triggerBody()?['object']?['properties']?['alerts']",
  "runtimeConfiguration": { "concurrency": { "repetitions": 1 } },
  "actions": {
    "Parse_JSON_-_Alert_Custom_Details": {
      "runAfter": {},
      "type": "ParseJson",
      "inputs": {
        "content": "@items('For_each_-_Alert')?['properties']?['additionalData']?['Custom Details']",
        "schema": {
          "type": "object",
          "properties": {
            "<your_custom_key>": {
              "type": "array",
              "items": { "type": "string" }
            }
          }
        }
      }
    },
    "For_each_-_Custom_Detail_Values": {
      "runAfter": { "Parse_JSON_-_Alert_Custom_Details": ["Succeeded"] },
      "type": "Foreach",
      "foreach": "@body('Parse_JSON_-_Alert_Custom_Details')?['<your_custom_key>']",
      "runtimeConfiguration": { "concurrency": { "repetitions": 1 } },
      "actions": {
        "Use_Custom_Detail_Value": {
          "runAfter": {},
          "type": "AppendToArrayVariable",
          "inputs": {
            "name": "<your_variable>",
            "value": "@items('For_each_-_Custom_Detail_Values')"
          }
        }
      }
    }
  }
}
```

**Key points:**
- `alerts` is already a parsed array — do not ParseJson the outer array itself.
- `Custom Details` inside `additionalData` IS a JSON string — always ParseJson it.
- Each custom detail value is an **array** of strings (even when only one value exists).
- To get a single value: `body('Parse_JSON_-_Alert_Custom_Details')?['<key>'][0]`
- Convert string values to integers where needed: `int(items('...'))`
- The `ParseJson` schema only needs to declare the keys you actually use.

---

## Entity Extraction Patterns

### Get All Account Entities

```json
"Entities_-_Get_Accounts": {
  "runAfter": {},
  "type": "ApiConnection",
  "inputs": {
    "body": "@triggerBody()?['object']?['properties']?['relatedEntities']",
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post",
    "path": "/entities/account"
  }
}
```
Loop input: `@body('Entities_-_Get_Accounts')?['Accounts']`  
Item fields: `items('For_each')?['accountName']`, `items('For_each')?['AadUserId']`, `items('For_each')?['upnSuffix']`

### Get Host Entities

```json
"Entities_-_Get_Hosts": {
  "runAfter": {},
  "type": "ApiConnection",
  "inputs": {
    "body": "@triggerBody()?['object']?['properties']?['relatedEntities']",
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post",
    "path": "/entities/host"
  }
}
```
Loop input: `@body('Entities_-_Get_Hosts')?['Hosts']`  
Item fields: `items('For_each')?['HostName']`, `items('For_each')?['additionalData']?['MdatpDeviceId']`

### Get IP Entities with RFC1918 Filtering

Filter out private IPs before calling external enrichment APIs:

```json
"Filter_IPs_Only": {
  "runAfter": {},
  "type": "Query",
  "inputs": {
    "from": "@array(triggerBody()?['object']?['properties']?['relatedEntities'])",
    "where": "@equals(item()?['kind'], 'Ip')"
  }
},
"Initialize_variable_PublicIPEntities": {
  "runAfter": { "Filter_IPs_Only": ["Succeeded"] },
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "PublicIPEntities", "type": "array", "value": [] }] }
},
"For_each_IP_Entity_RFC1918": {
  "foreach": "@body('Filter_IPs_Only')",
  "runAfter": { "Initialize_variable_PublicIPEntities": ["Succeeded"] },
  "type": "Foreach",
  "actions": {
    "KQLRFC1918Check": {
      "runAfter": {},
      "type": "ApiConnection",
      "inputs": {
        "body": "datatable(ip_string:string) [\"@{items('For_each_IP_Entity_RFC1918')?['properties']?['address']}\"]\n| extend result = ipv4_is_private(ip_string)",
        "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
        "method": "post",
        "path": "/queryData",
        "queries": {
          "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
          "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
          "resourcetype": "Log Analytics Workspace",
          "resourcename": "[parameters('WorkspaceName')]",
          "timerange": "Last 24 hours"
        }
      }
    },
    "Condition_RFC1918": {
      "runAfter": { "KQLRFC1918Check": ["Succeeded"] },
      "type": "If",
      "expression": {
        "and": [{ "equals": ["@body('KQLRFC1918Check')?['value'][0]?['result']", true] }]
      },
      "actions": {},
      "else": {
        "actions": {
          "Append_to_array_variable": {
            "runAfter": {},
            "type": "AppendToArrayVariable",
            "inputs": {
              "name": "PublicIPEntities",
              "value": "@items('For_each_IP_Entity_RFC1918')?['properties']?['address']"
            }
          }
        }
      }
    }
  }
}
```

Then loop over `@variables('PublicIPEntities')` for enrichment.

---

## Incident Update Patterns

### Add Comment

```json
"Add_comment_to_incident_(V3)": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "message": "<p><strong>Action completed</strong><br>@{variables('ResultSummary')}</p>"
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post",
    "path": "/Incidents/Comment"
  }
}
```

### Update Severity + Tag

```json
"Update_incident": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "severity": "High",
      "tagsToAdd": {
        "TagsToAdd": [{ "Tag": "AutoEscalated" }]
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "put",
    "path": "/Incidents"
  }
}
```

### Close Incident

```json
"Close_incident": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "status": "Closed",
      "classification": {
        "ClassificationAndReason": "FalsePositive - IncorrectAlertLogic",
        "ClassificationReasonText": "Verified as false positive by automated enrichment"
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "put",
    "path": "/Incidents"
  }
}
```

Classification options: `TruePositive - SuspiciousActivity`, `FalsePositive - IncorrectAlertLogic`, `FalsePositive - InaccurateData`, `BenignPositive - SuspiciousButExpected`

---

## OAuth2 Client Credentials Pattern

Full sequence for calling APIs that require App Registration auth (MDE, Graph, custom):

```json
"Get_Client_Secret": {
  "runAfter": { "Entities_-_Get_Hosts": ["Succeeded"] },
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['keyvault']['connectionId']" } },
    "method": "get",
    "path": "[concat('/secrets/@{encodeURIComponent(''', parameters('KeyVaultSecretName'), ''')}/value')]"
  }
},
"Initialize_variable_-_Result": {
  "runAfter": { "Get_Client_Secret": ["Succeeded"] },
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "Result", "type": "string", "value": "" }] }
},
"HTTP_-_Authenticate": {
  "runAfter": { "Initialize_variable_-_Result": ["Succeeded"] },
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[concat('https://login.microsoftonline.com/', subscription().tenantId, '/oauth2/v2.0/token')]",
    "headers": {
      "Content-Type": "application/x-www-form-urlencoded",
      "Host": "login.microsoftonline.com"
    },
    "body": "[concat('grant_type=client_credentials&client_id=', parameters('ClientId'), '&client_secret=@{body(''Get_Client_Secret'')?[''value'']}&scope=https://api.securitycenter.microsoft.com/.default')]"
  }
},
"Parse_JSON_-_Token": {
  "runAfter": { "HTTP_-_Authenticate": ["Succeeded"] },
  "type": "ParseJson",
  "inputs": {
    "content": "@body('HTTP_-_Authenticate')",
    "schema": {
      "properties": {
        "access_token": { "type": "string" },
        "expires_in": { "type": "integer" },
        "ext_expires_in": { "type": "integer" },
        "token_type": { "type": "string" }
      },
      "type": "object"
    }
  }
}
```

Use `@body('Parse_JSON_-_Token')?['access_token']` in all downstream HTTP action `Authorization` headers.

**Scope by API:**
- MDE Security Center: `https://api.securitycenter.microsoft.com/.default`
- Microsoft Graph: `https://graph.microsoft.com/.default`
- Azure Management: `https://management.azure.com/.default`

---

## Condition Patterns

### Severity-Based Branching

```json
"Condition_-_Check_Severity": {
  "type": "If",
  "expression": {
    "and": [{ "equals": ["@triggerBody()?['object']?['properties']?['severity']", "High"] }]
  },
  "actions": {
    "Escalate_Action": { /* ... */ }
  },
  "else": {
    "actions": {
      "Standard_Action": { /* ... */ }
    }
  }
}
```

### Check if String Variable is Non-Empty

```json
"Condition_-_Check_Results_Exist": {
  "type": "If",
  "expression": {
    "and": [{ "greater": ["@length(variables('ResultSummary'))", 0] }]
  },
  "actions": { /* send notification if results exist */ },
  "else": { "actions": {} }
}
```

### Check HTTP Response Status

```json
"Condition_-_HTTP_Success": {
  "type": "If",
  "expression": {
    "and": [{ "equals": ["@outputs('HTTP_-_API_Call')['statusCode']", 200] }]
  },
  "actions": { /* process success */ },
  "else": { "actions": { /* handle failure */ } }
}
```

### Check if Entity Field is Not Null

```json
"Condition_-_Check_for_MDE_Device_ID": {
  "type": "If",
  "expression": {
    "and": [{
      "not": {
        "equals": ["@items('For_each')?['additionalData']?['MdatpDeviceId']", ""]
      }
    }]
  },
  "actions": { /* proceed if device ID found */ },
  "else": {
    "actions": {
      "Append_not_found": {
        "type": "AppendToStringVariable",
        "inputs": {
          "name": "ResultSummary",
          "value": "No MDE Device ID found for @{items('For_each')?['HostName']}\n"
        }
      }
    }
  }
}
```

### Multi-Case Switch (Severity Color Mapping)

```json
"Switch_-_Severity": {
  "type": "Switch",
  "expression": "@triggerBody()?['object']?['properties']?['severity']",
  "cases": {
    "High": {
      "case": "High",
      "actions": {
        "Set_variable_High": {
          "type": "SetVariable",
          "inputs": { "name": "SeverityColor", "value": "#b32400" }
        }
      }
    },
    "Medium": {
      "case": "Medium",
      "actions": {
        "Set_variable_Medium": {
          "type": "SetVariable",
          "inputs": { "name": "SeverityColor", "value": "#ff6600" }
        }
      }
    },
    "Low": {
      "case": "Low",
      "actions": {
        "Set_variable_Low": {
          "type": "SetVariable",
          "inputs": { "name": "SeverityColor", "value": "#ffcc00" }
        }
      }
    },
    "Informational": {
      "case": "Informational",
      "actions": {
        "Set_variable_Info": {
          "type": "SetVariable",
          "inputs": { "name": "SeverityColor", "value": "#a6a6a6" }
        }
      }
    }
  },
  "default": { "actions": {} }
}
```

---

## Loop Patterns

### Foreach with Sequential Execution

When actions inside the loop write to shared variables, force sequential execution:

```json
"For_each_IP": {
  "type": "Foreach",
  "foreach": "@variables('PublicIPEntities')",
  "runtimeConfiguration": { "concurrency": { "repetitions": 1 } },
  "actions": {
    "HTTP_-_Enrich_IP": {
      "type": "Http",
      "inputs": {
        "method": "GET",
        "uri": "https://api.example.com/ip/@{items('For_each_IP')}"
      }
    },
    "Append_to_string_variable": {
      "runAfter": { "HTTP_-_Enrich_IP": ["Succeeded"] },
      "type": "AppendToStringVariable",
      "inputs": {
        "name": "ResultSummary",
        "value": "IP: @{items('For_each_IP')} — Status: @{body('HTTP_-_Enrich_IP')?['status']}\n"
      }
    }
  }
}
```

### Foreach with Error Handling per Item

Use `runAfter` with `["Succeeded", "Failed"]` to always run the append step:

```json
"For_each_Host": {
  "type": "Foreach",
  "foreach": "@body('Entities_-_Get_Hosts')?['Hosts']",
  "actions": {
    "HTTP_-_Isolate": {
      "type": "Http",
      "inputs": { /* ... */ }
    },
    "Condition_-_Check_Isolate_Result": {
      "runAfter": { "HTTP_-_Isolate": ["Succeeded", "Failed"] },
      "type": "If",
      "expression": {
        "and": [{ "equals": ["@outputs('HTTP_-_Isolate')['statusCode']", 201] }]
      },
      "actions": {
        "Append_success": {
          "type": "AppendToStringVariable",
          "inputs": { "name": "ResultSummary", "value": "✅ Isolated: @{items('For_each_Host')?['HostName']}\n" }
        }
      },
      "else": {
        "actions": {
          "Append_failure": {
            "type": "AppendToStringVariable",
            "inputs": { "name": "ResultSummary", "value": "❌ Failed to isolate: @{items('For_each_Host')?['HostName']}\n" }
          }
        }
      }
    }
  }
}
```

---

## Variable Management Patterns

### Initialize Multiple Variables at Start

Always initialize all variables before any loops (variables cannot be initialized inside loops):

```json
"Initialize_variable_-_ResultSummary": {
  "runAfter": {},
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "ResultSummary", "type": "string", "value": "" }] }
},
"Initialize_variable_-_AffectedUsers": {
  "runAfter": { "Initialize_variable_-_ResultSummary": ["Succeeded"] },
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "AffectedUsers", "type": "string", "value": "" }] }
},
"Initialize_variable_-_StatusCode": {
  "runAfter": { "Initialize_variable_-_AffectedUsers": ["Succeeded"] },
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "StatusCode", "type": "integer", "value": 0 }] }
}
```

### Reset Variable Inside Loop Iteration

When each loop item needs a clean state for a variable:

```json
"Set_variable_-_Reset_UPN": {
  "runAfter": {},
  "type": "SetVariable",
  "inputs": { "name": "UPN", "value": "" }
}
```

---

## KQL Query Patterns

### Run KQL and Parse Results

```json
"Run_query_and_list_results": {
  "runAfter": {},
  "type": "ApiConnection",
  "inputs": {
    "body": "SigninLogs | where UserPrincipalName == \"@{items('For_each')?['accountName']}@{items('For_each')?['upnSuffix']}\" | where TimeGenerated > ago(24h) | summarize Count=count() by Location, ResultType | order by Count desc | limit 10",
    "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
    "method": "post",
    "path": "/queryData",
    "queries": {
      "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
      "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
      "resourcetype": "Log Analytics Workspace",
      "resourcename": "[parameters('WorkspaceName')]",
      "timerange": "Last 24 hours"
    }
  }
},
"Parse_JSON_-_Query_Results": {
  "runAfter": { "Run_query_and_list_results": ["Succeeded"] },
  "type": "ParseJson",
  "inputs": {
    "content": "@body('Run_query_and_list_results')",
    "schema": {
      "properties": {
        "value": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "Location": { "type": "string" },
              "ResultType": { "type": "integer" },
              "Count": { "type": "integer" }
            }
          }
        }
      },
      "type": "object"
    }
  }
}
```

Access results: `@body('Parse_JSON_-_Query_Results')?['value']`  
Check non-empty: `@length(body('Run_query_and_list_results')?['value'])` > 0

### KQL with HTML Table for Incident Comment

```json
"Run_query_and_visualize_results": {
  "type": "ApiConnection",
  "inputs": {
    "body": "SecurityAlert | where TimeGenerated > ago(24h) | project TimeGenerated, AlertName, Severity, Entities | limit 10",
    "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
    "method": "post",
    "path": "/visualizeQuery",
    "queries": {
      "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
      "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
      "resourcetype": "Log Analytics Workspace",
      "resourcename": "[parameters('WorkspaceName')]",
      "timerange": "Last 24 hours",
      "visType": "Html Table"
    }
  }
}
```

Include in comment: `@{base64ToString(body('Run_query_and_visualize_results')?['attachmentContent'])}`

---

## Email Formatting Pattern (HTML Table)

Build a styled HTML table for incident email bodies:

```json
"Initialize_variable_-_HTMLTable": {
  "type": "InitializeVariable",
  "inputs": {
    "variables": [{
      "name": "HTMLTable",
      "type": "string",
      "value": "<table style=\"border-collapse:collapse;\"><tr><th style=\"border:1px solid black;padding:5px;\">Field</th><th style=\"border:1px solid black;padding:5px;\">Value</th></tr>"
    }]
  }
},
"Append_Incident_Number": {
  "type": "AppendToStringVariable",
  "inputs": {
    "name": "HTMLTable",
    "value": "<tr><td style=\"border:1px solid black;padding:5px;\">Incident #</td><td style=\"border:1px solid black;padding:5px;\">@{triggerBody()?['object']?['properties']?['incidentNumber']}</td></tr>"
  }
},
"Append_Severity": {
  "type": "AppendToStringVariable",
  "inputs": {
    "name": "HTMLTable",
    "value": "<tr><td style=\"border:1px solid black;padding:5px;\">Severity</td><td style=\"border:1px solid black;padding:5px;background-color:@{variables('SeverityColor')}\">@{triggerBody()?['object']?['properties']?['severity']}</td></tr>"
  }
},
"Append_Table_Close": {
  "type": "AppendToStringVariable",
  "inputs": { "name": "HTMLTable", "value": "</table>" }
}
```

---

## Date/Time Expression Patterns

Calculate relative times for KQL lookbacks:

```json
"Calculate_Lookback_Date": {
  "runAfter": {},
  "type": "Expression",
  "kind": "SubtractFromTime",
  "inputs": {
    "baseTime": "@triggerBody()?['object']?['properties']?['createdTimeUtc']",
    "interval": 14,
    "timeUnit": "Day"
  }
}
```

Access result: `@body('Calculate_Lookback_Date')` — ISO 8601 datetime string.

Format a datetime: `@formatDateTime(triggerBody()?['object']?['properties']?['createdTimeUtc'], 'yyyy-MM-dd HH:mm:ss')`

---

## Compose + Send to Log Analytics (Custom Table)

Enrich data and push to a custom _CL table for correlation:

```json
"Compose_Enrichment_Record": {
  "type": "Compose",
  "inputs": {
    "IncidentId": "@triggerBody()?['object']?['properties']?['incidentNumber']",
    "IPAddress": "@items('For_each_IP')",
    "MaliciousScore": "@body('Parse_JSON_-_Response')?['score']",
    "Classification": "@body('Parse_JSON_-_Response')?['classification']",
    "Country": "@body('Parse_JSON_-_Response')?['metadata']?['country']"
  }
},
"Send_Data_to_Log_Analytics": {
  "runAfter": { "Compose_Enrichment_Record": ["Succeeded"] },
  "type": "ApiConnection",
  "inputs": {
    "body": "@{outputs('Compose_Enrichment_Record')}",
    "headers": {
      "Log-Type": "IPEnrichment",
      "time-generated-field": "@triggerBody()?['object']?['properties']?['createdTimeUtc']"
    },
    "host": { "connection": { "name": "@parameters('$connections')['azureloganalyticsdatacollector']['connectionId']" } },
    "method": "post",
    "path": "/api/logs"
  }
}
```

The resulting table in Log Analytics will be named `IPEnrichment_CL`.

---

## User Identity Resolution Pattern

Accounts in Sentinel can appear with `AadUserId` or `accountName + upnSuffix`. Handle both:

```json
"Condition_-_Determine_UPN": {
  "type": "If",
  "expression": {
    "and": [{ "equals": ["@items('For_each')?['AadUserId']", "@null"] }]
  },
  "actions": {
    "Set_variable_-_Concatenate_UPN": {
      "type": "SetVariable",
      "inputs": {
        "name": "UPN",
        "value": "@{concat(items('For_each')?['accountName'], '@', items('For_each')?['upnSuffix'])}"
      }
    }
  },
  "else": {
    "actions": {
      "Set_variable_-_Use_AadUserId": {
        "type": "SetVariable",
        "inputs": { "name": "UPN", "value": "@{items('For_each')?['AadUserId']}" }
      }
    }
  }
}
```

---

## Watchlist Operations

### Add Item to Watchlist

```json
"Add_to_Watchlist": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "properties": {
        "itemsKeyValue": {
          "IPAddress": "@{items('For_each_IP')}",
          "AddedBy": "SentinelPlaybook",
          "AddedAt": "@{utcNow()}"
        }
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "put",
    "path": "[concat('/Watchlists/subscriptions/@{encodeURIComponent(triggerBody()?[''workspaceInfo'']?[''SubscriptionId''])}/resourceGroups/@{encodeURIComponent(triggerBody()?[''workspaceInfo'']?[''ResourceGroupName''])}/workspaces/', parameters('WorkspaceName'), '/watchlists/', parameters('WatchlistAlias'), '/watchlistItems/@{guid()}')]"
  }
}
```

---

---

## Severity Mapping Pattern (Sentinel → External System)

Use a Switch to map Sentinel severity strings to the numeric priority values expected by ServiceNow, Jira, or PagerDuty **before** creating any ticket:

```json
"Initialize_variable_-_TicketPriority": {
  "runAfter": {},
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "TicketPriority", "type": "string", "value": "3" }] }
},
"Switch_-_Map_Severity_to_Priority": {
  "runAfter": { "Initialize_variable_-_TicketPriority": ["Succeeded"] },
  "type": "Switch",
  "expression": "@triggerBody()?['object']?['properties']?['severity']",
  "cases": {
    "High": {
      "case": "High",
      "actions": {
        "Set_Priority_High": {
          "type": "SetVariable",
          "inputs": { "name": "TicketPriority", "value": "1" }
        }
      }
    },
    "Medium": {
      "case": "Medium",
      "actions": {
        "Set_Priority_Medium": {
          "type": "SetVariable",
          "inputs": { "name": "TicketPriority", "value": "2" }
        }
      }
    },
    "Low": {
      "case": "Low",
      "actions": {
        "Set_Priority_Low": {
          "type": "SetVariable",
          "inputs": { "name": "TicketPriority", "value": "3" }
        }
      }
    },
    "Informational": {
      "case": "Informational",
      "actions": {
        "Set_Priority_Info": {
          "type": "SetVariable",
          "inputs": { "name": "TicketPriority", "value": "4" }
        }
      }
    }
  },
  "default": { "actions": {} }
}
```

Reference in ticket creation: `"urgency": "@{variables('TicketPriority')}"` (ServiceNow) or `"priority": { "id": "@{variables('TicketPriority')}" }` (Jira).

---

## Bi-Directional Sync Pattern (ServiceNow / Jira)

When a Sentinel incident is **updated**, sync the change back to the external ticket. Check which fields changed using `updatedFields`:

```json
"Check_Status_Update": {
  "type": "If",
  "expression": {
    "and": [{ "contains": ["@string(triggerBody()?['incidentUpdates']?['updatedFields'])", "Status"] }]
  },
  "actions": {
    "Update_SNOW_Status": {
      "type": "ApiConnection",
      "inputs": {
        "body": { "state": "@{if(equals(triggerBody()?['object']?['properties']?['status'], 'Closed'), '7', '2')}" },
        "host": { "connection": { "name": "@parameters('$connections')['service-now']['connectionId']" } },
        "method": "patch",
        "path": "/api/now/v2/table/incident/@{variables('SNOWTicketSysId')}"
      }
    }
  },
  "else": { "actions": {} }
},
"Check_Severity_Update": {
  "runAfter": { "Check_Status_Update": ["Succeeded"] },
  "type": "If",
  "expression": {
    "and": [{ "contains": ["@string(triggerBody()?['incidentUpdates']?['updatedFields'])", "Severity"] }]
  },
  "actions": {
    "Update_SNOW_Urgency": {
      "type": "ApiConnection",
      "inputs": {
        "body": { "urgency": "@{variables('TicketPriority')}" },
        "host": { "connection": { "name": "@parameters('$connections')['service-now']['connectionId']" } },
        "method": "patch",
        "path": "/api/now/v2/table/incident/@{variables('SNOWTicketSysId')}"
      }
    }
  },
  "else": { "actions": {} }
}
```

**Store the external ticket ID in a Sentinel incident tag** immediately after creation so subsequent updates can retrieve it:

```json
"Tag_Incident_with_SNOW_ID": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "tagsToAdd": {
        "TagsToAdd": [{ "Tag": "SNOW-@{body('Create_SNOW_Incident')?['result']?['number']}" }]
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "put",
    "path": "/Incidents"
  }
}
```

---

## Until Loop (Async Polling Pattern)

For external systems where actions are asynchronous (Tanium, AWS SSM, CrowdStrike containment). Always initialize `IsComplete` (boolean, false) and `ActionId` (string) before the loop:

```json
"Initialize_variable_-_IsComplete": {
  "runAfter": {},
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "IsComplete", "type": "boolean", "value": false }] }
},
"Initialize_variable_-_ActionId": {
  "runAfter": { "Initialize_variable_-_IsComplete": ["Succeeded"] },
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "ActionId", "type": "string", "value": "" }] }
},
"HTTP_-_Issue_Action": {
  "runAfter": { "Initialize_variable_-_ActionId": ["Succeeded"] },
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.example.com/actions",
    "headers": { "Authorization": "Bearer @{variables('AccessToken')}" },
    "body": { "target": "@{items('For_each')?['HostName']}", "package": "QuarantineHost" }
  }
},
"Set_variable_-_ActionId": {
  "runAfter": { "HTTP_-_Issue_Action": ["Succeeded"] },
  "type": "SetVariable",
  "inputs": { "name": "ActionId", "value": "@body('HTTP_-_Issue_Action')?['id']" }
},
"Until_-_Wait_for_Completion": {
  "runAfter": { "Set_variable_-_ActionId": ["Succeeded"] },
  "type": "Until",
  "expression": "@equals(variables('IsComplete'), true)",
  "limit": { "count": 60, "timeout": "PT1H" },
  "actions": {
    "Wait_10_Seconds": {
      "runAfter": {},
      "type": "Wait",
      "inputs": { "interval": { "count": 10, "unit": "Second" } }
    },
    "HTTP_-_Get_Action_Status": {
      "runAfter": { "Wait_10_Seconds": ["Succeeded"] },
      "type": "Http",
      "inputs": {
        "method": "GET",
        "uri": "https://api.example.com/actions/@{variables('ActionId')}",
        "headers": { "Authorization": "Bearer @{variables('AccessToken')}" }
      }
    },
    "Parse_JSON_-_Status": {
      "runAfter": { "HTTP_-_Get_Action_Status": ["Succeeded"] },
      "type": "ParseJson",
      "inputs": {
        "content": "@body('HTTP_-_Get_Action_Status')",
        "schema": {
          "type": "object",
          "properties": {
            "status": { "type": "string" },
            "result": { "type": "string" }
          }
        }
      }
    },
    "Condition_-_Is_Action_Complete": {
      "runAfter": { "Parse_JSON_-_Status": ["Succeeded"] },
      "type": "If",
      "expression": {
        "or": [
          { "equals": ["@body('Parse_JSON_-_Status')?['status']", "Completed"] },
          { "equals": ["@body('Parse_JSON_-_Status')?['status']", "Failed"] }
        ]
      },
      "actions": {
        "Set_IsComplete_True": {
          "type": "SetVariable",
          "inputs": { "name": "IsComplete", "value": true }
        }
      },
      "else": { "actions": {} }
    }
  }
}
```

`limit.count` = max iterations, `limit.timeout` = ISO 8601 duration (PT1H = 1 hour).

---

## Nested Logic App (Workflow Call)

Call a child Logic App (e.g., a shared auth helper that returns an access token) from the parent playbook:

```json
"Call_Auth_Helper": {
  "runAfter": {},
  "type": "Workflow",
  "inputs": {
    "host": {
      "triggerName": "manual",
      "workflow": {
        "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Logic/workflows/', parameters('AuthHelperPlaybookName'))]"
      }
    },
    "body": {}
  },
  "runtimeConfiguration": {
    "secureData": { "properties": ["inputs", "outputs"] }
  }
},
"Set_variable_-_AccessToken": {
  "runAfter": { "Call_Auth_Helper": ["Succeeded"] },
  "type": "SetVariable",
  "inputs": {
    "name": "AccessToken",
    "value": "@{body('Call_Auth_Helper')?['AccessToken']}"
  }
}
```

Add `AuthHelperPlaybookName` as a `string` parameter with a `defaultValue` matching the deployed sub-playbook name. Use `secureData.properties: ["inputs","outputs"]` when the workflow returns secrets.

---

## Teams Adaptive Card with Wait-for-Response

Send an interactive card to Teams and pause until an analyst submits a decision:

```json
"Compose_-_Adaptive_Card": {
  "runAfter": {},
  "type": "Compose",
  "inputs": {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.4",
    "body": [
      {
        "type": "TextBlock",
        "text": "Sentinel Incident Requires Action",
        "size": "Large",
        "weight": "Bolder",
        "color": "Attention"
      },
      {
        "type": "FactSet",
        "facts": [
          { "title": "Incident #", "value": "@{triggerBody()?['object']?['properties']?['incidentNumber']}" },
          { "title": "Title", "value": "@{triggerBody()?['object']?['properties']?['title']}" },
          { "title": "Severity", "value": "@{triggerBody()?['object']?['properties']?['severity']}" },
          { "title": "Status", "value": "@{triggerBody()?['object']?['properties']?['status']}" }
        ]
      },
      {
        "type": "Input.ChoiceSet",
        "id": "analystAction",
        "label": "Select action:",
        "style": "expanded",
        "choices": [
          { "title": "✅ True Positive — Escalate", "value": "Escalate" },
          { "title": "🔴 Close as False Positive", "value": "FalsePositive" },
          { "title": "🟡 Needs Investigation", "value": "Investigate" }
        ]
      },
      {
        "type": "Input.Text",
        "id": "analystComment",
        "label": "Add a comment (optional):",
        "isMultiline": true
      }
    ],
    "actions": [{ "type": "Action.Submit", "title": "Submit Decision" }]
  }
},
"Post_Adaptive_Card_and_Wait": {
  "runAfter": { "Compose_-_Adaptive_Card": ["Succeeded"] },
  "type": "ApiConnectionWebhook",
  "inputs": {
    "body": {
      "body": { "messageBody": "@{outputs('Compose_-_Adaptive_Card')}" },
      "notificationUrl": "@{listCallbackUrl()}"
    },
    "host": { "connection": { "name": "@parameters('$connections')['teams']['connectionId']" } },
    "method": "post",
    "path": "/v1.0/teams/conversation/gatherinput/poster/Flow bot/location/@{encodeURIComponent('Channel')}/$subscriptions",
    "queries": {
      "groupId": "[parameters('TeamId')]",
      "channelId": "[parameters('ChannelId')]"
    }
  }
},
"Switch_-_Analyst_Decision": {
  "runAfter": { "Post_Adaptive_Card_and_Wait": ["Succeeded"] },
  "type": "Switch",
  "expression": "@body('Post_Adaptive_Card_and_Wait')?['data']?['analystAction']",
  "cases": {
    "Escalate": {
      "case": "Escalate",
      "actions": {
        "Update_Incident_Severity": {
          "type": "ApiConnection",
          "inputs": {
            "body": {
              "incidentArmId": "@triggerBody()?['object']?['id']",
              "severity": "High",
              "tagsToAdd": { "TagsToAdd": [{ "Tag": "AnalystEscalated" }] }
            },
            "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
            "method": "put",
            "path": "/Incidents"
          }
        }
      }
    },
    "FalsePositive": {
      "case": "FalsePositive",
      "actions": {
        "Close_Incident": {
          "type": "ApiConnection",
          "inputs": {
            "body": {
              "incidentArmId": "@triggerBody()?['object']?['id']",
              "status": "Closed",
              "classification": {
                "ClassificationAndReason": "FalsePositive - IncorrectAlertLogic",
                "ClassificationReasonText": "@{body('Post_Adaptive_Card_and_Wait')?['data']?['analystComment']}"
              }
            },
            "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
            "method": "put",
            "path": "/Incidents"
          }
        }
      }
    }
  },
  "default": { "actions": {} }
}
```

---

## HTML Table with Explicit Columns

When the array items have many fields and you only want specific ones with custom headers:

```json
"Create_HTML_Table_-_Device_Details": {
  "type": "Table",
  "inputs": {
    "format": "HTML",
    "from": "@body('Parse_JSON_-_Devices')?['resources']",
    "columns": [
      { "header": "Device ID",     "value": "@item()?['device_id']" },
      { "header": "Hostname",      "value": "@item()?['hostname']" },
      { "header": "OS Version",    "value": "@item()?['os_version']" },
      { "header": "External IP",   "value": "@item()?['external_ip']" },
      { "header": "Last Seen",     "value": "@item()?['last_seen']" },
      { "header": "Agent Version", "value": "@item()?['agent_version']" }
    ]
  }
}
```

Then include in an incident comment: `@{body('Create_HTML_Table_-_Device_Details')}`

---

## Pagination Pattern (Recurrence + Until Loop)

For scheduled playbooks that pull paginated data from a threat intel API:

```json
"Initialize_variable_-_Offset": {
  "runAfter": {},
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "Offset", "type": "integer", "value": 0 }] }
},
"Initialize_variable_-_TotalResults": {
  "runAfter": { "Initialize_variable_-_Offset": ["Succeeded"] },
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "TotalResults", "type": "integer", "value": 1 }] }
},
"Until_-_All_Pages_Fetched": {
  "runAfter": { "Initialize_variable_-_TotalResults": ["Succeeded"] },
  "type": "Until",
  "expression": "@greaterOrEquals(variables('Offset'), variables('TotalResults'))",
  "limit": { "count": 100, "timeout": "PT2H" },
  "actions": {
    "HTTP_-_Fetch_Page": {
      "runAfter": {},
      "type": "Http",
      "inputs": {
        "method": "GET",
        "uri": "https://api.threatintel.com/v1/alerts?limit=100&offset=@{variables('Offset')}",
        "headers": { "Authorization": "Bearer @{parameters('APIKey')}" }
      }
    },
    "Parse_JSON_-_Page": {
      "runAfter": { "HTTP_-_Fetch_Page": ["Succeeded"] },
      "type": "ParseJson",
      "inputs": {
        "content": "@body('HTTP_-_Fetch_Page')",
        "schema": {
          "type": "object",
          "properties": {
            "total": { "type": "integer" },
            "results": { "type": "array" }
          }
        }
      }
    },
    "Set_TotalResults": {
      "runAfter": { "Parse_JSON_-_Page": ["Succeeded"] },
      "type": "SetVariable",
      "inputs": { "name": "TotalResults", "value": "@body('Parse_JSON_-_Page')?['total']" }
    },
    "For_each_-_Result": {
      "runAfter": { "Set_TotalResults": ["Succeeded"] },
      "type": "Foreach",
      "foreach": "@body('Parse_JSON_-_Page')?['results']",
      "actions": {
        "Add_to_Watchlist": { /* watchlist PUT action */ }
      }
    },
    "Increment_Offset": {
      "runAfter": { "For_each_-_Result": ["Succeeded"] },
      "type": "IncrementVariable",
      "inputs": { "name": "Offset", "value": 100 }
    }
  }
}
```

---

## Incident Owner Assignment Pattern

Assign an incident to a specific analyst (requires owner UPN or object ID):

```json
"Assign_Incident_Owner": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "owner": {
        "assignedTo": "[parameters('AnalystUPN')]",
        "objectId": "[parameters('AnalystObjectId')]",
        "userPrincipalName": "[parameters('AnalystUPN')]"
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "put",
    "path": "/Incidents"
  }
}
```

---

---

## Foreach Sequential Execution (Concurrency = 1)

By default Foreach runs iterations in parallel. For API calls that must be serial (rate-limit or dependency), set `concurrency.repetitions: 1`.

```json
"For_each": {
  "type": "Foreach",
  "foreach": "@body('Entities_-_Get_IPs')?['IPs']",
  "actions": { /* ... */ },
  "runAfter": { "Entities_-_Get_IPs": ["Succeeded"] },
  "runtimeConfiguration": {
    "concurrency": {
      "repetitions": 1
    }
  }
}
```

Use `repetitions: 1` whenever: (a) each iteration calls an API that has per-second rate limits, (b) each iteration modifies shared state (e.g., appending to a single ticket), or (c) you need deterministic ordering of incident comments.

---

## Watchlist IP Lookup Pattern

Query a watchlist via KQL inside a Foreach loop. Checks whether an entity (IP, user, host) is in a watchlist, then branches on the result length.

```json
"Run_query_and_list_results": {
  "type": "ApiConnection",
  "inputs": {
    "body": "_GetWatchlist(\"@{variables('WatchlistName')}\")\n| where ipaddress == \"@{items('For_each')?['Address']}\"",
    "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
    "method": "post",
    "path": "/queryData",
    "queries": {
      "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
      "resourcename": "@triggerBody()?['workspaceInfo']?['WorkspaceName']",
      "resourcetype": "Log Analytics Workspace",
      "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
      "timerange": "Last 12 hours"
    }
  },
  "runAfter": {}
},
"Condition_-_if_IP_found_in_watchlist": {
  "type": "If",
  "expression": {
    "and": [{ "greater": ["@length(body('Run_query_and_list_results')?['value'])", 0] }]
  },
  "actions": {
    "Append_to_array_variable_-_add_to_safe_list": {
      "type": "AppendToArrayVariable",
      "inputs": { "name": "SafeIPs", "value": { "SafeIPs": "@{items('For_each')?['Address']}" } },
      "runAfter": {}
    }
  },
  "else": {
    "actions": {
      "Append_to_array_variable_-_add_to_not_safe_list": {
        "type": "AppendToArrayVariable",
        "inputs": { "name": "notSafeIPs", "value": { "NotSafeIPs": "@{items('For_each')?['Address']}" } },
        "runAfter": {}
      }
    }
  },
  "runAfter": { "Run_query_and_list_results": ["Succeeded"] }
}
```

**After loop — auto-close if all IPs safe:**
```json
"Condition_-_close_if_all_safe": {
  "type": "If",
  "expression": { "and": [{ "equals": ["@length(variables('notSafeIPs'))", 0] }] },
  "actions": {
    "Update_incident": {
      "type": "ApiConnection",
      "inputs": {
        "body": {
          "classification": {
            "ClassificationAndReason": "BenignPositive - SuspiciousButExpected",
            "ClassificationReasonText": "All IPs found in safe watchlist: @{join(variables('SafeIPs'), ', ')}"
          },
          "incidentArmId": "@triggerBody()?['object']?['id']",
          "status": "Closed"
        },
        "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
        "method": "put",
        "path": "/Incidents"
      },
      "runAfter": {}
    }
  },
  "runAfter": { "Add_comment_to_incident": ["Succeeded"] }
}
```

**KQL watchlist column names** are configurable — use `_GetWatchlist("<name>") | where <column> == "<value>"`.

---

## Scope Action (Grouped Error Handling)

Group related actions in a `Scope` to apply unified error handling. The scope succeeds only if all contained actions succeed.

```json
"Scope_-_Enrichment": {
  "type": "Scope",
  "actions": {
    "HTTP_-_Get_Threat_Intel": { /* action */ },
    "Parse_JSON_-_TI_Response": { /* action */ }
  },
  "runAfter": { "Initialize_variables": ["Succeeded"] }
},
"Condition_-_Enrichment_Succeeded": {
  "type": "If",
  "expression": {
    "and": [{ "equals": ["@result('Scope_-_Enrichment')[0]['status']", "Succeeded"] }]
  },
  "actions": { /* proceed with results */ },
  "else": {
    "actions": {
      "Add_comment_-_enrichment_failed": {
        "type": "ApiConnection",
        "inputs": {
          "body": {
            "incidentArmId": "@triggerBody()?['object']?['id']",
            "message": "<p>Enrichment step failed: @{result('Scope_-_Enrichment')[0]['error']?['message']}</p>"
          },
          "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
          "method": "post",
          "path": "/Incidents/Comment"
        },
        "runAfter": {}
      }
    }
  },
  "runAfter": { "Scope_-_Enrichment": ["Succeeded", "Failed", "TimedOut"] }
}
```

**Check scope run status:** `@result('Scope_Action_Name')[0]['status']` → `Succeeded` | `Failed` | `TimedOut` | `Skipped`

---

## ARM Key Vault Deployment Pattern

Deploy a Key Vault and populate secrets within the same ARM template. The Logic App's MSI is granted access via an `accessPolicies` resource.

```json
{
  "type": "Microsoft.KeyVault/vaults",
  "apiVersion": "2019-09-01",
  "name": "[parameters('KeyVaultName')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "sku": { "family": "A", "name": "standard" },
    "tenantId": "[subscription().tenantId]",
    "accessPolicies": [],
    "enabledForTemplateDeployment": true
  }
},
{
  "type": "Microsoft.KeyVault/vaults/secrets",
  "apiVersion": "2019-09-01",
  "name": "[concat(parameters('KeyVaultName'), '/ApiToken')]",
  "dependsOn": [
    "[resourceId('Microsoft.KeyVault/vaults', parameters('KeyVaultName'))]"
  ],
  "properties": {
    "value": "[parameters('ApiToken')]"
  }
},
{
  "type": "Microsoft.KeyVault/vaults/accessPolicies",
  "apiVersion": "2019-09-01",
  "name": "[concat(parameters('KeyVaultName'), '/add')]",
  "dependsOn": [
    "[resourceId('Microsoft.KeyVault/vaults', parameters('KeyVaultName'))]",
    "[resourceId('Microsoft.Logic/workflows', parameters('PlaybookName'))]"
  ],
  "properties": {
    "accessPolicies": [
      {
        "tenantId": "[subscription().tenantId]",
        "objectId": "[reference(resourceId('Microsoft.Logic/workflows', parameters('PlaybookName')), '2017-07-01', 'Full').identity.principalId]",
        "permissions": {
          "secrets": ["get", "list"]
        }
      }
    ]
  }
}
```

**Note:** `reference(..., 'Full').identity.principalId` requires the Logic App to be deployed first — add it to `dependsOn` of the `accessPolicies` resource.

**Keyvault connection with `parameterValueSet` (oauthMI variant):**
```json
"properties": {
  "parameterValueSet": {
    "name": "oauthMI",
    "values": {
      "vaultName": { "value": "[parameters('KeyVaultName')]" }
    }
  },
  "api": {
    "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/keyvault')]"
  }
}
```

---

## ARM Template Outputs Section

Use `outputs` to expose resource names and IDs for parent template consumption or post-deploy scripts.

```json
"outputs": {
  "PlaybookName": {
    "type": "string",
    "value": "[parameters('PlaybookName')]"
  },
  "PlaybookResourceId": {
    "type": "string",
    "value": "[resourceId('Microsoft.Logic/workflows', parameters('PlaybookName'))]"
  },
  "KeyVaultName": {
    "type": "string",
    "value": "[parameters('KeyVaultName')]"
  }
}
```

This section lives at the top level of the ARM template (sibling to `parameters`, `variables`, `resources`), not inside any resource.

---

## HTTP Authentication Variants

### Basic Auth (username + password inline)

```json
"HTTP_-_BasicAuth_Call": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.example.com/endpoint",
    "authentication": {
      "type": "Basic",
      "username": "@parameters('Username')",
      "password": "@parameters('Password')"
    }
  }
}
```

### Raw Bearer Token (inline, from prior HTTP call)

```json
"HTTP_-_Bearer_Token_Call": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.example.com/endpoint",
    "authentication": {
      "type": "Raw",
      "value": "Bearer @{body('Get_Token')?['access_token']}"
    }
  }
}
```

### Client Certificate (mTLS)

```json
"authentication": {
  "type": "ClientCertificate",
  "pfx": "@parameters('CertificatePfxBase64')",
  "password": "@parameters('CertificatePassword')"
}
```

**When to use each:**
- `Basic` — services that accept HTTP Basic auth (username/password in Authorization header)
- `Raw` — when you have a pre-built token string (e.g., token from OAuth sub-playbook)
- `ClientCertificate` — mTLS-secured APIs
- Use `headers: { "Authorization": "Bearer ..." }` instead of `authentication` when the token format is non-standard

---

## Common Anti-Patterns to Avoid

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| Initialize variable inside Foreach | Runtime error — variables must be initialized before loops | Move `InitializeVariable` before the Foreach |
| Missing `"runAfter": {}` on first action | Implicit dependency not recognized | Always declare `"runAfter": {}` explicitly on the first action |
| Not parsing HTTP response before accessing fields | `body()` returns a string, field access fails silently | Always use `ParseJson` before accessing nested response fields |
| Using `@triggerBody()` inside a Foreach for loop context | Works but can be confusing | Use `@items('For_each_name')?['field']` for loop item fields |
| Hardcoding tenant ID / subscription ID | Breaks on deployment to another tenant | Use `subscription().tenantId` and `subscription().subscriptionId` |
| Skipping `encodeURIComponent()` on user-provided values | Breaks if name contains spaces or special chars | Always `@{encodeURIComponent(value)}` for URL path segments |
| Missing `"identity": {"type": "SystemAssigned"}` | MSI connections fail — Logic App has no identity | Always include the identity block |
| Polling without a `Wait` action inside Until | Logic App runs tight loops, burns execution budget | Always add a `Wait` action as the first step inside Until |
| Until loop without `limit` | Runs forever on API errors | Always set both `count` and `timeout` in `limit` |
| Using `type: "Workflow"` without `secureData` for secret payloads | Credentials visible in run history | Add `runtimeConfiguration.secureData.properties: ["inputs","outputs"]` |
