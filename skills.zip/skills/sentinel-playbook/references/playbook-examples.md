# Playbook Examples Reference

> Parent skill: [sentinel-playbooks](../SKILL.md)

Complete, production-validated ARM template skeletons for each playbook category. Each example is a fully-wired, deployable template that can be adapted for any use case in its category.

---

## Category 1: Identity Response — Disable Entra ID User

**Trigger:** Incident | **Entities:** Account | **Connections:** azuresentinel, azuread

Pattern: Extract Account entities → Loop → Disable each user in Entra ID → Comment on incident.

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "metadata": {
    "title": "Disable-EntraID-User",
    "description": "Disables Azure AD user accounts for all Account entities on the incident.",
    "entities": ["Account"],
    "tags": ["Microsoft Sentinel", "Incident", "Entra ID", "Disable User"],
    "postDeployment": [
      "Grant the Logic App Managed Identity 'Microsoft Sentinel Responder' on the Sentinel workspace"
    ],
    "support": { "tier": "community" },
    "author": { "name": "Your Name" }
  },
  "parameters": {
    "PlaybookName": { "defaultValue": "Disable-EntraID-User", "type": "string" }
  },
  "variables": {
    "azuread": "[concat('azuread-', parameters('PlaybookName'))]",
    "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]"
  },
  "resources": [
    {
      "type": "Microsoft.Web/connections", "apiVersion": "2016-06-01",
      "name": "[variables('azuread')]", "location": "[resourceGroup().location]",
      "kind": "V1",
      "properties": {
        "displayName": "[parameters('PlaybookName')]",
        "customParameterValues": {},
        "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]" }
      }
    },
    {
      "type": "Microsoft.Web/connections", "apiVersion": "2016-06-01",
      "name": "[variables('azuresentinel')]", "location": "[resourceGroup().location]",
      "kind": "V1",
      "properties": {
        "displayName": "[parameters('PlaybookName')]",
        "customParameterValues": {},
        "parameterValueType": "Alternative",
        "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuresentinel')]" }
      }
    },
    {
      "type": "Microsoft.Logic/workflows", "apiVersion": "2017-07-01",
      "name": "[parameters('PlaybookName')]", "location": "[resourceGroup().location]",
      "tags": { "LogicAppsCategory": "security" },
      "identity": { "type": "SystemAssigned" },
      "dependsOn": [
        "[resourceId('Microsoft.Web/connections', variables('azuread'))]",
        "[resourceId('Microsoft.Web/connections', variables('azuresentinel'))]"
      ],
      "properties": {
        "state": "Enabled",
        "definition": {
          "$schema": "https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#",
          "contentVersion": "1.0.0.0",
          "parameters": { "$connections": { "defaultValue": {}, "type": "Object" } },
          "triggers": {
            "Microsoft_Sentinel_incident": {
              "type": "ApiConnectionWebhook",
              "inputs": {
                "body": { "callback_url": "@{listCallbackUrl()}" },
                "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
                "path": "/incident-creation"
              }
            }
          },
          "actions": {
            "Entities_-_Get_Accounts": {
              "runAfter": {},
              "type": "ApiConnection",
              "inputs": {
                "body": "@triggerBody()?['object']?['properties']?['relatedEntities']",
                "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
                "method": "post",
                "path": "/entities/account"
              }
            },
            "Initialize_variable_-_DisabledUsers": {
              "runAfter": { "Entities_-_Get_Accounts": ["Succeeded"] },
              "type": "InitializeVariable",
              "inputs": { "variables": [{ "name": "DisabledUsers", "type": "string", "value": "" }] }
            },
            "For_each": {
              "foreach": "@body('Entities_-_Get_Accounts')?['Accounts']",
              "runAfter": { "Initialize_variable_-_DisabledUsers": ["Succeeded"] },
              "type": "Foreach",
              "actions": {
                "Update_user_-_Disable": {
                  "runAfter": {},
                  "type": "ApiConnection",
                  "inputs": {
                    "body": { "accountEnabled": false },
                    "host": { "connection": { "name": "@parameters('$connections')['azuread']['connectionId']" } },
                    "method": "patch",
                    "path": "/v1.0/users/@{encodeURIComponent(items('For_each')?['AadUserId'])}"
                  }
                },
                "Append_to_string_variable": {
                  "runAfter": { "Update_user_-_Disable": ["Succeeded"] },
                  "type": "AppendToStringVariable",
                  "inputs": { "name": "DisabledUsers", "value": "@{items('For_each')?['accountName']}\n" }
                }
              }
            },
            "Add_comment_to_incident_(V3)": {
              "runAfter": { "For_each": ["Succeeded"] },
              "type": "ApiConnection",
              "inputs": {
                "body": {
                  "incidentArmId": "@triggerBody()?['object']?['id']",
                  "message": "<p><strong>The following user accounts have been disabled in Entra ID:</strong><br>@{variables('DisabledUsers')}</p>"
                },
                "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
                "method": "post",
                "path": "/Incidents/Comment"
              }
            }
          },
          "outputs": {}
        },
        "parameters": {
          "$connections": {
            "value": {
              "azuread": {
                "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuread'))]",
                "connectionName": "[variables('azuread')]",
                "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]"
              },
              "azuresentinel": {
                "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuresentinel'))]",
                "connectionName": "[variables('azuresentinel')]",
                "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuresentinel')]",
                "connectionProperties": { "authentication": { "type": "ManagedServiceIdentity" } }
              }
            }
          }
        }
      }
    }
  ]
}
```

---

## Category 2: Endpoint Response — MDE Machine Isolation

**Trigger:** Incident | **Entities:** Host | **Connections:** azuresentinel, keyvault | **External:** MDE API via App Registration

Pattern: Get Hosts → Get Key Vault secret → Authenticate to MDE → Loop → Isolate each machine → Comment on incident.

**Key sections (adapter pattern):**

```json
"parameters": {
  "PlaybookName": { "defaultValue": "MDE-Isolate-Machine", "type": "string" },
  "ClientId": { "type": "string", "metadata": { "description": "App Registration client ID" } },
  "KeyVaultName": { "type": "string", "metadata": { "description": "Key Vault containing client secret" } },
  "KeyVaultSecretName": { "type": "string", "metadata": { "description": "Secret name in Key Vault" } }
},
"variables": {
  "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]",
  "keyvault": "[concat('keyvault-', parameters('PlaybookName'))]"
}
```

**Action sequence:**
1. `Entities_-_Get_Hosts` — extract Host entities
2. `Get_Client_Secret` (keyvault) — retrieve app secret
3. `Initialize_variable_-_Affected_Hosts` — result string
4. `HTTP_-_Authenticate` — POST to `/oauth2/v2.0/token` with MDE scope
5. `Parse_JSON_-_Token` — extract `access_token`
6. `For_each_-_Host` loop:
   - `Condition_-_Check_for_MDE_Device_ID` — skip if no `MdatpDeviceId`
   - `HTTP_-_Isolate_Machine` — POST to `/api/machines/{id}/isolate`
   - `Append_to_string_variable` — record result
7. `Add_comment_to_incident_(V3)` — post summary

---

## Category 3: IP Enrichment — External Threat Intelligence

**Trigger:** Incident | **Entities:** Ip | **Connections:** azuresentinel, azuremonitorlogs, azureloganalyticsdatacollector

Pattern: Filter IPs → Check RFC1918 → Loop public IPs → Call TI API → Parse response → Compose record → Send to custom Log Analytics table → Visualize with KQL → Add HTML comment.

**Key sections:**

```json
"parameters": {
  "PlaybookName": { "defaultValue": "Enrich-IP-ThreatIntel", "type": "string" },
  "ThreatIntelAPIKey": { "defaultValue": "", "type": "securestring" },
  "WorkspaceName": { "defaultValue": "", "type": "string" },
  "WorkspaceId": { "defaultValue": "", "type": "string" },
  "WorkspaceKey": { "defaultValue": "", "type": "securestring" }
}
```

**Action sequence:**
1. `Filter_IPs_Only` — Query action filtering `kind == 'Ip'`
2. `Initialize_variable_PublicIPEntities` — empty array
3. `Initialize_variable_ResultSummary` — empty string
4. `For_each_IP_Entity_RFC1918` — loop with `KQLRFC1918Check` + `Condition` to populate `PublicIPEntities`
5. `For_each_IP_Entity` (sequential, `"repetitions": 1`) loop:
   - `HTTP_-_Lookup_IP` — GET to TI API endpoint
   - `Parse_JSON_IP_Response` — parse response
   - `Condition_-_Check_Result` — branch on `seen` / `malicious` field
   - `Compose_IP_Data` — build structured record
   - `Set_variable_IPData` — store `[outputs('Compose_IP_Data')]`
   - `Send_Data_to_Log_Analytics` — POST to `/api/logs` with custom `Log-Type`
   - `Run_query_and_visualize_results` — KQL on custom table, `visType: "Html Table"`
   - `Update_incident` — set severity + add tag
   - `Add_comment_to_incident_(V3)` — HTML comment with visualization
6. Final comment summarizing all IPs processed

---

## Category 4: Notification — Email Alert on Incident

**Trigger:** Incident (or Alert) | **Connections:** azuresentinel, office365, azuremonitorlogs

Pattern: Run KQL to get incident details → Build HTML table → Condition if results exist → Send email.

**Key sections:**

```json
"parameters": {
  "PlaybookName": { "defaultValue": "Incident-Email-Notification", "type": "string" },
  "MailList": { "defaultValue": "<user1>@<domain>;<user2>@<domain>", "type": "string" },
  "UserName": { "defaultValue": "<username>@<domain>", "type": "string" },
  "WorkspaceName": { "defaultValue": "", "type": "string" },
  "WorkspaceResourceGroup": { "defaultValue": "", "type": "string" },
  "WorkspaceSubscriptionId": { "defaultValue": "", "type": "string" }
}
```

**Action sequence:**
1. `Run_query_and_list_results` (azuremonitorlogs) — KQL: `SecurityIncident | where AlertIds contains "@{triggerBody()?['SystemAlertId']}"`
2. `Initialize_variable_-_varStyle` — object with CSS styles
3. `Initialize_variable_-_varHTMLTable` — string with HTML table header
4. `Initialize_variable_-_varSeverityColour` — string
5. `Parse_JSON` — parse query results
6. `For_each` — loop over results:
   - `Switch` — set `varSeverityColour` based on Severity
   - `Append_to_string_variable` — add `<tr>` row to HTML table
7. `Append_to_string_variable_2` — close `</table>`
8. `Condition` — check `length(body('Run_query_and_list_results')?['value']) > 0`
9. `Send_an_email_(V2)_2` (office365) — send HTML email

---

## Category 5: Chat Notification — Slack

**Trigger:** Incident | **Connections:** azuresentinel | **External:** Slack API (HTTP)

Pattern: Set severity icon variable → Format description → Build entity string → POST to Slack API.

**Key sections:**

```json
"parameters": {
  "PlaybookName": { "defaultValue": "Slack-Incident-Notification", "type": "string" },
  "OAuthToken": { "defaultValue": "", "type": "securestring" },
  "ChannelId": { "defaultValue": "", "type": "string" }
}
```

**Action sequence:**
1. `Initialize_Variable_-_Severity_Icon` — empty string
2. `Condition_-_Check_and_Set_Severity_Icon` — nested If conditions: High/Medium/Low/Informational
3. `Initialize_Variable_-_Description` — empty string
4. `Condition_-_Check_if_Description_Exists` — set description or "No Description"
5. `Initialize_Variable_-_Entities` — empty string
6. `Condition_-_Check_if_Entities_Exist` — loop entities, format each (IP gets geo lookup via http://ip-api.com)
7. `HTTP_-_Post_Slack_Message` — POST to `https://slack.com/api/chat.postMessage` with Block Kit JSON body

---

## Category 6: Ticketing — ServiceNow Incident

**Trigger:** Incident | **Connections:** azuresentinel, service-now

Pattern: Select entities → Create CSV → Create ServiceNow ticket with incident details.

```json
"parameters": {
  "PlaybookName": { "defaultValue": "Create-ServiceNow-Incident", "type": "string" }
}
```

**Action sequence:**
1. `Select` — transform `relatedEntities` to `[{ "Entity": friendlyName, "Type": kind }]`
2. `Create_CSV_table` — Table action, format: "CSV"
3. `Create_Record` (service-now) — POST to `/api/now/v2/table/incident` with body:
   ```json
   {
     "short_description": "Sentinel Incident #@{incidentNumber}: @{title}",
     "description": "Severity: @{severity}\nCreated: @{createdTime}\nEntities:\n@{body('Create_CSV_table')}\n\nSentinel URL: @{incidentUrl}",
     "urgency": "1",
     "impact": "1"
   }
   ```

---

## Category 7: Ticketing — Zendesk

**Trigger:** Incident | **Connections:** azuresentinel, zendesk

Pattern identical to ServiceNow — Select → CSV → Create Zendesk ticket.

```json
"parameters": {
  "PlaybookName": { "defaultValue": "Create-Zendesk-Ticket", "type": "string" },
  "requester_id": { "defaultValue": "00000000001", "type": "string",
    "metadata": { "description": "Zendesk user ID to create tickets on behalf of" } }
}
```

---

## Category 8: User Session Revocation (Graph API)

**Trigger:** Incident | **Entities:** Account | **Connections:** azuresentinel, keyvault

Pattern: Get Accounts → Get secret → Authenticate (Graph) → Loop:
- Resolve UPN from `accountName + upnSuffix` or `AadUserId`
- POST to `https://graph.microsoft.com/v1.0/users/@{UPN}/revokeSignInSessions`
- Check 200 status
- Append to result string

**App Registration permissions:** `User.RevokeSessions.All` on Microsoft Graph  
**Graph API scope:** `https://graph.microsoft.com/.default`

---

## Category 9: Scheduled Watchlist Refresh

**Trigger:** Recurrence (every 6 hours) | **Connections:** azuresentinel, azuremonitorlogs

Pattern: Run KQL to get current data → Loop results → Check if item exists in watchlist → Add/update watchlist entry.

```json
"triggers": {
  "Recurrence": {
    "type": "Recurrence",
    "recurrence": { "frequency": "Hour", "interval": 6, "timeZone": "UTC" }
  }
}
```

**Action sequence:**
1. `Run_query_and_list_results` — KQL to get data (e.g., named locations, TOR exit nodes)
2. `Parse_JSON` — parse results
3. `For_each` — loop each result
4. Add to Sentinel Watchlist via PUT `/Watchlists/.../watchlistItems/@{guid()}`

---

## Category 10: Multi-Step IAM Response (Master Playbook Pattern)

**Trigger:** Incident | **Entities:** Account | **Connections:** azuresentinel, azuread, keyvault

Pattern: Get Accounts → Loop → For each account:
- Revoke sessions (Graph API)
- Disable user (Azure AD connector)
- Force MFA re-registration (Graph API)
- Add user to monitoring group (Azure AD connector)
- Comment on incident with all actions taken

**Key principle:** Initialize a separate result string variable per action type, and build a composite comment at the end.

```json
"Initialize_variable_-_SessionsRevoked": {
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "SessionsRevoked", "type": "string", "value": "" }] }
},
"Initialize_variable_-_UsersDisabled": {
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "UsersDisabled", "type": "string", "value": "" }] }
}
```

Final comment:
```json
"message": "<p><strong>IAM Response Actions Completed</strong><br><br><strong>Sessions Revoked:</strong><br>@{variables('SessionsRevoked')}<br><strong>Users Disabled:</strong><br>@{variables('UsersDisabled')}</p>"
```

---

## Template Parameters Quick Reference

| Parameter | Type | When to Include |
|-----------|------|-----------------|
| `PlaybookName` | `string` | Always |
| `UserName` | `string` | OAuth connections (office365, teams) |
| `MailList` | `string` | Email notification playbooks |
| `ClientId` | `string` | App Registration (Graph, MDE) |
| `KeyVaultName` | `string` | Key Vault access |
| `KeyVaultSecretName` | `string` | Key Vault access |
| `WorkspaceName` | `string` | Log Analytics queries |
| `WorkspaceId` | `string` | Log Analytics data collector |
| `WorkspaceKey` | `securestring` | Log Analytics data collector |
| `ThreatIntelAPIKey` | `securestring` | External TI APIs |
| `OAuthToken` | `securestring` | Slack Bot API |
| `ChannelId` | `string` | Slack / Teams channel |
| `TeamId` | `string` | Teams channel |
| `requester_id` | `string` | Zendesk ticket creator |

---

---

## Category 11: CrowdStrike Device Enrichment + Containment

**Trigger:** Incident | **Entities:** Host | **Connections:** azuresentinel + HTTP (CrowdStrike API via nested auth helper)

Pattern: Call auth helper → get CrowdStrike token → extract hosts → query device by hostname → get device details → check containment status → contain if not already contained → HTML table comment.

```json
"parameters": {
  "PlaybookName":        { "defaultValue": "CrowdStrike-ContainHost", "type": "string" },
  "BasePlaybookName":   { "defaultValue": "CrowdStrike-Base", "type": "string",
    "metadata": { "description": "Name of the CrowdStrike auth helper Logic App" } }
},
"variables": {
  "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]"
}
```

**Action sequence:**
1. `Entities_-_Get_Hosts` — extract Host entities
2. `Initialize_variable_-_AffectedHosts` — string for comment
3. `CrowdStrike_Base` (Workflow) — call auth helper, returns `{ "AccessToken": "...", "FalconHost": "https://api.crowdstrike.com" }`
4. `For_each_-_Host` loop:
   - `HTTP_-_Get_Device_ID` — GET `/devices/queries/devices/v1?filter=hostname:'@{items(...)?['HostName']}'`
   - `Condition_-_Device_Found` — check `body(...)?['resources']?[0]` is not null
   - `HTTP_-_Get_Device_Info` — GET `/devices/entities/devices/v2?ids=@{body(...)?['resources']?[0]}`
   - `Parse_JSON_-_Device_Info` — extract `hostname`, `status`, `os_version`, `external_ip`
   - `Condition_-_Not_Contained` — check `status` not equal to `"contained"` or `"containment_pending"`
   - `HTTP_-_Contain_Device` — POST `/devices/entities/devices/actions/v2?action_name=contain` with `{ "ids": ["deviceId"] }`
   - `Condition_-_Contain_Success` — check status code 202
   - `Append_to_string_variable` — record hostname + outcome
5. `Create_HTML_Table_-_Device_Details` — Table action with explicit columns
6. `Add_comment_to_incident_(V3)` — HTML table + action summary

**Auth helper pattern (CrowdStrike_Base sub-playbook):**
```json
"HTTP_-_Get_CrowdStrike_Token": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.crowdstrike.com/oauth2/token",
    "headers": { "Content-Type": "application/x-www-form-urlencoded" },
    "body": "client_id=@{body('Get_ClientId')?['value']}&client_secret=@{body('Get_ClientSecret')?['value']}"
  }
},
"Response": {
  "type": "Response",
  "inputs": {
    "statusCode": 200,
    "body": {
      "AccessToken": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}",
      "FalconHost": "https://api.crowdstrike.com"
    }
  }
}
```

---

## Category 12: Jira Create-and-Update Issue (Bi-Directional)

**Trigger:** Incident (creation) or Incident (update) | **Connections:** azuresentinel, jira

Pattern: On new incident → map severity to Jira priority → create Jira issue → tag Sentinel incident with Jira key. On incident update → check which fields changed → patch Jira issue accordingly.

```json
"parameters": {
  "PlaybookName":     { "defaultValue": "Jira-CreateAndUpdate", "type": "string" },
  "JiraProjectKey":   { "defaultValue": "SEC", "type": "string" }
},
"variables": {
  "jira":            "[concat('jira-', parameters('PlaybookName'))]",
  "azuresentinel":   "[concat('azuresentinel-', parameters('PlaybookName'))]"
}
```

**Action sequence (creation flow):**
1. `Initialize_variable_-_TicketPriority` — string = "3"
2. `Switch_-_Map_Severity_to_Priority` — set `TicketPriority` (1=High, 2=Medium, 3=Low, 4=Informational)
3. `Select_-_Entities` — transform `relatedEntities` to `[{Entity, Type}]`
4. `Create_CSV_table` — CSV of entities
5. `Create_a_new_issue` (jira) — POST `/issue` with summary, description, priority
6. `Tag_Incident_with_Jira_Key` — PUT /Incidents with tag `"Jira-@{body('Create_a_new_issue')?['key']}"`
7. `Add_comment_to_incident_(V3)` — include Jira key and URL

**Update flow** (separate playbook with same incident update trigger):
1. `Initialize_variable_-_JiraKey` — extract from incident tags: `first(filter(tags, contains(tag, 'Jira-')))?['Tag']`
2. `Condition_-_Status_Changed` — check `updatedFields` contains "Status"
3. `Condition_-_Severity_Changed` — check `updatedFields` contains "Severity"
4. `Add_Comment_to_Issue` (jira) — sync note to Jira issue

---

## Category 13: Teams Adaptive Card with Analyst Approval

**Trigger:** Incident | **Connections:** azuresentinel, teams

Pattern: Build adaptive card → post to Teams and wait → branch on analyst response → update incident accordingly.

```json
"parameters": {
  "PlaybookName": { "defaultValue": "Teams-IncidentApproval", "type": "string" },
  "TeamId":       { "defaultValue": "", "type": "string" },
  "ChannelId":    { "defaultValue": "", "type": "string" }
},
"variables": {
  "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]",
  "teams":         "[concat('teams-', parameters('PlaybookName'))]"
}
```

**Action sequence:**
1. `Compose_-_Adaptive_Card` — build card with FactSet (incident fields) + Input.ChoiceSet + Input.Text
2. `Post_Adaptive_Card_and_Wait` (teams, `ApiConnectionWebhook`) — blocks until analyst submits
3. `Switch_-_Analyst_Decision` on `body(...)?['data']?['analystAction']`:
   - `"Escalate"` → `Update_incident` severity=High + tag
   - `"FalsePositive"` → close incident with analyst's comment as reason
   - `"Investigate"` → assign incident to analyst + add comment
4. `Add_comment_to_incident_(V3)` — record analyst name + decision

**Capture analyst identity:**
`@body('Post_Adaptive_Card_and_Wait')?['responder']?['displayName']`

---

## Category 14: TheHive Case Creation with Observables

**Trigger:** Incident | **Connections:** azuresentinel | **External:** TheHive API (HTTP)

Pattern: Create TheHive case from incident → extract entities → create observables for each entity type → create default tasks.

```json
"parameters": {
  "PlaybookName":     { "defaultValue": "TheHive-CreateCase", "type": "string" },
  "TheHiveURL":       { "defaultValue": "https://thehive.company.com", "type": "string" },
  "TheHiveAPIKey":    { "defaultValue": "", "type": "securestring" }
},
"variables": {
  "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]"
}
```

**Action sequence:**
1. `Entities_-_Get_Accounts` — extract accounts
2. `Entities_-_Get_Hosts` — extract hosts
3. `Entities_-_Get_IPs` — extract IPs
4. `HTTP_-_Create_TheHive_Case` — POST `/api/case`
   ```json
   {
     "title": "@{triggerBody()?['object']?['properties']?['title']}",
     "description": "Sentinel #@{triggerBody()?['object']?['properties']?['incidentNumber']}\n@{triggerBody()?['object']?['properties']?['description']}",
     "severity": "@{if(equals(triggerBody()?['object']?['properties']?['severity'], 'High'), 3, if(equals(triggerBody()?['object']?['properties']?['severity'], 'Medium'), 2, 1))}",
     "tlp": 2,
     "tags": ["sentinel", "@{triggerBody()?['object']?['properties']?['severity']}"]
   }
   ```
   Headers: `{ "Authorization": "Bearer @{parameters('TheHiveAPIKey')}" }`
5. `Parse_JSON_-_Case_Response` — extract `_id` (case ID)
6. `For_each_-_Account` — POST `/api/case/@{body(...)['_id']}/artifact` with `{ "dataType": "mail", "data": "UPN", "message": "Account entity" }`
7. `For_each_-_Host` — POST artifact with `{ "dataType": "hostname", "data": "hostname" }`
8. `For_each_-_IP` — POST artifact with `{ "dataType": "ip", "data": "ipAddress" }`
9. `HTTP_-_Create_Task` — POST `/api/case/@{caseId}/task` with `{ "title": "Investigate", "status": "Waiting" }`
10. `Add_comment_to_incident_(V3)` — link to TheHive case URL

---

## Category 15: Async Remediation (Tanium-Style Quarantine)

**Trigger:** Incident | **Entities:** Host | **Connections:** azuresentinel, keyvault | **External:** Tanium API (HTTP)

Pattern: Get hosts → retrieve API token from Key Vault → issue quarantine action → poll Until complete → report results.

```json
"parameters": {
  "PlaybookName":          { "defaultValue": "Tanium-QuarantineHost", "type": "string" },
  "KeyVaultName":          { "type": "string" },
  "TaniumAPITokenSecret":  { "defaultValue": "TaniumAPIToken", "type": "string" },
  "TaniumServer":          { "type": "string", "metadata": { "description": "Tanium server hostname" } }
},
"variables": {
  "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]",
  "keyvault":      "[concat('keyvault-', parameters('PlaybookName'))]"
}
```

**Action sequence:**
1. `Entities_-_Get_Hosts` — extract Host entities
2. `Get_API_Token` (keyvault) — get Tanium API token secret
3. `Initialize_variable_-_ResultSummary` — empty string
4. `For_each_-_Host` loop:
   a. `Initialize_variable_-_IsComplete` — boolean = false
   b. `Initialize_variable_-_ActionId` — string = ""
   c. `HTTP_-_Get_Package` — GET `/api/v2/packages?name=QuarantineHost` (find package ID)
   d. `HTTP_-_Issue_Action` — POST `/api/v2/actions` with package reference + target host
   e. `Set_variable_-_ActionId` — extract from response
   f. `Until_-_Wait_for_Completion` (limit: count=60, timeout=PT1H):
      - `Wait_10_Seconds`
      - `HTTP_-_Get_Action_Status` — GET `/api/v2/actions/{id}`
      - `Condition_-_Check_Status` — set `IsComplete = true` when status = "Completed" or "Failed"
   g. `Append_to_string_variable` — record hostname + final status
5. `Add_comment_to_incident_(V3)` — summary of all hosts actioned

---

## Category 16: Scheduled Threat Intel Ingestion with Pagination

**Trigger:** Recurrence (daily) | **Connections:** azuresentinel, azuremonitorlogs

Pattern: Run on schedule → fetch from threat intel API with pagination → for each result add/update watchlist entry.

```json
"parameters": {
  "PlaybookName":          { "defaultValue": "ThreatIntel-WatchlistRefresh", "type": "string" },
  "ThreatIntelAPIKey":     { "type": "securestring" },
  "WorkspaceName":         { "type": "string" },
  "WatchlistAlias":        { "defaultValue": "MaliciousIPs", "type": "string" }
},
"variables": {
  "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]"
}
```

**Trigger (no Sentinel connection needed):**
```json
"triggers": {
  "Recurrence": {
    "type": "Recurrence",
    "recurrence": { "frequency": "Day", "interval": 1, "timeZone": "UTC" }
  }
}
```

**Action sequence:**
1. `Initialize_variable_-_Offset` — integer = 0
2. `Initialize_variable_-_TotalResults` — integer = 1 (start > 0 so loop enters)
3. `Until_-_All_Pages_Fetched` (`expression: @greaterOrEquals(variables('Offset'), variables('TotalResults'))`, limit: count=100, timeout=PT2H):
   a. `HTTP_-_Fetch_Page` — GET TI API with `?limit=100&offset=@{variables('Offset')}`
   b. `Parse_JSON_-_Page` — extract `total`, `results`
   c. `Set_variable_-_TotalResults` — `@body(...)?['total']`
   d. `For_each_-_Result`:
      - `Add_to_Watchlist` — PUT `/Watchlists/.../watchlistItems/@{guid()}` with item properties
   e. `IncrementVariable_-_Offset` by 100
4. No incident comment (recurrence trigger has no incident context)

**Post-deployment:** Grant Logic App MSI the `Microsoft Sentinel Contributor` role for watchlist write access.

---

---

## Category 17: Watchlist-Based Auto-Triage (Close Known-Safe IPs)

**Pattern:** For each IP entity in the incident, query a watchlist via KQL. Collect safe vs. unknown IPs into two arrays. If ALL IPs are in the safe watchlist, close the incident as BenignPositive.

**Connections:** `azuresentinel` (MSI), `azuremonitorlogs` (OAuth)

**Parameters:**
- `PlaybookName` — string
- `WatchlistName` — string (watchlist must have an `ipaddress` column)

**Skeleton:**

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "metadata": {
    "title": "Watchlist - Close Incident Known IPs",
    "description": "Checks each IP entity against a safe-IPs watchlist. Closes incident as BenignPositive if all IPs are known-safe.",
    "prerequisites": ["Create a watchlist with a column named 'ipaddress'"],
    "postDeployment": [
      "Assign Microsoft Sentinel Responder to the Logic App MSI",
      "Assign Log Analytics Reader to the Logic App MSI on the workspace resource group"
    ],
    "entities": ["Ip"],
    "tags": ["Triage", "Watchlist"]
  },
  "parameters": {
    "PlaybookName": { "type": "string", "defaultValue": "Watchlist-CloseIncidentKnownIPs" },
    "WatchlistName": { "type": "string" }
  },
  "variables": {
    "AzureSentinelConnectionName": "[concat('azuresentinel-', parameters('PlaybookName'))]",
    "AzureMonitorLogsConnectionName": "[concat('azuremonitorlogs-', parameters('PlaybookName'))]"
  },
  "resources": [
    { /* azuresentinel connection — MSI pattern */ },
    { /* azuremonitorlogs connection — OAuth */ },
    {
      "type": "Microsoft.Logic/workflows",
      "identity": { "type": "SystemAssigned" },
      "dependsOn": ["[azuresentinel connection]", "[azuremonitorlogs connection]"],
      "properties": {
        "definition": {
          "triggers": { /* incident trigger */ },
          "actions": {
            "Initialize_variable_-_WatchlistName": {
              "type": "InitializeVariable",
              "inputs": { "variables": [{ "name": "WatchlistName", "type": "string", "value": "[parameters('WatchlistName')]" }] },
              "runAfter": {}
            },
            "Initialize_variable_-_SafeIPs": {
              "type": "InitializeVariable",
              "inputs": { "variables": [{ "name": "SafeIPs", "type": "array" }] },
              "runAfter": { "Initialize_variable_-_WatchlistName": ["Succeeded"] }
            },
            "Initialize_variable_-_notSafeIPs": {
              "type": "InitializeVariable",
              "inputs": { "variables": [{ "name": "notSafeIPs", "type": "array" }] },
              "runAfter": { "Initialize_variable_-_SafeIPs": ["Succeeded"] }
            },
            "Entities_-_Get_IPs": {
              "type": "ApiConnection",
              "inputs": {
                "body": "@triggerBody()?['object']?['properties']?['relatedEntities']",
                "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
                "method": "post",
                "path": "/entities/ip"
              },
              "runAfter": { "Initialize_variable_-_notSafeIPs": ["Succeeded"] }
            },
            "For_each": {
              "type": "Foreach",
              "foreach": "@body('Entities_-_Get_IPs')?['IPs']",
              "runtimeConfiguration": { "concurrency": { "repetitions": 1 } },
              "actions": {
                "Run_query_and_list_results": {
                  "type": "ApiConnection",
                  "inputs": {
                    "body": "_GetWatchlist(\"@{variables('WatchlistName')}\")\n| where ipaddress == \"@{items('For_each')?['Address']}\"",
                    "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
                    "method": "post",
                    "path": "/queryData",
                    "queries": {
                      "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
                      "resourcename": "@triggerBody()?['workspaceInfo']?['WorkspaceName']",
                      "resourcetype": "Log Analytics Workspace",
                      "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
                      "timerange": "Last 12 hours"
                    }
                  },
                  "runAfter": {}
                },
                "Condition_-_if_IP_found_in_watchlist": {
                  "type": "If",
                  "expression": { "and": [{ "greater": ["@length(body('Run_query_and_list_results')?['value'])", 0] }] },
                  "actions": {
                    "Append_to_SafeIPs": { "type": "AppendToArrayVariable", "inputs": { "name": "SafeIPs", "value": { "SafeIPs": "@{items('For_each')?['Address']}" } }, "runAfter": {} }
                  },
                  "else": {
                    "actions": {
                      "Append_to_notSafeIPs": { "type": "AppendToArrayVariable", "inputs": { "name": "notSafeIPs", "value": { "NotSafeIPs": "@{items('For_each')?['Address']}" } }, "runAfter": {} }
                    }
                  },
                  "runAfter": { "Run_query_and_list_results": ["Succeeded"] }
                }
              },
              "runAfter": { "Entities_-_Get_IPs": ["Succeeded"] }
            },
            "Create_HTML_table_-_safe": {
              "type": "Table",
              "inputs": { "format": "HTML", "from": "@variables('SafeIPs')" },
              "runAfter": { "For_each": ["Succeeded"] }
            },
            "Create_HTML_table_-_not_safe": {
              "type": "Table",
              "inputs": { "format": "HTML", "from": "@variables('notSafeIPs')" },
              "runAfter": { "Create_HTML_table_-_safe": ["Succeeded"] }
            },
            "Add_comment_to_incident": {
              "type": "ApiConnection",
              "inputs": {
                "body": {
                  "incidentArmId": "@triggerBody()?['object']?['id']",
                  "message": "<p>Watchlist check (@{variables('WatchlistName')}) results:<br>Safe IPs: @{body('Create_HTML_table_-_safe')}<br>Unknown IPs: @{body('Create_HTML_table_-_not_safe')}</p>"
                },
                "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
                "method": "post",
                "path": "/Incidents/Comment"
              },
              "runAfter": { "Create_HTML_table_-_not_safe": ["Succeeded"] }
            },
            "Condition_-_Close_if_all_safe": {
              "type": "If",
              "expression": { "and": [{ "equals": ["@length(variables('notSafeIPs'))", 0] }] },
              "actions": {
                "Update_incident": {
                  "type": "ApiConnection",
                  "inputs": {
                    "body": {
                      "classification": {
                        "ClassificationAndReason": "BenignPositive - SuspiciousButExpected",
                        "ClassificationReasonText": "All IPs found in safe watchlist @{variables('WatchlistName')}: @{join(variables('SafeIPs'), ', ')}"
                      },
                      "incidentArmId": "@triggerBody()?['object']?['id']",
                      "status": "Closed"
                    },
                    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
                    "method": "put",
                    "path": "/Incidents"
                  },
                  "runAfter": {}
                }
              },
              "runAfter": { "Add_comment_to_incident": ["Succeeded"] }
            }
          }
        }
      }
    }
  ]
}
```

**Action sequence:**
1. `Initialize_variable_-_WatchlistName` → `SafeIPs` (array) → `notSafeIPs` (array)
2. `Entities_-_Get_IPs` — extract IP entities from `relatedEntities`
3. `For_each` (sequential, `repetitions: 1`) — for each IP: query watchlist via KQL, append to SafeIPs or notSafeIPs
4. `Create_HTML_table_-_safe` + `Create_HTML_table_-_not_safe` — for incident comment formatting
5. `Add_comment_to_incident` — show both lists
6. `Condition` — if `length(notSafeIPs) == 0`: close incident as BenignPositive

**Variation:** For user watchlist, use `_GetWatchlist("<name>") | where upn == "<upn>"` and switch entity extraction to `/entities/account`.

---

## Category 18: OAuth2 Auth Sub-Playbook + Caller (Zscaler Pattern)

**Pattern:** Deploy a standalone "authentication" Logic App with an HTTP trigger that returns an OAuth2 token. Deploy one or more "action" Logic Apps that call the auth sub-playbook via `type: "Workflow"` before making API calls. The auth sub-playbook avoids embedding credentials in every action playbook.

**Auth sub-playbook connections:** None (HTTP action only, no managed connectors)

**Caller connections:** `azuresentinel` (MSI)

**Parameters for auth sub-playbook:**
- `PlaybookName` — string
- `OAuthClientId` — string
- `OAuthClientSecret` — securestring
- `OAuthTokenUrl` — string

**Parameters for caller:**
- `PlaybookName` — string
- `ZscalerAuthPlaybook` — string (name of the auth sub-playbook, used to build resource ID)
- `BlockCategory` — string

**Auth sub-playbook skeleton:**

```json
{
  "type": "Microsoft.Logic/workflows",
  "identity": { "type": "SystemAssigned" },
  "properties": {
    "definition": {
      "parameters": {
        "clientId": { "defaultValue": "[parameters('OAuthClientId')]", "type": "String" },
        "clientSecret": { "defaultValue": "[parameters('OAuthClientSecret')]", "type": "SecureString" },
        "oauthUrl": { "defaultValue": "[parameters('OAuthTokenUrl')]", "type": "String" }
      },
      "triggers": {
        "manual": { "type": "Request", "kind": "Http", "inputs": {} }
      },
      "actions": {
        "HTTP_Get_OAuth_Token": {
          "type": "Http",
          "inputs": {
            "body": "grant_type=client_credentials&client_id=@{encodeUriComponent(parameters('clientId'))}&client_secret=@{encodeUriComponent(parameters('clientSecret'))}",
            "headers": { "Content-Type": "application/x-www-form-urlencoded" },
            "method": "POST",
            "uri": "@parameters('oauthUrl')"
          },
          "runtimeConfiguration": { "secureData": { "properties": ["inputs", "outputs"] } },
          "runAfter": {}
        },
        "Parse_Token_Response": {
          "type": "ParseJson",
          "inputs": {
            "content": "@body('HTTP_Get_OAuth_Token')",
            "schema": { "properties": { "access_token": { "type": "string" }, "token_type": { "type": "string" }, "expires_in": { "type": "integer" } }, "type": "object" }
          },
          "runAfter": { "HTTP_Get_OAuth_Token": ["Succeeded"] }
        },
        "Response": {
          "type": "Response",
          "kind": "Http",
          "inputs": {
            "statusCode": 200,
            "body": "@body('HTTP_Get_OAuth_Token')",
            "headers": { "Content-Type": "application/json" }
          },
          "runAfter": { "Parse_Token_Response": ["Succeeded"] }
        }
      }
    },
    "parameters": {
      "clientId": { "value": "[parameters('OAuthClientId')]" },
      "clientSecret": { "value": "[parameters('OAuthClientSecret')]" },
      "oauthUrl": { "value": "[parameters('OAuthTokenUrl')]" }
    }
  }
}
```

**Caller variables block (build auth sub-playbook resource ID):**
```json
"variables": {
  "AzureSentinelConnectionName": "[concat('azuresentinel-', parameters('PlaybookName'))]",
  "AuthPlaybookId": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Logic/workflows/', parameters('ZscalerAuthPlaybook'))]"
}
```

**Caller action sequence:**
1. `InitializeVariable` — Category = `[parameters('BlockCategory')]`
2. `Entities_-_Get_IPs` — `/entities/ip`
3. `Invoke_Auth_Sub_Playbook` (`type: "Workflow"`, `host.workflow.id: "[variables('AuthPlaybookId')]"`, `host.triggerName: "manual"`)
4. `Parse_Authentication_Response` — extract `access_token`, `token_type`
5. `For_each` (sequential) — for each IP:
   - `HTTP_Add_IP` — PUT to ZIA API with `Authorization: "@{concat(body('Parse_Authentication_Response')?['token_type'], ' ', body('Parse_Authentication_Response')?['access_token'])}"`
   - `HTTP_Activate_Changes` — POST `/status/activate`
   - `Add_comment_to_incident`

**Post-deployment:**
1. Deploy auth sub-playbook first
2. Deploy caller playbook, passing the auth sub-playbook name as a parameter
3. Grant caller Logic App MSI `Microsoft Sentinel Responder` role
4. Grant caller Logic App MSI `Logic App Contributor` on the auth sub-playbook (or use resource group scope)

---

## Category 19: VMware Carbon Black Cloud — Device Quarantine via Custom Connector

**Pattern:** Deploys a `Microsoft.Web/customApis` custom connector first (separate template or nested deployment), then the action playbook uses it. The custom connector uses an API key in the `X-Auth-Token` security definition.

**Connections:** `azuresentinel` (MSI), `CarbonBlackCloudConnector` (custom, API key)

**Two-template deployment:**
1. First template: deploy `Microsoft.Web/customApis` (CarbonBlackConnector/azuredeploy.json)
2. Second template: deploy the action Logic App referencing the custom connector

**Action playbook parameters:**
- `PlaybookName` — string
- `CustomConnectorName` — string (must match deployed custom API name)
- `OrgKey` — string (Carbon Black org key)

**Connection resource for the custom connector:**
```json
{
  "type": "Microsoft.Web/connections",
  "name": "[variables('CBConnectionName')]",
  "properties": {
    "displayName": "[variables('CBConnectionName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/customApis/', parameters('CustomConnectorName'))]"
    }
  }
}
```

**`$connections` wire-up:**
```json
"CarbonBlackCloudConnector": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('CBConnectionName'))]",
  "connectionName": "[variables('CBConnectionName')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/customApis/', parameters('CustomConnectorName'))]"
}
```

**Device search action:**
```json
"CBC_Search_Device": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "criteria": { "status": ["ACTIVE"] },
      "query": "name:@{items('For_each')?['HostName']}"
    },
    "host": { "connection": { "name": "@parameters('$connections')['CarbonBlackCloudConnector']['connectionId']" } },
    "method": "post",
    "path": "/appservices/v6/orgs/@{encodeURIComponent(parameters('OrgKey'))}/devices/_search"
  },
  "runAfter": {}
}
```

**Device quarantine action:**
```json
"CBC_Quarantine_Device": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "action_type": "QUARANTINE",
      "device_id": ["@{body('Parse_JSON_-_Device')?['results'][0]?['id']}"],
      "options": { "toggle": "ON" }
    },
    "host": { "connection": { "name": "@parameters('$connections')['CarbonBlackCloudConnector']['connectionId']" } },
    "method": "post",
    "path": "/appservices/v6/orgs/@{encodeURIComponent(parameters('OrgKey'))}/device_actions"
  },
  "runAfter": { "Parse_JSON_-_Device": ["Succeeded"] }
}
```

**Post-deployment:** Sign in to the custom connector connection in the Azure Portal with the Carbon Black API key. Format: `<API_ID>/<API_SECRET_KEY>` as the API Key value.

---

## Deployment Checklist

Before finalizing any playbook ARM template:

- [ ] Every connection has a corresponding `Microsoft.Web/connections` resource
- [ ] Every connection is listed in `dependsOn` of the Logic App
- [ ] Every connection is wired in `$connections.value`
- [ ] `azuresentinel` uses `parameterValueType: "Alternative"` and MSI `connectionProperties`
- [ ] `keyvault` uses `parameterValueType: "Alternative"` with `alternativeParameterValues.vaultName`
- [ ] Logic App has `"identity": { "type": "SystemAssigned" }`
- [ ] All secrets are `securestring` parameters (never `string`)
- [ ] `metadata.postDeployment` lists all required manual RBAC assignments
- [ ] `metadata.entities` lists all entity types the playbook processes
- [ ] First action has `"runAfter": {}` (empty object, not omitted)
- [ ] Every variable is initialized before its first use and before any loops
- [ ] Loop variables are initialized outside the loop, reset with `SetVariable` inside if needed
- [ ] HTTP responses are parsed with `ParseJson` before field access
