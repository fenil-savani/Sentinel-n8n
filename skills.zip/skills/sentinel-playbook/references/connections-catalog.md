# Connections Catalog Reference

> Parent skill: [sentinel-playbooks](../SKILL.md)

Every API used in a playbook requires a `Microsoft.Web/connections` resource AND a corresponding entry in the Logic App's `$connections` parameter. This reference covers every connector seen in production Sentinel playbooks.

## Pattern: Connection Variable + Declaration + Wiring

For each connector used, follow this three-part pattern:

**1. Variable** (in `variables` block):
```json
"azuread": "[concat('azuread-', parameters('PlaybookName'))]"
```

**2. Resource** (sibling of the Logic App in `resources` array):
```json
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('azuread')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]"
    }
  }
}
```

**3. `$connections` wiring** (inside Logic App `parameters.$connections.value`):
```json
"azuread": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuread'))]",
  "connectionName": "[variables('azuread')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]"
}
```

**4. `dependsOn`** entry in the Logic App resource:
```json
"[resourceId('Microsoft.Web/connections', variables('azuread'))]"
```

---

## Microsoft Sentinel (`azuresentinel`)

**ManagedApi ID:** `azuresentinel`  
**Auth:** Managed Service Identity (MSI) — **always use Alternative auth**  
**Permissions needed:** Microsoft Sentinel Responder (minimum)

```json
/* Variable */
"azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('azuresentinel')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "parameterValueType": "Alternative",
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuresentinel')]"
    }
  }
}

/* $connections wiring — ALWAYS include connectionProperties for MSI */
"azuresentinel": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuresentinel'))]",
  "connectionName": "[variables('azuresentinel')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuresentinel')]",
  "connectionProperties": {
    "authentication": { "type": "ManagedServiceIdentity" }
  }
}
```

**Common actions:**

| Action | Method | Path |
|--------|--------|------|
| Get Account entities | POST | `/entities/account` |
| Get Host entities | POST | `/entities/host` |
| Get IP entities | POST | `/entities/ip` |
| Get URL entities | POST | `/entities/url` |
| Get FileHash entities | POST | `/entities/filehash` |
| Add comment to incident | POST | `/Incidents/Comment` |
| Update incident | PUT | `/Incidents` |
| Close incident | PUT | `/Incidents` (status: Closed) |
| List incidents | GET | `/Cases` |

---

## Azure Active Directory / Entra ID (`azuread`)

**ManagedApi ID:** `azuread`  
**Auth:** OAuth (user must authorize during deployment)  
**Permissions:** User.ReadWrite.All or Directory.ReadWrite.All

```json
/* Variable */
"azuread": "[concat('azuread-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('azuread')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]"
    }
  }
}

/* $connections wiring */
"azuread": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuread'))]",
  "connectionName": "[variables('azuread')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]"
}
```

**Common actions (ApiConnection):**

| Action | Method | Path |
|--------|--------|------|
| Disable user (`accountEnabled: false`) | PATCH | `/v1.0/users/@{encodeURIComponent(userId)}` |
| Enable user (`accountEnabled: true`) | PATCH | `/v1.0/users/@{encodeURIComponent(userId)}` |
| Get user | GET | `/v1.0/users/@{encodeURIComponent(userId)}` |
| Add user to group | POST | `/v1.0/groups/@{groupId}/members/$ref` |
| Remove user from group | DELETE | `/v1.0/groups/@{groupId}/members/@{userId}/$ref` |

> **Note:** For revokeSignInSessions and other Graph API operations not covered by the managed connector, use an HTTP action with an App Registration + Key Vault secret. See [action-patterns.md — OAuth2 Client Credentials](action-patterns.md).

---

## Azure Key Vault (`keyvault`)

**ManagedApi ID:** `keyvault`  
**Auth:** MSI (Alternative) — Logic App's Managed Identity must have `Key Vault Secrets User` role  
**Parameters needed:** `KeyVaultName` — pass in `alternativeParameterValues`

```json
/* Parameter */
"KeyVaultName": { "type": "string", "metadata": { "description": "Name of the Key Vault" } }

/* Variable */
"keyvault": "[concat('keyvault-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('keyvault')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "parameterValueType": "Alternative",
    "alternativeParameterValues": {
      "vaultName": "[parameters('KeyVaultName')]"
    },
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/keyvault')]"
    }
  }
}

/* $connections wiring */
"keyvault": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('keyvault'))]",
  "connectionName": "[variables('keyvault')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/keyvault')]",
  "connectionProperties": {
    "authentication": { "type": "ManagedServiceIdentity" }
  }
}
```

**Get secret action:**
```json
"Get_Secret": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['keyvault']['connectionId']" } },
    "method": "get",
    "path": "[concat('/secrets/@{encodeURIComponent(''', parameters('KeyVaultSecretName'), ''')}/value')]"
  }
}
```
Access value: `@body('Get_Secret')?['value']`

---

## Office 365 / Outlook (`office365`)

**ManagedApi ID:** `office365`  
**Auth:** OAuth (authorizing user's mailbox is the sender)  
**Parameters needed:** Deployer's username for `displayName`

```json
/* Variable */
"office365": "[concat('o365-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('office365')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "[parameters('UserName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/office365')]"
    }
  }
}
```

**Send email action:**
```json
"Send_an_email_(V2)": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "To": "[parameters('MailList')]",
      "Subject": "Sentinel Incident: @{triggerBody()?['object']?['properties']?['title']}",
      "Body": "<p>Incident details here</p>",
      "Importance": "High"
    },
    "host": { "connection": { "name": "@parameters('$connections')['office365']['connectionId']" } },
    "method": "post",
    "path": "/v2/Mail"
  }
}
```

---

## Microsoft Teams (`teams`)

**ManagedApi ID:** `teams`  
**Auth:** OAuth  
**Parameters needed:** Team ID, Channel ID

```json
/* Variable */
"teams": "[concat('teams-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('teams')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/teams')]"
    }
  }
}
```

**Post message action:**
```json
"Post_message_in_a_chat_or_channel": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "recipient": {
        "groupId": "[parameters('TeamId')]",
        "channelId": "[parameters('ChannelId')]"
      },
      "messageBody": "<p><b>New Sentinel Incident</b><br>Title: @{triggerBody()?['object']?['properties']?['title']}<br>Severity: @{triggerBody()?['object']?['properties']?['severity']}</p>"
    },
    "host": { "connection": { "name": "@parameters('$connections')['teams']['connectionId']" } },
    "method": "post",
    "path": "/beta/teams/conversation/message/poster/Flow bot/location/@{encodeURIComponent('channel')}"
  }
}
```

---

## Azure Monitor Logs / Log Analytics (`azuremonitorlogs`)

**ManagedApi ID:** `azuremonitorlogs`  
**Auth:** OAuth  
**Use for:** Running KQL queries against the Sentinel Log Analytics workspace

```json
/* Variable */
"azuremonitorlogs": "[concat('azuremon-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('azuremonitorlogs')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "[parameters('UserName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuremonitorlogs')]"
    }
  }
}
```

**Query actions — two variants:**

*List results (JSON array):*
```json
"Run_query_and_list_results": {
  "type": "ApiConnection",
  "inputs": {
    "body": "SecurityEvent | where TimeGenerated > ago(1h) | limit 50",
    "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
    "method": "post",
    "path": "/queryData",
    "queries": {
      "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
      "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
      "resourcetype": "Log Analytics Workspace",
      "resourcename": "[parameters('WorkspaceName')]",
      "timerange": "Last 24 hours"
    }
  }
}
```
Access: `@body('Run_query_and_list_results')?['value']` → array

*HTML visualization (for incident comments):*
```json
"path": "/visualizeQuery",
"queries": {
  /* same workspace queries */,
  "visType": "Html Table"
}
```
Access: `@{base64ToString(body('Run_query_and_visualize_results')?['attachmentContent'])}` → HTML string

---

## Azure Log Analytics Data Collector (`azureloganalyticsdatacollector`)

**ManagedApi ID:** `azureloganalyticsdatacollector`  
**Auth:** Workspace ID + Key (passed as `parameterValues`)  
**Use for:** Sending enrichment data into a custom Log Analytics table

```json
/* Parameters */
"WorkspaceId": { "type": "string" },
"WorkspaceKey": { "type": "securestring" }

/* Variable */
"azureloganalyticsdatacollector": "[concat('azureloganalyticsdatacollector-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('azureloganalyticsdatacollector')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "SendtoLogAnalytics",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azureloganalyticsdatacollector')]"
    },
    "parameterValues": {
      "username": "[parameters('WorkspaceId')]",
      "password": "[parameters('WorkspaceKey')]"
    }
  }
}
```

**Send data action:**
```json
"Send_Data": {
  "type": "ApiConnection",
  "inputs": {
    "body": "@{body('Compose_Result')}",
    "headers": {
      "Log-Type": "CustomTableName_CL",
      "time-generated-field": "@triggerBody()?['object']?['properties']?['createdTimeUtc']"
    },
    "host": { "connection": { "name": "@parameters('$connections')['azureloganalyticsdatacollector']['connectionId']" } },
    "method": "post",
    "path": "/api/logs"
  }
}
```

---

## ServiceNow (`service-now`)

**ManagedApi ID:** `service-now`  
**Auth:** Basic or OAuth  
**Parameters needed:** ServiceNow instance URL, username, password

```json
/* Variable */
"servicenow": "[concat('servicenow-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('servicenow')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/service-now')]"
    }
  }
}
```

**Create incident action:**
```json
"Create_Record": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "short_description": "Sentinel: @{triggerBody()?['object']?['properties']?['title']}",
      "description": "Severity: @{triggerBody()?['object']?['properties']?['severity']}\nLink: @{triggerBody()?['object']?['properties']?['incidentUrl']}",
      "urgency": "1",
      "impact": "1",
      "category": "Security"
    },
    "host": { "connection": { "name": "@parameters('$connections')['service-now']['connectionId']" } },
    "method": "post",
    "path": "/api/now/v2/table/@{encodeURIComponent('incident')}"
  }
}
```

---

## Zendesk (`zendesk`)

**ManagedApi ID:** `zendesk`  
**Auth:** OAuth or API token  
**Parameters needed:** Subdomain, requester_id

```json
/* Variable */
"zendesk": "[concat('zendesk-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('zendesk')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "[variables('zendesk')]",
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/zendesk')]"
    }
  }
}
```

**Create ticket action:**
```json
"Create_Item": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "subject": "@{triggerBody()?['object']?['properties']?['incidentNumber']} - @{triggerBody()?['object']?['properties']?['title']}",
      "description": "Severity: @{triggerBody()?['object']?['properties']?['severity']}\nLink: @{triggerBody()?['object']?['properties']?['incidentUrl']}",
      "external_id": "@{triggerBody()?['object']?['properties']?['incidentNumber']}",
      "requester_id": "[parameters('requester_id')]",
      "type": "incident"
    },
    "host": { "connection": { "name": "@parameters('$connections')['zendesk']['connectionId']" } },
    "method": "post",
    "path": "/datasets/default/tables/@{encodeURIComponent(encodeURIComponent('tickets'))}/items"
  }
}
```

---

## Slack (HTTP — no managed connector)

Slack is accessed via direct HTTP webhook — no managed connector required. Store the Webhook URL or OAuth token as a parameter.

```json
/* Parameter */
"SlackWebhookUrl": { "type": "securestring" }
/* OR */
"OAuthToken": { "type": "securestring" },
"ChannelId": { "type": "string" }
```

**Webhook post:**
```json
"HTTP_-_Post_Slack_Message": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[parameters('SlackWebhookUrl')]",
    "headers": { "Content-Type": "application/json" },
    "body": {
      "text": "🚨 *New Sentinel Incident*\n*Title:* @{triggerBody()?['object']?['properties']?['title']}\n*Severity:* @{triggerBody()?['object']?['properties']?['severity']}\n*URL:* @{triggerBody()?['object']?['properties']?['incidentUrl']}"
    }
  }
}
```

**Bot API post (with OAuth token):**
```json
"HTTP_-_Post_Slack_Message": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://slack.com/api/chat.postMessage",
    "headers": {
      "Authorization": "[concat('Bearer ', parameters('OAuthToken'))]",
      "Content-type": "application/json; charset=utf-8"
    },
    "body": {
      "channel": "[parameters('ChannelId')]",
      "blocks": [
        {
          "type": "section",
          "text": { "type": "mrkdwn", "text": "*@{triggerBody()?['object']?['properties']?['title']}*" }
        }
      ]
    }
  }
}
```

---

## PagerDuty (HTTP)

```json
/* Parameter */
"PagerDutyIntegrationKey": { "type": "securestring" }
```

```json
"HTTP_-_Create_PagerDuty_Incident": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://events.pagerduty.com/v2/enqueue",
    "headers": { "Content-Type": "application/json" },
    "body": {
      "routing_key": "@parameters('PagerDutyIntegrationKey')",
      "event_action": "trigger",
      "payload": {
        "summary": "Sentinel: @{triggerBody()?['object']?['properties']?['title']}",
        "severity": "@{if(equals(triggerBody()?['object']?['properties']?['severity'], 'High'), 'critical', if(equals(triggerBody()?['object']?['properties']?['severity'], 'Medium'), 'error', 'warning'))}",
        "source": "Microsoft Sentinel",
        "custom_details": {
          "incident_url": "@{triggerBody()?['object']?['properties']?['incidentUrl']}",
          "incident_number": "@{triggerBody()?['object']?['properties']?['incidentNumber']}"
        }
      }
    }
  }
}
```

---

## Microsoft Defender for Endpoint (HTTP + App Registration)

MDE is accessed via the Security Center API using client credentials. Requires App Registration with `Machine.Isolate`, `Machine.Read.All`, etc.

**Token acquisition:** See [action-patterns.md — OAuth2 Client Credentials](action-patterns.md).

```json
/* Common MDE API calls */

/* Isolate machine */
"HTTP_-_Isolate_Machine": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.securitycenter.microsoft.com/api/machines/@{items('For_each')?['additionalData']?['MdatpDeviceId']}/isolate",
    "headers": { "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}" },
    "body": {
      "Comment": "Isolated by Sentinel playbook",
      "IsolationType": "Full"
    }
  }
}

/* Get machine actions */
"HTTP_-_Get_Machine_Actions": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.securitycenter.microsoft.com/api/machineactions?$filter=machineId eq '@{variables('machineId')}'",
    "headers": { "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}" }
  }
}
```

---

## Microsoft Graph API (HTTP + App Registration)

Direct Graph calls for operations not covered by the `azuread` managed connector.

```json
/* Revoke sign-in sessions */
"HTTP_-_Revoke_Sessions": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://graph.microsoft.com/v1.0/users/@{variables('UPN')}/revokeSignInSessions",
    "headers": {
      "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}",
      "Content-Type": "application/json"
    }
  }
}

/* Delete app registration */
"HTTP_-_Delete_App": {
  "type": "Http",
  "inputs": {
    "method": "DELETE",
    "uri": "https://graph.microsoft.com/v1.0/applications/@{items('For_each')?['id']}",
    "headers": { "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}" }
  }
}
```

---

---

## Jira (`jira`)

**ManagedApi ID:** `jira`  
**Auth:** OAuth (Atlassian account)  
**Parameters needed:** Jira base URL, project key

```json
/* Variable */
"jira": "[concat('jira-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('jira')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/jira')]"
    }
  }
}

/* $connections wiring */
"jira": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('jira'))]",
  "connectionName": "[variables('jira')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/jira')]"
}
```

**Create issue action:**
```json
"Create_a_new_issue": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "fields": {
        "project": { "key": "[parameters('JiraProjectKey')]" },
        "summary": "Sentinel #@{triggerBody()?['object']?['properties']?['incidentNumber']}: @{triggerBody()?['object']?['properties']?['title']}",
        "description": "Severity: @{triggerBody()?['object']?['properties']?['severity']}\nIncident URL: @{triggerBody()?['object']?['properties']?['incidentUrl']}\nDescription: @{triggerBody()?['object']?['properties']?['description']}",
        "issuetype": { "id": "10001" },
        "priority": { "id": "@{variables('JiraPriorityId')}" }
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['jira']['connectionId']" } },
    "method": "post",
    "path": "/issue"
  }
}
```

Access created issue key: `@body('Create_a_new_issue')?['key']` (e.g. `SEC-1234`)

**Add comment to existing issue:**
```json
"Add_Comment_to_Issue": {
  "type": "ApiConnection",
  "inputs": {
    "body": { "body": "Update from Sentinel: @{variables('UpdateNote')}" },
    "host": { "connection": { "name": "@parameters('$connections')['jira']['connectionId']" } },
    "method": "post",
    "path": "/issue/@{variables('JiraIssueKey')}/comment"
  }
}
```

**Jira priority IDs (map from Sentinel severity via Switch):**

| Sentinel Severity | Jira Priority ID | Label |
|-------------------|-----------------|-------|
| High | `1` | Highest |
| Medium | `2` | High |
| Low | `3` | Medium |
| Informational | `4` | Low |

---

## Okta (`okta`)

**ManagedApi ID:** `okta`  
**Auth:** API Token (passed as `parameterValues`)  
**Parameters needed:** Okta domain, API token

```json
/* Variable */
"okta": "[concat('okta-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('okta')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/okta')]"
    },
    "parameterValues": {
      "token:ApiKey": "[parameters('OktaAPIToken')]",
      "domain": "[parameters('OktaDomain')]"
    }
  }
}
```

**Get user action:**
```json
"Get_User": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['okta']['connectionId']" } },
    "method": "get",
    "path": "/api/v1/users/@{encodeURIComponent(items('For_each')?['accountName'])}"
  }
}
```

**Get user groups:**
```json
"Get_User_Groups": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['okta']['connectionId']" } },
    "method": "get",
    "path": "/api/v1/users/@{encodeURIComponent(body('Get_User')?['id'])}/groups"
  }
}
```

Access user fields: `body('Get_User')?['profile']?['login']`, `body('Get_User')?['profile']?['email']`, `body('Get_User')?['status']`

**Suspend user:**
```json
"Suspend_User": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['okta']['connectionId']" } },
    "method": "post",
    "path": "/api/v1/users/@{encodeURIComponent(body('Get_User')?['id'])}/lifecycle/suspend"
  }
}
```

---

## Slack Managed Connector (`slack`)

**ManagedApi ID:** `slack`  
**Auth:** OAuth  
**Note:** Use this for simple channel messages. For advanced Block Kit formatting, use HTTP action instead.

```json
/* Variable */
"slack": "[concat('slack-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('slack')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/slack')]"
    }
  }
}
```

**Post message action:**
```json
"Post_Message": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "channel": "[parameters('SlackChannelName')]",
      "text": "🚨 Sentinel Incident #@{triggerBody()?['object']?['properties']?['incidentNumber']}\n*@{triggerBody()?['object']?['properties']?['title']}*\nSeverity: @{triggerBody()?['object']?['properties']?['severity']}\n@{triggerBody()?['object']?['properties']?['incidentUrl']}"
    },
    "host": { "connection": { "name": "@parameters('$connections')['slack']['connectionId']" } },
    "method": "post",
    "path": "/chat.postMessage"
  }
}
```

---

## Azure Function App (`azurefunction`)

**Use for:** Calling Azure Functions that wrap external APIs (AWS, on-prem systems, complex logic).  
**Auth:** MSI or Function key  
**Parameters needed:** Function App resource ID or name

```json
/* Variable */
"azurefunction": "[concat('azurefunction-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('azurefunction')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azurefunctions')]"
    }
  }
}
```

**Call function action:**
```json
"Call_Azure_Function": {
  "type": "Function",
  "inputs": {
    "function": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/sites/', parameters('FunctionAppName'), '/functions/', parameters('FunctionName'))]"
    },
    "body": {
      "HostName": "@{items('For_each')?['HostName']}",
      "Action": "Quarantine"
    },
    "method": "POST"
  }
}
```

Access result: `@body('Call_Azure_Function')?['status']`

---

## Custom Connector (`customconnectors`)

When a solution ships a custom Logic App connector (not a built-in managed API), reference it by GUID:

```json
/* Parameter */
"CustomConnectorName": {
  "defaultValue": "MyCustomConnector",
  "type": "string",
  "metadata": { "description": "Name of the deployed custom connector resource" }
}

/* Variable */
"customconnector": "[concat('customconnector-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('customconnector')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/customApis/', parameters('CustomConnectorName'))]"
    }
  }
}

/* $connections wiring */
"customconnector": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('customconnector'))]",
  "connectionName": "[variables('customconnector')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/customApis/', parameters('CustomConnectorName'))]"
}
```

The custom connector action shape is identical to managed connectors — `type: "ApiConnection"` with the connection name referencing the custom connector key.

---

## GitHub (`github`)

**ManagedApi ID:** `github`  
**Auth:** OAuth

```json
/* Variable */
"github": "[concat('github-', parameters('PlaybookName'))]"

/* Resource */
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('github')]",
  "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/github')]"
    }
  }
}
```

**Create issue action:**
```json
"Create_GitHub_Issue": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "title": "Sentinel Incident: @{triggerBody()?['object']?['properties']?['title']}",
      "body": "**Severity:** @{triggerBody()?['object']?['properties']?['severity']}\n**URL:** @{triggerBody()?['object']?['properties']?['incidentUrl']}",
      "labels": ["security", "sentinel"]
    },
    "host": { "connection": { "name": "@parameters('$connections')['github']['connectionId']" } },
    "method": "post",
    "path": "/repos/@{encodeURIComponent(parameters('RepoOwner'))}/@{encodeURIComponent(parameters('RepoName'))}/issues"
  }
}
```

---

## 10. SIGNL4

Mobile alerting and incident response. Standard managed connector — OAuth sign-in.

**ARM connection resource:**
```json
{
  "type": "Microsoft.Web/connections",
  "apiVersion": "2016-06-01",
  "name": "[variables('SIGNL4ConnectionName')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "displayName": "[variables('SIGNL4ConnectionName')]",
    "api": {
      "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/signl4')]"
    }
  }
}
```

**Trigger alert action:**
```json
"Trigger_Alert": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "flags": 0,
      "severity": 0,
      "text": "@triggerBody()?['object']?['properties']?['description']",
      "title": "@triggerBody()?['object']?['properties']?['title']"
    },
    "host": { "connection": { "name": "@parameters('$connections')['signl4']['connectionId']" } },
    "method": "post",
    "path": "/alerts"
  }
}
```

**`$connections` wire-up** (no MSI — uses OAuth, post-deploy sign-in):
```json
"signl4": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('SIGNL4ConnectionName'))]",
  "connectionName": "[variables('SIGNL4ConnectionName')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/signl4')]"
}
```

---

## 11. VMware Carbon Black Cloud (Custom Connector)

Carbon Black Cloud uses a `Microsoft.Web/customApis` custom connector with an API key in the `X-Auth-Token` header. Org key is a URL path parameter.

**ARM custom API resource:**
```json
{
  "type": "Microsoft.Web/customApis",
  "apiVersion": "2016-06-01",
  "name": "[parameters('CustomConnectorName')]",
  "location": "[resourceGroup().location]",
  "properties": {
    "connectionParameters": {
      "api_key": {
        "type": "securestring",
        "uiDefinition": {
          "displayName": "API Key",
          "description": "The API Key for this api",
          "tooltip": "Provide your API Key",
          "constraints": { "clearText": false, "required": "true" }
        }
      }
    },
    "backendService": {
      "serviceUrl": "[parameters('ServiceEndPoint')]"
    },
    "displayName": "[parameters('CustomConnectorName')]",
    "swagger": { /* OpenAPI spec — see CarbonBlackConnector/azuredeploy.json */ }
  }
}
```

**Key API paths in the swagger:**

| Path | Method | Purpose |
|------|--------|---------|
| `/appservices/v6/orgs/{org_key}/devices/_search` | POST | Search devices by status, OS, policy ID |
| `/appservices/v6/orgs/{org_key}/device_actions` | POST | QUARANTINE / UPDATE_POLICY on device list |
| `/appservices/v6/orgs/{org_key}/alerts/{alert_id}/workflow` | POST | Dismiss or reopen alert |
| `/appservices/v6/orgs/{org_key}/alerts/{alert_id}/notes` | POST | Add note to alert |

**Device quarantine action body:**
```json
{
  "action_type": "QUARANTINE",
  "device_id": ["@{items('For_each')?['id']}"],
  "options": { "toggle": "ON" }
}
```

**`$connections` wire-up** (custom connector — uses API key):
```json
"CarbonBlackCloudConnector": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('CBConnectionName'))]",
  "connectionName": "[variables('CBConnectionName')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/customApis/', parameters('CustomConnectorName'))]"
}
```

**Post-deployment:** User must sign in to the custom connector with their Carbon Black API Key.

---

## 12. Zscaler Internet Access (OAuth2 Sub-Playbook Pattern)

Zscaler uses an HTTP trigger sub-playbook for OAuth2 token acquisition. The main playbook calls it via `type: "Workflow"` and gets the token back from the response body.

**No dedicated managed connector — all calls are HTTP actions using the OAuth2 token.**

**Key API endpoints:**

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `[OAuthTokenUrl]` | POST | Acquire OAuth2 access token (x-www-form-urlencoded) |
| `https://api.zsapi.net/zia/api/v1/urlCategories/{category}?action=ADD_TO_LIST` | PUT | Add URL/IP to block category |
| `https://api.zsapi.net/zia/api/v1/urlCategories/{category}?action=REMOVE_FROM_LIST` | PUT | Remove from block category |
| `https://api.zsapi.net/zia/api/v1/status/activate` | POST | Activate pending changes |

**Auth sub-playbook variable reference (in caller):**
```json
"ZscalerAuthenticationFlow": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Logic/workflows/', parameters('Zscaler OAuth2 Authentication Playbook'))]"
```

**Caller action — invoke auth sub-playbook:**
```json
"zscaler": {
  "type": "Workflow",
  "inputs": {
    "host": {
      "triggerName": "manual",
      "workflow": { "id": "[variables('ZscalerAuthenticationFlow')]" }
    }
  },
  "runAfter": { "Entities_-_Get_IPs": ["Succeeded"] }
}
```

**Use token from sub-playbook response:**
```json
"Authorization": "@{concat(body('Parse_Authentication_Response')?['token_type'], ' ', body('Parse_Authentication_Response')?['access_token'])}"
```

**Post-deployment:** Grant Logic App MSI `Microsoft Sentinel Responder` on the workspace. Deploy the `Zscaler-Oauth2-Authentication` playbook first and pass its name as a parameter.

---

## 13. Cisco Umbrella (Custom Connector)

Cisco Umbrella Enforcement API uses a custom connector with Basic auth. URL-to-domain extraction is done inline.

**`parameterValues` for basic auth:**
```json
"parameterValues": {
  "authType": "basic",
  "username": "[parameters('APIKey')]",
  "password": ""
}
```

**Domain extraction from URL:**
```
@{split(replace(replace(items('For_each')?['Url'],'http://',''),'https://',''),'/')[0]}
```

**Block domain action:**
```json
"HTTP_-_BlockDomain": {
  "type": "ApiConnection",
  "inputs": {
    "body": [{ "identifierType": "domain", "identifier": "@{split(replace(replace(items('For_each')?['Url'],'http://',''),'https://',''),'/')[0]}" }],
    "host": { "connection": { "name": "@parameters('$connections')['CiscoUmbrellaConnector']['connectionId']" } },
    "method": "post",
    "path": "/1.0/events"
  }
}
```

---

## Quick-Reference: ManagedApi IDs

| Service | ManagedApi ID | Auth Type |
|---------|--------------|-----------|
| Microsoft Sentinel | `azuresentinel` | MSI (Alternative) |
| Azure Active Directory | `azuread` | OAuth |
| Key Vault | `keyvault` | MSI (Alternative) |
| Office 365 | `office365` | OAuth |
| Microsoft Teams | `teams` | OAuth |
| Log Analytics (query) | `azuremonitorlogs` | OAuth |
| Log Analytics (ingest) | `azureloganalyticsdatacollector` | Workspace ID/Key |
| ServiceNow | `service-now` | Basic/OAuth |
| Zendesk | `zendesk` | OAuth/API Token |
| Jira | `jira` | OAuth |
| Okta | `okta` | API Token |
| Slack (managed) | `slack` | OAuth |
| Slack (advanced) | HTTP (no connector) | OAuth Token / Webhook |
| GitHub | `github` | OAuth |
| PagerDuty | HTTP (no connector) | Integration Key |
| SIGNL4 | `signl4` | OAuth |
| Azure Function | `azurefunctions` | MSI / Function Key |
| Custom Connector | `customconnectors/<name>` | Varies |
| VMware Carbon Black | `Microsoft.Web/customApis/...` | API Key (securestring) |
| Cisco Umbrella | `Microsoft.Web/customApis/...` | Basic (API Key + empty pw) |
| Cisco ISE | `Microsoft.Web/customApis/...` | Basic (authType param) |
| Zscaler Internet Access | HTTP + OAuth2 sub-playbook | Client Credentials |
| MDE API | HTTP + App Reg | Client Credentials |
| Microsoft Graph | HTTP + App Reg | Client Credentials |
| CrowdStrike | HTTP + OAuth2 | Client Credentials |
| TheHive | HTTP | API Key header |
| Tanium | HTTP + Key Vault | API Token |
