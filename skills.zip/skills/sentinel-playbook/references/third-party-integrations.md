# Third-Party Integration Patterns

> Parent skill: [sentinel-playbooks](../SKILL.md)

Full HTTP action patterns for third-party security platforms that do not have managed Logic App connectors. Each section covers authentication, key API calls, and Sentinel-specific usage patterns derived from production playbook templates.

---

## CrowdStrike Falcon

**Auth:** OAuth2 client credentials (client_id + client_secret stored in Key Vault)  
**Base URL:** `https://api.crowdstrike.com`  
**Scopes required:** `Hosts:Read`, `Device control policies:Write`, `Real time response:Write`

### Authentication (get Bearer token)

```json
"HTTP_-_Get_CrowdStrike_Token": {
  "runAfter": { "Get_ClientSecret": ["Succeeded"] },
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.crowdstrike.com/oauth2/token",
    "headers": { "Content-Type": "application/x-www-form-urlencoded" },
    "body": "client_id=@{body('Get_ClientId')?['value']}&client_secret=@{body('Get_ClientSecret')?['value']}"
  }
},
"Parse_JSON_-_Token": {
  "runAfter": { "HTTP_-_Get_CrowdStrike_Token": ["Succeeded"] },
  "type": "ParseJson",
  "inputs": {
    "content": "@body('HTTP_-_Get_CrowdStrike_Token')",
    "schema": {
      "type": "object",
      "properties": {
        "access_token": { "type": "string" },
        "expires_in": { "type": "integer" },
        "token_type": { "type": "string" }
      }
    }
  }
}
```

Reference token: `Bearer @{body('Parse_JSON_-_Token')?['access_token']}`

> **Best practice:** Deploy a shared "CrowdStrike_Base" sub-playbook that handles Key Vault retrieval and token acquisition, and return `{ "AccessToken": "Bearer ...", "FalconHost": "https://api.crowdstrike.com" }`. Call it via `type: "Workflow"` from all CrowdStrike playbooks.

### Search Device by Hostname

```json
"HTTP_-_Get_Device_ID": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.crowdstrike.com/devices/queries/devices/v1?filter=hostname:'@{items('For_each')?['HostName']}'",
    "headers": { "Authorization": "@{variables('AccessToken')}" }
  }
}
```

Check device found: `@not(equals(body('HTTP_-_Get_Device_ID')?['resources']?[0], null))`  
Extract device ID: `@{body('HTTP_-_Get_Device_ID')?['resources']?[0]}`

### Get Device Details

```json
"HTTP_-_Get_Device_Info": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.crowdstrike.com/devices/entities/devices/v2?ids=@{variables('DeviceId')}",
    "headers": { "Authorization": "@{variables('AccessToken')}" }
  }
}
```

Key fields from `body(...)?['resources']?[0]`:
- `hostname` — machine name
- `device_id` — CrowdStrike device GUID
- `external_ip` — external IP address
- `local_ip` — internal IP
- `os_version` — OS version string
- `agent_version` — Falcon agent version
- `status` — `normal` | `contained` | `containment_pending` | `lift_containment_pending`
- `last_seen` — ISO 8601 last activity time

### Contain (Isolate) Device

```json
"HTTP_-_Contain_Device": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.crowdstrike.com/devices/entities/devices/actions/v2?action_name=contain",
    "headers": {
      "Authorization": "@{variables('AccessToken')}",
      "Content-Type": "application/json"
    },
    "body": { "ids": ["@{variables('DeviceId')}"] }
  }
}
```

Success: HTTP 202. Check with: `@equals(outputs('HTTP_-_Contain_Device')['statusCode'], 202)`

### Lift Containment

```json
"HTTP_-_Lift_Containment": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.crowdstrike.com/devices/entities/devices/actions/v2?action_name=lift_containment",
    "headers": {
      "Authorization": "@{variables('AccessToken')}",
      "Content-Type": "application/json"
    },
    "body": { "ids": ["@{variables('DeviceId')}"] }
  }
}
```

### Get Detections for Device

```json
"HTTP_-_Get_Detections": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.crowdstrike.com/detects/queries/detects/v1?filter=device.device_id:'@{variables('DeviceId')}'&limit=20",
    "headers": { "Authorization": "@{variables('AccessToken')}" }
  }
}
```

---

## Okta Identity Cloud

**Auth:** API token in `Authorization` header (stored as securestring parameter, fetched from Key Vault)  
**Base URL:** `https://{your-domain}.okta.com`

> Prefer using the managed `okta` Logic App connector when available. Use HTTP for operations not covered by the connector (e.g., reset factors, clear sessions, MFA enrollment).

### Get User by Login/Email

```json
"HTTP_-_Get_Okta_User": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://[parameters('OktaDomain')]/api/v1/users/@{encodeURIComponent(concat(items('For_each')?['accountName'], '@', items('For_each')?['upnSuffix']))}",
    "headers": {
      "Authorization": "SSWS @{parameters('OktaAPIToken')}",
      "Accept": "application/json"
    }
  }
}
```

Key fields: `body(...)?['id']`, `body(...)?['status']`, `body(...)?['profile']?['login']`, `body(...)?['profile']?['email']`

### Suspend User

```json
"HTTP_-_Suspend_Okta_User": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://[parameters('OktaDomain')]/api/v1/users/@{body('HTTP_-_Get_Okta_User')?['id']}/lifecycle/suspend",
    "headers": { "Authorization": "SSWS @{parameters('OktaAPIToken')}" }
  }
}
```

### Clear User Sessions

```json
"HTTP_-_Clear_Okta_Sessions": {
  "type": "Http",
  "inputs": {
    "method": "DELETE",
    "uri": "https://[parameters('OktaDomain')]/api/v1/users/@{body('HTTP_-_Get_Okta_User')?['id']}/sessions",
    "headers": { "Authorization": "SSWS @{parameters('OktaAPIToken')}" }
  }
}
```

### Get User Groups

```json
"HTTP_-_Get_Okta_User_Groups": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://[parameters('OktaDomain')]/api/v1/users/@{body('HTTP_-_Get_Okta_User')?['id']}/groups",
    "headers": {
      "Authorization": "SSWS @{parameters('OktaAPIToken')}",
      "Accept": "application/json"
    }
  }
}
```

Groups array: `body('HTTP_-_Get_Okta_User_Groups')` → each item has `profile.name`, `type`

### Reset All Factors (Force MFA Re-enrollment)

```json
"HTTP_-_Reset_Okta_Factors": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://[parameters('OktaDomain')]/api/v1/users/@{body('HTTP_-_Get_Okta_User')?['id']}/lifecycle/reset_factors",
    "headers": { "Authorization": "SSWS @{parameters('OktaAPIToken')}" }
  }
}
```

---

## TheHive Project

**Auth:** API key in `Authorization: Bearer` header  
**Base URL:** Customer-hosted (parameter `TheHiveURL`)

### Create Case

```json
"HTTP_-_Create_TheHive_Case": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[concat(parameters('TheHiveURL'), '/api/case')]",
    "headers": {
      "Authorization": "Bearer @{parameters('TheHiveAPIKey')}",
      "Content-Type": "application/json"
    },
    "body": {
      "title": "@{triggerBody()?['object']?['properties']?['title']}",
      "description": "**Sentinel Incident #@{triggerBody()?['object']?['properties']?['incidentNumber']}**\n\n@{triggerBody()?['object']?['properties']?['description']}\n\n[View in Sentinel](@{triggerBody()?['object']?['properties']?['incidentUrl']})",
      "severity": "@{if(equals(triggerBody()?['object']?['properties']?['severity'], 'High'), 3, if(equals(triggerBody()?['object']?['properties']?['severity'], 'Medium'), 2, 1))}",
      "tlp": 2,
      "pap": 2,
      "tags": [
        "sentinel",
        "@{triggerBody()?['object']?['properties']?['severity']}",
        "@{first(triggerBody()?['object']?['properties']?['tactics'])}"
      ],
      "flag": false
    }
  }
}
```

TheHive severity: 1=Low, 2=Medium, 3=High. Extract case ID: `body('HTTP_-_Create_TheHive_Case')?['_id']`

### Add Observable (Artifact)

```json
"HTTP_-_Add_IP_Observable": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[concat(parameters('TheHiveURL'), '/api/case/@{variables(''CaseId'')}/artifact')]",
    "headers": {
      "Authorization": "Bearer @{parameters('TheHiveAPIKey')}",
      "Content-Type": "application/json"
    },
    "body": {
      "dataType": "ip",
      "data": "@{items('For_each')?['Address']}",
      "message": "IP entity from Sentinel incident",
      "tlp": 2,
      "ioc": true,
      "sighted": true,
      "tags": ["sentinel-entity"]
    }
  }
}
```

**dataType values:** `ip`, `domain`, `url`, `hash`, `mail`, `hostname`, `filename`, `other`

### Create Case Task

```json
"HTTP_-_Create_Task": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[concat(parameters('TheHiveURL'), '/api/case/@{variables(''CaseId'')}/task')]",
    "headers": {
      "Authorization": "Bearer @{parameters('TheHiveAPIKey')}",
      "Content-Type": "application/json"
    },
    "body": {
      "title": "Investigate Sentinel Alert",
      "description": "Review entities and determine if incident is a true positive.",
      "status": "Waiting",
      "flag": false
    }
  }
}
```

---

## Tanium

**Auth:** API token in `Authorization: Token` header (stored in Key Vault)  
**Base URL:** `https://{tanium-server}/plugin/products/api/v2`

### Get Package by Name

```json
"HTTP_-_Get_Package": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "[concat('https://', parameters('TaniumServer'), '/plugin/products/api/v2/packages?name=', encodeURIComponent('QuarantineHost'))]",
    "headers": {
      "Authorization": "Token @{body('Get_API_Token')?['value']}",
      "Content-Type": "application/json"
    }
  }
}
```

Extract package ID: `body('HTTP_-_Get_Package')?['data']?[0]?['id']`

### Issue Action (Quarantine Host)

```json
"HTTP_-_Issue_Quarantine_Action": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[concat('https://', parameters('TaniumServer'), '/plugin/products/api/v2/actions')]",
    "headers": {
      "Authorization": "Token @{body('Get_API_Token')?['value']}",
      "Content-Type": "application/json"
    },
    "body": {
      "package": { "id": "@{variables('PackageId')}" },
      "targets": {
        "computerGroups": [],
        "endpoints": [{ "name": "@{items('For_each')?['HostName']}" }]
      },
      "name": "Sentinel-Quarantine-@{items('For_each')?['HostName']}"
    }
  }
}
```

Extract action ID: `body('HTTP_-_Issue_Quarantine_Action')?['data']?['id']`

### Poll Action Status

```json
"HTTP_-_Get_Action_Status": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "[concat('https://', parameters('TaniumServer'), '/plugin/products/api/v2/actions/@{variables(''ActionId'')}')]",
    "headers": { "Authorization": "Token @{body('Get_API_Token')?['value']}" }
  }
}
```

Status field: `body('HTTP_-_Get_Action_Status')?['data']?['status']`  
Terminal states: `"Completed"`, `"Failed"`, `"Expired"`

---

## Microsoft Defender for Endpoint (MDE)

**Auth:** App Registration client credentials (scope: `https://api.securitycenter.microsoft.com/.default`)  
**Base URL:** `https://api.securitycenter.microsoft.com/api`

See [action-patterns.md — OAuth2 Client Credentials](action-patterns.md) for token acquisition.

### Get Machine by Hostname

```json
"HTTP_-_Get_MDE_Machine": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.securitycenter.microsoft.com/api/machines?$filter=computerDnsName eq '@{items('For_each')?['HostName']}'",
    "headers": { "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}" }
  }
}
```

Machine fields from `body(...)?['value']?[0]`: `id`, `computerDnsName`, `osPlatform`, `healthStatus`, `onboardingStatus`, `exposureLevel`

### Isolate Machine

```json
"HTTP_-_Isolate_MDE_Machine": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.securitycenter.microsoft.com/api/machines/@{variables('MachineId')}/isolate",
    "headers": {
      "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}",
      "Content-Type": "application/json"
    },
    "body": {
      "Comment": "Isolated by Sentinel playbook — Incident #@{triggerBody()?['object']?['properties']?['incidentNumber']}",
      "IsolationType": "Full"
    }
  }
}
```

Success: HTTP 201. Extract action ID: `body(...)?['id']`

### Run Antivirus Scan

```json
"HTTP_-_Run_AV_Scan": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.securitycenter.microsoft.com/api/machines/@{variables('MachineId')}/runAntiVirusScan",
    "headers": {
      "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}",
      "Content-Type": "application/json"
    },
    "body": {
      "Comment": "AV scan triggered by Sentinel playbook",
      "ScanType": "Quick"
    }
  }
}
```

`ScanType` values: `"Quick"` | `"Full"`

### Collect Investigation Package

```json
"HTTP_-_Collect_Package": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.securitycenter.microsoft.com/api/machines/@{variables('MachineId')}/collectInvestigationPackage",
    "headers": {
      "Authorization": "Bearer @{body('Parse_JSON_-_Token')?['access_token']}",
      "Content-Type": "application/json"
    },
    "body": { "Comment": "Evidence collection for Sentinel incident" }
  }
}
```

---

## Recorded Future

**Auth:** API token in `X-RFToken` header  
**Base URL:** `https://api.recordedfuture.com/v2`

### IP Lookup

```json
"HTTP_-_RF_IP_Lookup": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.recordedfuture.com/v2/ip/@{encodeURIComponent(items('For_each_IP'))}?fields=risk,intelCard,location",
    "headers": {
      "X-RFToken": "@{parameters('RecordedFutureAPIKey')}",
      "Accept": "application/json"
    }
  }
}
```

Key fields: `body(...)?['data']?['risk']?['score']`, `body(...)?['data']?['risk']?['criticalityLabel']`, `body(...)?['data']?['intelCard']`

Criticality labels: `None` | `Unusual` | `Suspicious` | `Malicious` | `Very Malicious`

### Domain Lookup

```json
"HTTP_-_RF_Domain_Lookup": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.recordedfuture.com/v2/domain/@{encodeURIComponent(items('For_each')?['Url'])}?fields=risk,intelCard",
    "headers": {
      "X-RFToken": "@{parameters('RecordedFutureAPIKey')}",
      "Accept": "application/json"
    }
  }
}
```

### Hash Lookup

```json
"HTTP_-_RF_Hash_Lookup": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.recordedfuture.com/v2/hash/@{encodeURIComponent(items('For_each')?['Value'])}?fields=risk,intelCard,timestamps",
    "headers": {
      "X-RFToken": "@{parameters('RecordedFutureAPIKey')}",
      "Accept": "application/json"
    }
  }
}
```

---

## VirusTotal

**Auth:** API key in `x-apikey` header  
**Base URL:** `https://www.virustotal.com/api/v3`

### IP Report

```json
"HTTP_-_VT_IP_Report": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://www.virustotal.com/api/v3/ip_addresses/@{items('For_each_IP')}",
    "headers": { "x-apikey": "@{parameters('VirusTotalAPIKey')}" }
  }
}
```

Key stats: `body(...)?['data']?['attributes']?['last_analysis_stats']` → `{ "malicious": n, "suspicious": n, "harmless": n, "undetected": n }`

### File Hash Report

```json
"HTTP_-_VT_File_Report": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://www.virustotal.com/api/v3/files/@{items('For_each')?['Value']}",
    "headers": { "x-apikey": "@{parameters('VirusTotalAPIKey')}" }
  }
}
```

### URL Report

```json
"HTTP_-_VT_URL_Report": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://www.virustotal.com/api/v3/urls/@{base64(items('For_each')?['Url'])}",
    "headers": { "x-apikey": "@{parameters('VirusTotalAPIKey')}" }
  }
}
```

---

## ServiceNow — Advanced Patterns

### Get Incident by Sentinel Tag (for bi-directional sync)

When Sentinel tags the incident with `SNOW-<number>`, retrieve the SNOW sys_id on updates:

```json
"Filter_SNOW_Tag": {
  "type": "Query",
  "inputs": {
    "from": "@triggerBody()?['object']?['properties']?['labels']",
    "where": "@startsWith(item()?['labelName'], 'SNOW-')"
  }
},
"Set_variable_-_SNOW_Number": {
  "type": "SetVariable",
  "inputs": {
    "name": "SNOWNumber",
    "value": "@{replace(first(body('Filter_SNOW_Tag'))?['labelName'], 'SNOW-', '')}"
  }
},
"HTTP_-_Get_SNOW_SysId": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['service-now']['connectionId']" } },
    "method": "get",
    "path": "/api/now/v2/table/incident",
    "queries": {
      "sysparm_query": "number=@{variables('SNOWNumber')}",
      "sysparm_fields": "sys_id,number,state,urgency"
    }
  }
}
```

Extract sys_id: `body('HTTP_-_Get_SNOW_SysId')?['result']?[0]?['sys_id']`

### Add Work Note (Internal Note)

```json
"HTTP_-_Add_SNOW_Work_Note": {
  "type": "ApiConnection",
  "inputs": {
    "body": { "work_notes": "@{variables('UpdateNote')}" },
    "host": { "connection": { "name": "@parameters('$connections')['service-now']['connectionId']" } },
    "method": "patch",
    "path": "/api/now/v2/table/incident/@{variables('SNOWSysId')}"
  }
}
```

---

## PagerDuty — Advanced Patterns

### Resolve Event (Close Alert)

```json
"HTTP_-_PD_Resolve": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://events.pagerduty.com/v2/enqueue",
    "headers": { "Content-Type": "application/json" },
    "body": {
      "routing_key": "@{parameters('PagerDutyIntegrationKey')}",
      "event_action": "resolve",
      "dedup_key": "@{triggerBody()?['object']?['properties']?['incidentNumber']}"
    }
  }
}
```

Use the same `dedup_key` (incident number) as when you triggered the alert — PagerDuty uses this to correlate.

### Acknowledge Event

```json
"HTTP_-_PD_Acknowledge": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://events.pagerduty.com/v2/enqueue",
    "headers": { "Content-Type": "application/json" },
    "body": {
      "routing_key": "@{parameters('PagerDutyIntegrationKey')}",
      "event_action": "acknowledge",
      "dedup_key": "@{triggerBody()?['object']?['properties']?['incidentNumber']}"
    }
  }
}
```

---

---

## 10. Zscaler Internet Access (ZIA)

Authentication uses an OAuth2 auth sub-playbook (see playbook-examples.md Category 18). All API calls pass the Bearer token from the sub-playbook response.

**Base URL:** `https://api.zsapi.net/zia/api/v1`

**Token acquisition (in auth sub-playbook):**
```json
"HTTP_Get_OAuth_Token": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "@parameters('oauthUrl')",
    "headers": { "Content-Type": "application/x-www-form-urlencoded" },
    "body": "grant_type=client_credentials&client_id=@{encodeUriComponent(parameters('clientId'))}&client_secret=@{encodeUriComponent(parameters('clientSecret'))}"
  },
  "runtimeConfiguration": { "secureData": { "properties": ["inputs", "outputs"] } }
}
```

**Add IP to block category:**
```json
"HTTP_Add_IP_to_Category": {
  "type": "Http",
  "inputs": {
    "method": "PUT",
    "uri": "https://api.zsapi.net/zia/api/v1/urlCategories/@{variables('Category')}?action=ADD_TO_LIST",
    "headers": {
      "Authorization": "@{concat(body('Parse_Authentication_Response')?['token_type'], ' ', body('Parse_Authentication_Response')?['access_token'])}",
      "Content-Type": "application/json",
      "Cache-Control": "no-cache"
    },
    "body": { "dbCategorizedUrls": ["@{items('For_each')?['Address']}"] }
  }
}
```

**Remove IP from category:**
```json
"HTTP_Remove_IP": {
  "type": "Http",
  "inputs": {
    "method": "PUT",
    "uri": "https://api.zsapi.net/zia/api/v1/urlCategories/@{variables('Category')}?action=REMOVE_FROM_LIST",
    "headers": { "Authorization": "@{concat(body('Parse_Authentication_Response')?['token_type'], ' ', body('Parse_Authentication_Response')?['access_token'])}", "Content-Type": "application/json" },
    "body": { "dbCategorizedUrls": ["@{items('For_each')?['Address']}"] }
  }
}
```

**Activate pending policy changes (required after every add/remove):**
```json
"HTTP_Activate_Changes": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "https://api.zsapi.net/zia/api/v1/status/activate",
    "headers": { "Authorization": "@{concat(body('Parse_Authentication_Response')?['token_type'], ' ', body('Parse_Authentication_Response')?['access_token'])}", "Content-Type": "application/json" },
    "body": { "status": "ACTIVE" }
  }
}
```

**Block URL (same pattern, use URL instead of IP):**
```json
"body": { "dbCategorizedUrls": ["@{items('For_each')?['Url']}"] }
```

**Whitelist URL (add to allowlist category):**
Use `?action=ADD_TO_LIST` with a whitelist category name.

**Lookup IP category:**
```json
"uri": "https://api.zsapi.net/zia/api/v1/urlLookup",
"body": ["@{items('For_each')?['Address']}"]
```

---

## 11. VMware Carbon Black Cloud

Uses a custom connector (`Microsoft.Web/customApis`) with the API key passed as `X-Auth-Token`. The org key is a required URL path parameter for all endpoints.

**Base URL (configurable):** e.g., `https://defense.conferdeploy.net`

**Search devices by hostname:**
```json
"CBC_Search_Devices": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "query": "name:@{items('For_each_Host')?['HostName']}",
      "criteria": { "status": ["ACTIVE"] },
      "rows": "1"
    },
    "host": { "connection": { "name": "@parameters('$connections')['CarbonBlackCloudConnector']['connectionId']" } },
    "method": "post",
    "path": "/appservices/v6/orgs/@{encodeURIComponent(parameters('OrgKey'))}/devices/_search"
  }
}
```

**Quarantine device (enable):**
```json
"CBC_Quarantine_Device": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "action_type": "QUARANTINE",
      "device_id": ["@{body('Parse_JSON_Device')?['results'][0]?['id']}"],
      "options": { "toggle": "ON" }
    },
    "host": { "connection": { "name": "@parameters('$connections')['CarbonBlackCloudConnector']['connectionId']" } },
    "method": "post",
    "path": "/appservices/v6/orgs/@{encodeURIComponent(parameters('OrgKey'))}/device_actions"
  }
}
```

**Lift quarantine:**
Change `"toggle": "OFF"`.

**Dismiss an alert:**
```json
"CBC_Dismiss_Alert": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "state": "DISMISSED",
      "comment": "Dismissed via Microsoft Sentinel playbook",
      "remediation_state": "Remediated via Sentinel"
    },
    "host": { "connection": { "name": "@parameters('$connections')['CarbonBlackCloudConnector']['connectionId']" } },
    "method": "post",
    "path": "/appservices/v6/orgs/@{encodeURIComponent(parameters('OrgKey'))}/alerts/@{encodeURIComponent(variables('AlertId'))}/workflow"
  }
}
```

**Add note to alert:**
```json
"CBC_Add_Note": {
  "type": "ApiConnection",
  "inputs": {
    "body": { "note": "Sentinel Incident #@{triggerBody()?['object']?['properties']?['incidentNumber']}: @{triggerBody()?['object']?['properties']?['title']}" },
    "host": { "connection": { "name": "@parameters('$connections')['CarbonBlackCloudConnector']['connectionId']" } },
    "method": "post",
    "path": "/appservices/v6/orgs/@{encodeURIComponent(parameters('OrgKey'))}/alerts/@{encodeURIComponent(variables('AlertId'))}/notes"
  }
}
```

---

## 12. Cisco Umbrella (Enforcement API)

Uses a custom connector with Basic auth where the username is the API key and password is empty. Domain extraction from URLs is done inline.

**Base URL:** Configured in the custom connector `serviceUrl`.

**URL-to-domain extraction:**
```
@{split(replace(replace(items('For_each')?['Url'],'http://',''),'https://',''),'/')[0]}
```

**Block domain:**
```json
"CiscoUmbrella_BlockDomain": {
  "type": "ApiConnection",
  "inputs": {
    "body": [
      {
        "identifierType": "domain",
        "identifier": "@{split(replace(replace(items('For_each')?['Url'],'http://',''),'https://',''),'/')[0]}"
      }
    ],
    "host": { "connection": { "name": "@parameters('$connections')['CiscoUmbrellaConnector']['connectionId']" } },
    "method": "post",
    "path": "/1.0/events"
  }
}
```

**Block IP address:**
```json
"body": [{ "identifierType": "ip", "identifier": "@{items('For_each')?['Address']}" }]
```

**Custom connector connection `parameterValues`:**
```json
"parameterValues": {
  "authType": "basic",
  "username": "[parameters('APIKey')]",
  "password": ""
}
```

**Post-deployment:** The Umbrella API key is entered as the username in the connector connection during sign-in.

---

## 13. Cisco ISE

Uses a custom connector with Basic auth (`authType: "basic"`). MAC address entities are extracted from `additionalData['Custom Details']`.

**Extract MAC address from entity custom details:**
```json
"items('For_each')?['properties']?['additionalData']?['Custom Details']?['MACAddress'][0]"
```

**Endpoint quarantine (custom connector action):**
```json
"CiscoISE_QuarantineEndpoint": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "OperationAdditionalData": {
        "additionalData": [
          { "name": "macAddress", "value": "@{variables('MACAddress')}" },
          { "name": "policyName", "value": "Quarantine_Policy" }
        ]
      }
    },
    "host": { "connection": { "name": "@parameters('$connections')['CiscoISEConnector']['connectionId']" } },
    "method": "put",
    "path": "/ers/config/ancendpoint/apply"
  }
}
```

**Get endpoint details:**
```json
"path": "/ers/config/endpoint/name/@{encodeURIComponent(variables('MACAddress'))}"
```

**Incident status → Cisco action mapping (Switch pattern):**
```json
"Switch_-_Action": {
  "type": "Switch",
  "expression": "@triggerBody()?['object']?['properties']?['status']",
  "cases": {
    "Case_Quarantine": {
      "case": "Active",
      "actions": { /* quarantine */ }
    },
    "Case_Release": {
      "case": "Closed",
      "actions": { /* clear ANC policy */ }
    }
  },
  "default": { "actions": {} }
}
```

---

## Integration Parameters Quick Reference

| Integration | Required Parameters | Secret Type | Connector Pattern |
|-------------|--------------------|----|---|
| CrowdStrike | `KeyVaultName`, `ClientIdSecret`, `ClientSecretSecret` | `securestring` (Key Vault) | HTTP + OAuth2 |
| Okta | `OktaDomain`, `OktaAPIToken` | `securestring` | Managed (`okta`) |
| TheHive | `TheHiveURL`, `TheHiveAPIKey` | `securestring` | HTTP + API Key header |
| Tanium | `TaniumServer`, `KeyVaultName`, `TaniumAPITokenSecret` | `securestring` (Key Vault) | HTTP + Key Vault token |
| MDE | `ClientId`, `KeyVaultName`, `KeyVaultSecretName` | `securestring` (Key Vault) | HTTP + Client Credentials |
| Recorded Future | `RecordedFutureAPIKey` | `securestring` | HTTP + API Key header |
| VirusTotal | `VirusTotalAPIKey` | `securestring` | HTTP + API Key param |
| PagerDuty | `PagerDutyIntegrationKey` | `securestring` | HTTP + Integration Key |
| ServiceNow | Managed connector OAuth | n/a | Managed (`service-now`) |
| Jira | Managed connector OAuth | n/a | Managed (`jira`) |
| Zscaler ZIA | `OAuthClientId`, `OAuthClientSecret`, `OAuthTokenUrl`, `ZscalerAuthPlaybook` | `securestring` | HTTP + Auth Sub-Playbook |
| VMware Carbon Black | `CustomConnectorName`, `OrgKey`, API Key (post-deploy sign-in) | Custom connector | `Microsoft.Web/customApis` |
| Cisco Umbrella | `CustomConnectorName`, `APIKey` (as username in Basic auth) | Custom connector | `Microsoft.Web/customApis` |
| Cisco ISE | `CustomConnectorName`, Username/Password | Custom connector | `Microsoft.Web/customApis` |
| SIGNL4 | SIGNL4 account (post-deploy OAuth sign-in) | n/a | Managed (`signl4`) |
