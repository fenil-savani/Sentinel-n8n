# Trigger Patterns Reference

> Parent skill: [sentinel-playbooks](../SKILL.md)

All trigger types used in Microsoft Sentinel playbooks, with full body expression references.

---

## Trigger Type Decision Matrix

| Use Case | Trigger Type | `azuresentinel` path |
|----------|-------------|---------------------|
| React to new incident | Incident | `/incident-creation` |
| React to new alert | Alert | `/subscribe` |
| Scheduled job (watchlist, health check) | Recurrence | — (no Sentinel connection needed for trigger) |
| On-demand from REST call or parent Logic App | HTTP / Manual | — |
| Azure Event (resource created/updated) | EventGrid | — |

---

## 1. Incident Trigger

Fires when Microsoft Sentinel creates a new incident (after alert grouping). This is the correct trigger for playbooks that process entities and update incidents.

```json
"triggers": {
  "Microsoft_Sentinel_incident": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": {
        "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" }
      },
      "path": "/incident-creation"
    }
  }
}
```

### Full Incident Trigger Body Reference

```
triggerBody()?['object']?['id']                                     → Incident ARM resource ID (use as incidentArmId)
triggerBody()?['object']?['name']                                   → Incident GUID
triggerBody()?['object']?['properties']?['incidentNumber']          → Numeric incident ID (e.g. 12345)
triggerBody()?['object']?['properties']?['title']                   → Incident title
triggerBody()?['object']?['properties']?['description']             → Incident description (may be null)
triggerBody()?['object']?['properties']?['severity']                → High | Medium | Low | Informational
triggerBody()?['object']?['properties']?['status']                  → New | Active | Closed
triggerBody()?['object']?['properties']?['incidentUrl']             → Azure Portal URL for the incident
triggerBody()?['object']?['properties']?['createdTimeUtc']          → ISO 8601 creation time
triggerBody()?['object']?['properties']?['lastModifiedTimeUtc']     → ISO 8601 last modified time
triggerBody()?['object']?['properties']?['relatedEntities']         → Array of entity objects
triggerBody()?['object']?['properties']?['labels']                  → Array of label objects
triggerBody()?['object']?['properties']?['tactics']                 → Array of MITRE tactic strings
triggerBody()?['object']?['properties']?['firstActivityTimeUtc']    → First activity time
triggerBody()?['object']?['properties']?['lastActivityTimeUtc']     → Last activity time
triggerBody()?['object']?['properties']?['owner']?['assignedTo']    → Assigned analyst name
triggerBody()?['workspaceInfo']?['SubscriptionId']                  → Workspace subscription ID
triggerBody()?['workspaceInfo']?['ResourceGroupName']               → Workspace resource group
triggerBody()?['workspaceInfo']?['WorkspaceId']                     → Log Analytics workspace GUID
```

### Entity Object Structure (from `relatedEntities`)

```
item()?['kind']                                 → Account | Host | Ip | Url | File | FileHash | etc.
item()?['id']                                   → Entity ARM resource ID
item()?['properties']?['friendlyName']          → Display name (all entity types)
item()?['properties']?['address']              → IP address (Ip entities)
item()?['properties']?['url']                  → URL value (Url entities)
item()?['properties']?['hashValue']            → Hash value (FileHash entities)
item()?['properties']?['algorithm']            → MD5 | SHA1 | SHA256 (FileHash entities)
```

### Account Entity Fields (after `/entities/account` extraction)

```
items('For_each')?['accountName']              → Username without domain
items('For_each')?['ntDomain']                 → NetBIOS domain name
items('For_each')?['upnSuffix']               → UPN domain suffix (@contoso.com)
items('For_each')?['AadUserId']               → Azure AD object ID (may be null)
items('For_each')?['AadTenantId']             → Azure AD tenant ID
items('For_each')?['displayName']             → Full display name
items('For_each')?['sid']                      → Windows SID
```

Resolve full UPN: `@{concat(items('For_each')?['accountName'], '@', items('For_each')?['upnSuffix'])}`

### Host Entity Fields (after `/entities/host` extraction)

```
items('For_each')?['HostName']                            → Hostname (without domain)
items('For_each')?['FQDN']                               → Fully qualified domain name
items('For_each')?['DnsDomain']                          → DNS domain
items('For_each')?['OSFamily']                           → Windows | Linux | macOS | Android | iOS
items('For_each')?['additionalData']?['MdatpDeviceId']   → MDE Device ID (if onboarded)
items('For_each')?['additionalData']?['AzureID']         → Azure VM resource ID
```

### Alert Custom Details (Analytics Rule key-value pairs)

Custom Details are key-value pairs defined in a Sentinel Analytics Rule's **Custom Details** mapping. They are surfaced **per alert**, not per incident. Because an incident can contain multiple alerts, custom details are accessed by iterating the incident's `alerts` array.

**Rule: never read custom details directly off the incident object.** The incident-level `additionalData` only holds entity fields like `MdatpDeviceId`. Custom detail keys are not promoted to the incident level.

**Correct pattern — three steps:**

1. **Loop over alerts** — `foreach: @triggerBody()?['object']?['properties']?['alerts']`
2. **ParseJson the custom details string** inside the loop — content is `items('<loop_name>')?['properties']?['additionalData']?['Custom Details']`. This field is a JSON-encoded string, so `ParseJson` is required before any field access.
3. **Access your key** from the parsed body — `body('<parse_action_name>')?['<your_key>']` returns an array of string values. Use `[0]` for the first value, or loop again for multiple.

**Schema to use in ParseJson** (adjust keys to match your analytics rule):
```json
{
  "type": "object",
  "properties": {
    "<your_custom_key>": {
      "type": "array",
      "items": { "type": "string" }
    }
  }
}
```

**Wrong paths (produce null or crash ParseJson — do NOT use):**
```
triggerBody()?['object']?['properties']?['additionalData']?['Custom Details']   ← does not exist at incident level
triggerBody()?['object']?['properties']?['additionalData']?['<key>']            ← additionalData is entity-level only
```

See `references/action-patterns.md` §Alert Custom Details for the full working action block.

---

### Tactics and Labels

```
triggerBody()?['object']?['properties']?['tactics']     → Array of MITRE ATT&CK tactic strings
                                                           e.g. ["InitialAccess","Persistence"]
triggerBody()?['object']?['properties']?['labels']      → Array of label objects: [{"labelName":"..."}]
```

Access first tactic: `@{first(triggerBody()?['object']?['properties']?['tactics'])}`

Join tactics for ticket description: `@{join(triggerBody()?['object']?['properties']?['tactics'], ', ')}`

---

## 2. Alert Trigger

Fires on each Sentinel alert before incident grouping. Use when you need the raw alert payload or `SystemAlertId`.

```json
"triggers": {
  "Microsoft_Sentinel_alert": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": {
        "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" }
      },
      "path": "/subscribe"
    }
  }
}
```

### Alert Trigger Body Reference

```
triggerBody()?['SystemAlertId']           → Alert GUID (use in KQL: AlertIds contains "...")
triggerBody()?['AlertDisplayName']        → Alert rule display name
triggerBody()?['AlertSeverity']           → High | Medium | Low | Informational
triggerBody()?['Description']             → Alert description
triggerBody()?['StartTimeUtc']            → Alert start time (ISO 8601)
triggerBody()?['EndTimeUtc']              → Alert end time (ISO 8601)
triggerBody()?['ProviderName']            → Alert provider (e.g. ASI Scheduled Alerts)
triggerBody()?['VendorName']              → Vendor (e.g. Microsoft)
triggerBody()?['Entities']               → JSON string of alert entities (parse before use)
triggerBody()?['ExtendedProperties']     → JSON object of alert-specific properties
```

**Get incident containing this alert (via KQL):**
```json
"body": "SecurityIncident | where AlertIds contains \"@{triggerBody()?['SystemAlertId']}\" | project IncidentNumber, Title, Severity, IncidentUrl, CreatedTime"
```

---

## 2b. Incident Update Trigger

Fires when an **existing** Sentinel incident is updated (status change, severity change, comment added). Requires a separate automation rule targeting "When incident is updated".

```json
"triggers": {
  "Microsoft_Sentinel_incident": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": {
        "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" }
      },
      "path": "/incident-creation"
    }
  }
}
```

The trigger structure is identical to the creation trigger — the difference is in the automation rule configuration. At runtime, the trigger body includes an additional `incidentUpdates` field:

```
triggerBody()?['incidentUpdates']?['updatedFields']   → Array of field names that changed
triggerBody()?['incidentUpdates']?['comments']        → New comments (if Comments changed)
```

**Detect specific field changes:**
```json
"Condition_-_Status_Changed": {
  "type": "If",
  "expression": {
    "and": [{ "contains": ["@string(triggerBody()?['incidentUpdates']?['updatedFields'])", "Status"] }]
  },
  "actions": { /* sync status to external ticket */ },
  "else": { "actions": {} }
}
```

```json
"Condition_-_Severity_Changed": {
  "type": "If",
  "expression": {
    "and": [{ "contains": ["@string(triggerBody()?['incidentUpdates']?['updatedFields'])", "Severity"] }]
  },
  "actions": { /* sync severity */ },
  "else": { "actions": {} }
}
```

**updatedFields values to check:** `"Status"`, `"Severity"`, `"Owner"`, `"Labels"`, `"Comments"`

---

## 2c. Entity Trigger

Fires when a Sentinel automation rule targets an entity directly (e.g., account, IP). The trigger body provides the entity's ARM ID, kind, and properties — but **no incident context**. Use this when your playbook acts on a single entity independently of incident state (e.g., force-reset a compromised account).

```json
"triggers": {
  "Microsoft_Sentinel_entity": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": {
        "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" }
      },
      "path": "/entity/@{encodeURIComponent(triggerBody()?['Entity']?['kind'])}"
    }
  }
}
```

### Entity Trigger Body Reference

```
triggerBody()?['Entity']?['kind']                          → Account | IP | Host | URL | FileHash | File
triggerBody()?['Entity']?['id']                            → Entity ARM resource ID
triggerBody()?['Entity']?['properties']?['friendlyName']   → Display name
triggerBody()?['Entity']?['properties']?['address']        → IP address (IP entities)
triggerBody()?['Entity']?['properties']?['accountName']    → Username (Account entities)
triggerBody()?['Entity']?['properties']?['upnSuffix']      → UPN suffix (Account entities)
triggerBody()?['Entity']?['properties']?['AadUserId']      → Azure AD object ID (Account entities)
triggerBody()?['Entity']?['properties']?['HostName']       → Hostname (Host entities)
triggerBody()?['workspaceInfo']?['WorkspaceId']            → Workspace GUID (same as incident trigger)
```

**Important differences vs Incident trigger:**
- No `triggerBody()?['object']` — entity data is at `triggerBody()?['Entity']`
- No `incidentArmId` in trigger body — cannot add incident comments directly
- Automation rule must be configured for "When entity is created/updated" to target this trigger
- Most entity enrichment playbooks use the **incident** trigger and loop over entities — use entity trigger only when a single-entity automation rule is explicitly required

---

## 3. Recurrence Trigger (Scheduled)

No Sentinel connection required in the trigger. Used for periodic automation: watchlist refresh, health checks, bulk operations.

```json
"triggers": {
  "Recurrence": {
    "type": "Recurrence",
    "recurrence": {
      "frequency": "Hour",
      "interval": 6,
      "timeZone": "UTC",
      "startTime": "2024-01-01T00:00:00Z"
    }
  }
}
```

**Frequency values:** `Second`, `Minute`, `Hour`, `Day`, `Week`, `Month`

**Common schedules:**

| Schedule | frequency | interval |
|----------|-----------|----------|
| Every 15 minutes | `Minute` | `15` |
| Every hour | `Hour` | `1` |
| Every 6 hours | `Hour` | `6` |
| Daily at midnight | `Day` | `1` |
| Weekly | `Week` | `1` |

**With specific days/times (weekly):**
```json
"recurrence": {
  "frequency": "Week",
  "interval": 1,
  "schedule": {
    "weekDays": ["Monday", "Wednesday", "Friday"],
    "hours": [9],
    "minutes": [0]
  },
  "timeZone": "Eastern Standard Time"
}
```

**Access execution time:** `@{utcNow()}` → ISO 8601 string of current run time

---

## 4. HTTP / Manual Trigger

Allows the playbook to be triggered by an HTTP POST to its webhook URL, or called from another Logic App or Azure Function.

```json
"triggers": {
  "manual": {
    "type": "Request",
    "kind": "Http",
    "inputs": {
      "schema": {
        "type": "object",
        "properties": {
          "incidentNumber": { "type": "integer" },
          "userPrincipalName": { "type": "string" },
          "action": { "type": "string", "enum": ["disable", "enable", "revoke"] }
        },
        "required": ["action"]
      }
    }
  }
}
```

**Access request body:** `@triggerBody()?['incidentNumber']`, `@triggerBody()?['userPrincipalName']`

**Return response (optional):**
```json
"Response": {
  "type": "Response",
  "inputs": {
    "statusCode": 200,
    "body": { "result": "@{variables('ResultSummary')}", "status": "completed" }
  }
}
```

---

## 5. Trigger Selection — Common Pitfalls

**Incident vs Alert trigger:**
- Use **Incident trigger** when you need `incidentArmId` to add comments or update the incident
- Use **Alert trigger** when you need `SystemAlertId` to query raw alert data in Log Analytics
- You cannot add a comment directly to an alert — you must resolve the incident via KQL first

**Recurrence trigger with Sentinel actions:**
- Recurrence does not provide workspace info — hardcode `WorkspaceName`, `WorkspaceResourceGroup`, and `WorkspaceSubscriptionId` as template parameters
- The azuresentinel connection is still needed for watchlist and incident operations, but the trigger itself uses only the Recurrence type

**HTTP trigger security:**
- The Logic App webhook URL is a secret — treat it as one
- Add IP restrictions or Azure AD authentication via API Management if exposing externally
- Validate required fields from the request body with conditions before processing

---

## Extended Entity Field Reference

### File Entity Fields (after `/entities/file` extraction)

```
items('For_each')?['Name']                     → Filename
items('For_each')?['Directory']               → File path/directory
items('For_each')?['FileHashes']              → Array of associated hashes
```

### FileHash Entity Fields (after `/entities/filehash` extraction)

```
items('For_each')?['Value']                   → Hash value string
items('For_each')?['Algorithm']              → MD5 | SHA1 | SHA256 | SHA512
items('For_each')?['FileEntityId']           → Related file entity ID (if linked)
```

### URL Entity Fields (after `/entities/url` extraction)

```
items('For_each')?['Url']                     → Full URL string
```

### IP Entity Fields (after `/entities/ip` extraction)

```
items('For_each')?['Address']                 → IP address string (v4 or v6)
items('For_each')?['Location']?['CountryCode']  → ISO country code (if geo-enriched)
items('For_each')?['Location']?['City']        → City name
```

### Process Entity Fields

```
items('For_each')?['ProcessId']              → Process ID
items('For_each')?['CommandLine']            → Full command line
items('For_each')?['ElevationToken']         → Default | Full | Limited
items('For_each')?['CreationTimeUtc']        → Process creation time
```

### Mail Message Entity Fields

```
items('For_each')?['Subject']                → Email subject
items('For_each')?['Sender']                 → Sender email address
items('For_each')?['Recipient']              → Recipient email address
items('For_each')?['InternetMessageId']      → Message-ID header value
```

---

## Trigger Body Expression Cheat Sheet

```
# Incident details
@triggerBody()?['object']?['id']                    incidentArmId for comments/updates
@triggerBody()?['object']?['properties']?['title']  Incident title
@triggerBody()?['object']?['properties']?['severity'] High/Medium/Low/Informational
@triggerBody()?['object']?['properties']?['incidentNumber']  Integer ID
@triggerBody()?['object']?['properties']?['incidentUrl']     Portal URL
@triggerBody()?['object']?['properties']?['description']     Description (may be null)
@triggerBody()?['object']?['properties']?['createdTimeUtc']  ISO 8601 creation time

# Workspace info (incident trigger only)
@triggerBody()?['workspaceInfo']?['SubscriptionId']
@triggerBody()?['workspaceInfo']?['ResourceGroupName']
@triggerBody()?['workspaceInfo']?['WorkspaceId']

# Alert trigger
@triggerBody()?['SystemAlertId']
@triggerBody()?['AlertSeverity']
@triggerBody()?['AlertDisplayName']

# Useful expressions
@{utcNow()}                    Current UTC time
@{guid()}                      Random GUID
@{formatDateTime(utcNow(), 'yyyy-MM-dd')}   Today's date
@{length(triggerBody()?['object']?['properties']?['relatedEntities'])}  Entity count
```
