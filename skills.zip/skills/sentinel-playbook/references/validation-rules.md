# Validation Rules and Authoritative Catalogs

> Parent skill: [sentinel-playbooks](../SKILL.md)

The authoritative lists of identifiers, paths, fields, schemas, and structures used in Sentinel playbooks. Every value here is **canonical** — copy these verbatim. If the value you need is not in this file, **do not invent it** — stop and ask the user for clarification or for the API spec.

This file is the single source of truth for anti-hallucination. Read it first whenever you are about to write any identifier, path, or property name into an ARM template.

---

## 1. apiVersion — Authoritative

| Resource type | Required apiVersion |
|----|----|
| `Microsoft.Logic/workflows` | `"2017-07-01"` |
| `Microsoft.Web/connections` | `"2016-06-01"` |
| `Microsoft.Web/customApis` | `"2016-06-01"` |
| `Microsoft.KeyVault/vaults` | `"2019-09-01"` |
| `Microsoft.KeyVault/vaults/secrets` | `"2019-09-01"` |
| `Microsoft.KeyVault/vaults/accessPolicies` | `"2019-09-01"` |

**Schemas (use verbatim):**
- ARM deployment template: `"https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"`
- Workflow definition: `"https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#"`
- Adaptive Card: `"http://adaptivecards.io/schemas/adaptive-card.json"` (with `version: "1.4"`)

---

## 2. Sentinel API Paths (`azuresentinel` connection)

| Action | Method | Path | Body / response |
|----|----|----|----|
| Incident trigger (webhook) | — | `/incident-creation` | `triggerBody()?['object']?[…]` |
| Alert trigger (webhook) | — | `/subscribe` | `triggerBody()?['SystemAlertId']` |
| Entity trigger (webhook) | — | `/entity/{kind}` | `triggerBody()?['Entity']?[…]`; `{kind}` = `Account`/`Ip`/`Host`/`Url`/`FileHash` |
| Extract Account entities | POST | `/entities/account` | body: `relatedEntities`; response: `?['Accounts']` |
| Extract Host entities | POST | `/entities/host` | response: `?['Hosts']` |
| Extract IP entities | POST | `/entities/ip` | response: `?['IPs']` |
| Extract URL entities | POST | `/entities/url` | response: `?['URLs']` |
| Extract FileHash entities | POST | `/entities/filehash` | response: `?['FileHashes']` |
| Extract File entities | POST | `/entities/file` | response: `?['Files']` |
| Add incident comment | POST | `/Incidents/Comment` | body requires `incidentArmId`, `message` (HTML allowed) |
| Update incident | PUT | `/Incidents` | body requires `incidentArmId` + fields to update |
| Get alerts in incident | GET | `/Incidents/Alerts` | queries: `incidentNumber`, workspace fields |

**Do not invent any other Sentinel paths.** If the user needs an action not in this table, say so explicitly.

---

## 3. Entity Property Names — Authoritative

Use these exact spellings (case-sensitive). Wrong names produce silent nulls at runtime.

### Account entity (after `/entities/account`)

| Property | Description |
|----|----|
| `accountName` | Username without domain (note: lowercase `a`) |
| `ntDomain` | NetBIOS domain |
| `upnSuffix` | UPN domain (e.g. `contoso.com`) |
| `AadUserId` | Azure AD object ID (may be null) |
| `AadTenantId` | Tenant ID |
| `displayName` | Full display name |
| `sid` | Windows SID |

Build full UPN: `@{concat(items('For_each')?['accountName'], '@', items('For_each')?['upnSuffix'])}`

### Host entity (after `/entities/host`)

| Property | Description |
|----|----|
| `HostName` | Hostname (note: PascalCase) |
| `FQDN` | Fully qualified domain name |
| `DnsDomain` | DNS domain |
| `OSFamily` | `Windows` / `Linux` / `macOS` / `Android` / `iOS` |
| `additionalData.MdatpDeviceId` | MDE Device ID (when onboarded) |
| `additionalData.AzureID` | Azure VM resource ID |

### IP entity (after `/entities/ip`)

| Property | Description |
|----|----|
| `Address` | IP string v4 or v6 (PascalCase) |
| `Location.CountryCode` | ISO country code (if geo-enriched) |
| `Location.City` | City name |

### URL entity (after `/entities/url`)

| Property | Description |
|----|----|
| `Url` | Full URL string (note: PascalCase, single capital) |

### FileHash entity (after `/entities/filehash`)

| Property | Description |
|----|----|
| `Value` | Hash value string |
| `Algorithm` | `MD5` / `SHA1` / `SHA256` / `SHA512` |
| `FileEntityId` | Related file entity ID (if linked) |

### File entity (after `/entities/file`)

| Property | Description |
|----|----|
| `Name` | Filename |
| `Directory` | File path / directory |
| `FileHashes` | Array of associated hashes |

### Process entity

| Property | Description |
|----|----|
| `ProcessId` | Process ID |
| `CommandLine` | Full command line |
| `ElevationToken` | `Default` / `Full` / `Limited` |
| `CreationTimeUtc` | Process creation time |

### MailMessage entity

| Property | Description |
|----|----|
| `Subject` | Email subject |
| `Sender` | Sender address |
| `Recipient` | Recipient address |
| `InternetMessageId` | Message-ID header value |

### Common bugs (do NOT use these)

| Wrong | Correct |
|----|----|
| `username` | `accountName` |
| `IPAddress`, `ip`, `ipAddress` | `Address` |
| `Hostname`, `hostname` | `HostName` |
| `URL`, `url` | `Url` |
| `hash`, `HashValue` | `Value` |
| `OS`, `os` | `OSFamily` |
| `triggerBody()?['object']?['properties']?['additionalData']?['Custom Details']` (reading analytics rule custom details from the incident object) | Loop over `triggerBody()?['object']?['properties']?['alerts']`, then `ParseJson` `items(...)?['properties']?['additionalData']?['Custom Details']` per alert |

---

## 4. Connection ID Format — Authoritative

### Managed API connection — value at `$connections.value.<key>.id`
```
/subscriptions/<subId>/providers/Microsoft.Web/locations/<region>/managedApis/<managedApiId>
```
ARM expression:
```
[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/<id>')]
```

### Custom connector connection — value at `$connections.value.<key>.id`
```
/subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.Web/customApis/<customApiName>
```
ARM expression:
```
[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Web/customApis/', parameters('CustomConnectorName'))]
```

### Logic App workflow (target of nested `Workflow` call)
```
/subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.Logic/workflows/<playbookName>
```
ARM expression:
```
[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Logic/workflows/', parameters('<HelperPlaybookName>'))]
```

### Connection resource (value at `$connections.value.<key>.connectionId`)
```
/subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.Web/connections/<connectionName>
```
ARM expression: `[resourceId('Microsoft.Web/connections', variables('<ConnectionVariable>'))]`

**Critical:** `connectionName` value in `$connections.value` MUST exactly equal `variables('<ConnectionVariable>')`. Mismatch produces `BadRequest: $connections value is invalid` at deploy.

---

## 5. ManagedApi IDs — Authoritative Closed List

Use ONLY these IDs in `managedApis/<id>` paths.

| Service | ID |
|----|----|
| Microsoft Sentinel | `azuresentinel` |
| Azure Active Directory | `azuread` |
| Key Vault | `keyvault` |
| Office 365 (Mail/Outlook) | `office365` |
| Office 365 Users | `office365users` |
| Microsoft Teams | `teams` |
| Log Analytics (query) | `azuremonitorlogs` |
| Log Analytics (ingest) | `azureloganalyticsdatacollector` |
| ServiceNow | `service-now` |
| Zendesk | `zendesk` |
| Jira | `jira` |
| Okta | `okta` |
| Slack | `slack` |
| GitHub | `github` |
| SIGNL4 | `signl4` |
| Azure Functions | `azurefunctions` |
| Azure Blob Storage | `azureblob` |
| Event Hubs | `eventhubs` |
| Azure Automation | `azureautomation` |
| Outlook | `outlook` |

If a service is not listed here, it is either an HTTP-action integration (see `references/third-party-integrations.md`) or a custom connector (see `references/connections-catalog.md` §11–13). **Never invent a new managedApi ID.**

---

## 6. Trigger-Body Expressions — Authoritative

### Incident trigger (`Microsoft_Sentinel_incident`)

```
@triggerBody()?['object']?['id']                                       → incidentArmId
@triggerBody()?['object']?['name']                                     → incident GUID
@triggerBody()?['object']?['properties']?['incidentNumber']            → integer
@triggerBody()?['object']?['properties']?['title']
@triggerBody()?['object']?['properties']?['description']
@triggerBody()?['object']?['properties']?['severity']                  → High|Medium|Low|Informational
@triggerBody()?['object']?['properties']?['status']                    → New|Active|Closed
@triggerBody()?['object']?['properties']?['incidentUrl']
@triggerBody()?['object']?['properties']?['createdTimeUtc']
@triggerBody()?['object']?['properties']?['lastModifiedTimeUtc']
@triggerBody()?['object']?['properties']?['firstActivityTimeUtc']
@triggerBody()?['object']?['properties']?['lastActivityTimeUtc']
@triggerBody()?['object']?['properties']?['relatedEntities']           → array
@triggerBody()?['object']?['properties']?['alerts']                    → array of alert objects (each has Custom Details)
@triggerBody()?['object']?['properties']?['tactics']                   → array of MITRE strings
@triggerBody()?['object']?['properties']?['labels']                    → array of {labelName}
@triggerBody()?['object']?['properties']?['owner']?['assignedTo']
@triggerBody()?['workspaceInfo']?['SubscriptionId']
@triggerBody()?['workspaceInfo']?['ResourceGroupName']
@triggerBody()?['workspaceInfo']?['WorkspaceId']
@triggerBody()?['workspaceInfo']?['WorkspaceName']

# Update-trigger only
@triggerBody()?['incidentUpdates']?['updatedFields']                   → array of field names
@triggerBody()?['incidentUpdates']?['comments']
```

### Alert trigger (`Microsoft_Sentinel_alert`)

```
@triggerBody()?['SystemAlertId']
@triggerBody()?['AlertDisplayName']
@triggerBody()?['AlertSeverity']
@triggerBody()?['Description']
@triggerBody()?['StartTimeUtc']
@triggerBody()?['EndTimeUtc']
@triggerBody()?['ProviderName']
@triggerBody()?['VendorName']
@triggerBody()?['Entities']                                            → JSON string; ParseJson before use
@triggerBody()?['ExtendedProperties']                                  → object
```

### Entity trigger (`Microsoft_Sentinel_entity`)

```
@triggerBody()?['Entity']?['kind']                                     → Account|Ip|Host|Url|FileHash
@triggerBody()?['Entity']?['id']
@triggerBody()?['Entity']?['properties']?['friendlyName']
@triggerBody()?['Entity']?['properties']?['address']                   → IP entities
@triggerBody()?['Entity']?['properties']?['accountName']               → Account entities
@triggerBody()?['Entity']?['properties']?['HostName']                  → Host entities
@triggerBody()?['workspaceInfo']?['WorkspaceId']
```

---

## 7. Severity / Status / Classification — Authoritative Enumerations

**Severity** (case-sensitive, exact spelling):
- `High`, `Medium`, `Low`, `Informational`

**Status**:
- `New`, `Active`, `Closed`

**ClassificationAndReason** (when closing an incident):
- `BenignPositive - SuspiciousButExpected`
- `FalsePositive - InaccurateData`
- `FalsePositive - IncorrectAlertLogic`
- `TruePositive - SuspiciousActivity`
- `Undetermined`

**Severity mapping (cross-system):**

| Sentinel | ServiceNow urgency/impact | Jira priority | PagerDuty severity |
|----|----|----|----|
| High | 1 | Highest | critical |
| Medium | 2 | High | error |
| Low | 3 | Medium | warning |
| Informational | 4 | Low | info |

---

## 8. runAfter Statuses — Authoritative

Valid values inside a `runAfter` status array:
- `Succeeded` (most common)
- `Failed`
- `Skipped`
- `TimedOut`

Patterns:
- Default: `["Succeeded"]`
- Cleanup that runs on either outcome: `["Succeeded", "Failed"]`
- After a `Scope` action (where you handle errors via `result()`): `["Succeeded", "Failed", "TimedOut"]`

---

## 9. Required `metadata` Fields — Authoritative

Every emitted ARM template's `metadata` block MUST contain:

```json
{
  "title": "<short, imperative-form title>",
  "description": "<one-paragraph explanation: what it does, when it runs, what it touches>",
  "prerequisites": ["<deployable prerequisites — Key Vault, app reg, watchlist, etc.>"],
  "lastUpdateTime": "<ISO 8601 timestamp>",
  "entities": ["Account", "Host", "Ip", "Url", "FileHash", "File", "Process", "Mailbox", "MailMessage", "CloudApplication", "DnsResolution", "RegistryKey", "RegistryValue", "SecurityGroup"],
  "tags": ["Remediation"|"Enrichment"|"Notification"|"Triage"|"Sync"],
  "support": { "tier": "community" },
  "author": { "name": "<author>" },
  "postDeployment": [
    "Assign the Logic App MSI 'Microsoft Sentinel Responder' on the workspace",
    "<connector sign-ins, Key Vault access, app reg permissions, automation rule>"
  ],
  "releaseNotes": [
    { "version": "1.0.0", "title": "<title>", "notes": ["Initial version"] }
  ]
}
```

Entity kinds in `entities` are case-sensitive. Use only the values from the list above.

---

## 10. ARM Parameter Type Rules — Authoritative

| Purpose | Type |
|----|----|
| Playbook / Logic App name | `string` |
| Workspace name, resource group, region | `string` |
| API key, client secret, token, password, integration key | `securestring` |
| Numeric configuration (timeout, retry count) | `int` |
| Boolean flag | `bool` |
| List of allowed values | `string` with `allowedValues: [...]` |
| Object payload | `object` |

`securestring` parameter values are not echoed in deployment logs and not accessible via `reference()`. Use them for every secret.

**Required parameter shape:**
```json
"ApiKey": {
  "type": "securestring",
  "metadata": { "description": "<clear, deployment-time guidance>" }
}
```

Never use a plain `string` for a credential. Never include a default value for a `securestring`.

---

## 11. Common Deployment-Breaking Errors — Authoritative

| Error / Symptom | Root cause | Fix |
|----|----|----|
| `ParseJson` fails: "Required property 'content' expects a value but got null" | Reading alert Custom Details from incident-level `additionalData` — that path does not exist; `additionalData` at the incident level holds entity fields only | Loop over `triggerBody()?['object']?['properties']?['alerts']`, then `ParseJson` each alert's `items(...)?['properties']?['additionalData']?['Custom Details']` — see `action-patterns.md` §Alert Custom Details Extraction |
| `BadRequest: $connections value is invalid` | `connectionName` in `$connections.value` doesn't match the connection resource name | Set `connectionName` to `variables('<ConnectionVariable>')` everywhere |
| `BadRequest: ManagedServiceIdentity is not configured for the workflow` | Workflow missing `identity` block while using MSI connection | Add `"identity": { "type": "SystemAssigned" }` on the workflow resource |
| `Action 'X' references unrecognized action 'Y'` | `runAfter` key has typo (case mismatch) | Match action name exactly, including underscores |
| `Variable 'X' is not initialized` | `InitializeVariable` placed inside a loop, or referenced before init | Initialize all variables at top level of `actions{}`, before any loop |
| `InvalidVariableInitialization` at deploy | `InitializeVariable` nested inside a `Condition` (If) action — Logic Apps forbids this at the engine level | Move ALL `InitializeVariable` actions to the top-level `actions` block; make the `Condition` run after them via `runAfter` |
| Playbook ends as Succeeded despite an API failure | No `Terminate` action on the error path — Logic Apps marks a run Succeeded unless explicitly terminated as Failed | On every failure path where continuing is meaningless, add a `Terminate` action with `runStatus: "Failed"`. Optionally precede it with any cleanup/notification action appropriate for the playbook context. Wire the `Terminate`'s `runAfter` only to statuses that confirm its preceding action actually ran. See `action-patterns.md` §Failure Path — Terminate as Failed |
| Terminate fires on success path | `Terminate` `runAfter` includes `"Skipped"` — any action that only runs on the failure path is skipped on the success path; listing `"Skipped"` causes the Terminate to trigger even when nothing failed | Audit every `Terminate`'s `runAfter`: include only the statuses under which its immediately preceding action genuinely executed. `"Skipped"` must never appear in a Terminate's `runAfter` when that preceding action can be bypassed on the success path. See `action-patterns.md` §Failure Path — Terminate as Failed |
| Credentials exposed at deploy time | Third-party API key / client secret passed as an ARM `securestring` parameter | Add a `keyvault` connection; store each credential as a Key Vault secret; fetch at runtime with `Get_Secret` actions. Never accept third-party credentials as ARM parameters of any type |
| Auth pattern wrong for third-party API | Auth pattern assumed without reading the supplied spec | Always read the user-provided API spec or Postman collection before choosing an auth pattern — never infer from training data |
| Runtime: `Cannot read property '...' of null` | Direct nested access into an HTTP-string response | Insert `ParseJson` before `@body(...)?['field']` access |
| Connection 'Unauthenticated' post-deploy | OAuth managed connector requires manual sign-in | Add post-deployment step: "Authorize the X connection in the Azure Portal" |
| `Forbidden` from Sentinel API at runtime | MSI lacks RBAC | Post-deployment: assign `Microsoft Sentinel Responder` |
| `Forbidden` from Key Vault | MSI lacks `Get` on secrets | Add `accessPolicies` resource (or RBAC `Key Vault Secrets User`) |
| `Schema validation failed` at deploy | Wrong `apiVersion` or schema URL | Use exact values from §1 |
| Foreach iterations run in parallel when serial was needed | Default Foreach concurrency is parallel (50) | Add `runtimeConfiguration.concurrency.repetitions: 1` |
| Until loop runs forever | No `limit` set | Always set both `count` and `timeout` |
| Sub-playbook returns nothing | Helper Logic App has no `Response` action | Add a `Response` action returning the desired body |
| Credentials visible in run history | Workflow call without `secureData` | Add `runtimeConfiguration.secureData.properties: ["inputs","outputs"]` |
| Comment HTML renders as plain text in incident | Wrong content type (using Markdown) | Comment messages accept HTML; wrap in `<p>...</p>` |
| `kind: V1` missing on `azuresentinel` connection | Alternative auth requires V1 connection kind | Add `"kind": "V1"` to the connection resource |
| Custom connector connection won't authenticate | Connection resource missing `parameterValues` for the custom auth fields | Add `parameterValues` matching the customApi's `connectionParameters` schema |

---

## 12. Action Type Cheat Sheet — Authoritative `type` Values

| Action | `type` |
|----|----|
| Managed API call (Sentinel, Teams, etc.) | `ApiConnection` |
| Wait-for-webhook (adaptive card, callback) | `ApiConnectionWebhook` |
| Raw HTTP call | `Http` |
| HTTP request/manual trigger | `Request` |
| Synchronous HTTP response | `Response` |
| Variable declaration | `InitializeVariable` |
| Overwrite variable | `SetVariable` |
| Append to string | `AppendToStringVariable` |
| Append to array | `AppendToArrayVariable` |
| Increment int variable | `IncrementVariable` |
| Decrement int variable | `DecrementVariable` |
| If/else condition | `If` |
| Switch/case | `Switch` |
| Loop over array | `Foreach` |
| Loop until condition | `Until` |
| Pause | `Wait` |
| Group of actions | `Scope` |
| Parse JSON body | `ParseJson` |
| Build object | `Compose` |
| Transform array | `Select` |
| Generate CSV/HTML table | `Table` |
| Query/filter array | `Query` |
| Recurrence schedule | `Recurrence` (trigger only) |
| Call another Logic App | `Workflow` |
| Terminate workflow | `Terminate` |

`type` values are case-sensitive. Wrong casing fails schema validation at deploy.

---

## 13. Recurrence Trigger Frequency Values — Authoritative

| Frequency | Valid value |
|----|----|
| Sub-minute (rare) | `Second` |
| Per-minute | `Minute` |
| Hourly | `Hour` |
| Daily | `Day` |
| Weekly | `Week` |
| Monthly | `Month` |

`timeZone` values must match Windows zone names (e.g., `UTC`, `Eastern Standard Time`, `Pacific Standard Time`, `India Standard Time`). Use Windows names, not IANA (`UTC`, not `Etc/UTC`).

---

## 14. Adaptive Card Response Access — Authoritative

After a Teams `gatherinput` `ApiConnectionWebhook` action:

```
@body('Post_Adaptive_Card_and_Wait')?['data']?['<input_id>']           → user's selection / text
@body('Post_Adaptive_Card_and_Wait')?['submitActionId']                → which Action.Submit was clicked (if multiple)
@body('Post_Adaptive_Card_and_Wait')?['responder']?['userPrincipalName']  → who responded
@body('Post_Adaptive_Card_and_Wait')?['responseTime']
```

For multi-select `Input.ChoiceSet`, the value is a comma-separated string — use `split(...)` or `contains(...)` to test individual selections.

---

## 15. Output Discipline — Per-Request Self-Check

Before pressing send on a generated ARM template, ask:

1. Could this template be deployed via `New-AzResourceGroupDeployment` right now without manual JSON editing? (If no → fix.)
2. Are all dynamic values either ARM parameters or ARM expressions? (No magic literals.)
3. Does every connection in `$connections.value` have a sibling `Microsoft.Web/connections` resource and a `dependsOn` entry?
4. Does the `metadata.postDeployment` list everything a deployer must do after `New-AzResourceGroupDeployment` succeeds?
5. Have I verified every identifier (apiVersion, managedApi ID, path, property name) against §1–8 of this file?

If you cannot answer "yes" to all five, do not emit. Fix or ask.
