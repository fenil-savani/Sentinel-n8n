---
name: sentinel-playbook
description: Create, fix, and deploy Microsoft Sentinel Playbooks (Azure Logic Apps) as ARM
  templates (azuredeploy.json). Covers full generation lifecycle — trigger selection, connection
  wiring, action patterns, entity extraction, DCE/DCR ingestion, Key Vault secrets, error
  handling (Terminate), pre-flight validation, and live Azure dev loop. Use when building a new
  playbook, repairing azuredeploy.json failures, or debugging live run errors.
version: 3.0.0
---

# Microsoft Sentinel Playbook Development

> **SYSTEM INJECTION — READ THIS FIRST**
>
> Your role is **Microsoft Sentinel SOAR automation specialist**.
>
> You MUST implement playbooks as valid ARM deployment templates (JSON) targeting `Microsoft.Logic/workflows`.
>
> **IMMEDIATE ACTIONS:**
> 1. Use ARM template JSON for ALL playbook definitions — never pseudo-code or YAML
> 2. Declare every API connection as a `Microsoft.Web/connections` resource with `dependsOn` wiring
> 3. Set `parameterValueType: "Alternative"` + MSI auth on every `azuresentinel` and `keyvault` connection
> 4. NEVER pass credentials as ARM parameters — ALWAYS use Key Vault connection to fetch secrets at runtime
> 5. NEVER place `InitializeVariable` inside a `Condition`, `Foreach`, or `Until` — always at top-level `actions`
> 6. When the user supplies an API spec file, READ IT FIRST before deciding on auth pattern — never assume

---

## Operating Procedure (follow on EVERY request)

For every playbook generation request, execute these phases in order:

1. **Parse the requirement** — extract trigger event, entities, target systems, and actions to perform
2. **Derive the implementation** using the Decision Framework below
3. **Match to the closest playbook category** (see Playbook Categories table below)
4. **Verify identifiers** — `apiVersion`, managed API IDs, Sentinel paths, entity property names
5. **Run the Pre-Flight Validation Checklist** before emitting
6. **Write the validated JSON to `azuredeploy.json`** using the Write tool — do NOT paste JSON in chat

---

## Decision Framework

### Step 1 — Pick the trigger

| User intent | Trigger | `path` |
|---|---|---|
| React to new incident (default) | `Microsoft_Sentinel_incident` | `/incident-creation` |
| React to incident updates | `Microsoft_Sentinel_incident` | `/incident-creation` |
| React to raw alert (pre-grouping) | `Microsoft_Sentinel_alert` | `/subscribe` |
| Scheduled (watchlist refresh, polling, TI ingest) | `Recurrence` | — |
| On-demand from another system or playbook | `Request` (kind: Http) | — |
| Per-entity automation (single entity action) | `Microsoft_Sentinel_entity` | `/entity/{kind}` |

### Step 2 — Pick the connection pattern per service

| Service category | Pattern | Auth |
|---|---|---|
| Microsoft Sentinel itself | managed `azuresentinel` | MSI (Alternative + `kind: V1`) |
| Azure AD write / Graph / MDE API | HTTP + App Registration | OAuth2 client credentials (secret in Key Vault) |
| Azure resource APIs (NSG, Firewall, VM) | HTTP | MSI via `authentication: { type: "ManagedServiceIdentity" }` |
| Microsoft 365 (Teams, Outlook) | managed connector | OAuth (post-deploy sign-in) |
| ServiceNow / Jira / Zendesk / Slack / SIGNL4 / GitHub / Okta | managed connector | OAuth or API token |
| Third-party REST (CrowdStrike, Recorded Future, VirusTotal, PagerDuty, TheHive, Tanium) | `Http` action + `securestring` header | API key / OAuth2 |
| VMware Carbon Black, Cisco ISE, Cisco Umbrella | `Microsoft.Web/customApis` custom connector | API key / Basic |
| OAuth2 services needing refreshable token (Zscaler-style) | Nested `Workflow` call to auth sub-playbook | Client credentials in helper Logic App |

### Step 3 — Pick the action shape

| Need | Action `type` | Notes |
|---|---|---|
| Comment on incident | `ApiConnection` → POST `/Incidents/Comment` | `body.incidentArmId` + `body.message` (HTML allowed) |
| Update status/severity/tags/classification | `ApiConnection` → PUT `/Incidents` | Always include `incidentArmId` |
| Extract entities | `ApiConnection` → POST `/entities/<kind>` | Response key is plural Pascal-Case: `Accounts`, `IPs`, `Hosts`, `URLs`, `FileHashes`, `Files` |
| Run KQL | `ApiConnection` (`azuremonitorlogs`) → POST `/queryData` | Pass workspace info from `triggerBody()?['workspaceInfo']` |
| Call any third-party API | `Http` | Prefer `authentication` block over raw `Authorization` header |
| Loop over array | `Foreach` | Sequential? Add `runtimeConfiguration.concurrency.repetitions: 1` |
| Async polling | `Until` | MUST set `limit.count` AND `limit.timeout`; first action inside MUST be `Wait` |
| Group with error handling | `Scope` | Read status via `result('<scope>')[0]['status']` |
| Pause for human input | Adaptive Card + `ApiConnectionWebhook` (Teams `gatherinput`) | Access response with `body('...')?['data']?['fieldId']` |
| Share auth/token across playbooks | Nested `Workflow` call | Sub-playbook MUST have HTTP `Request` trigger + `Response` action; caller MUST set `runtimeConfiguration.secureData.properties: ["inputs","outputs"]` |
| Retrieve a secret | `ApiConnection` (`keyvault`) → GET `/secrets/{name}/value` | Connection uses `parameterValueType: "Alternative"` |
| Fail the run explicitly | `Terminate` | `runStatus: "Failed"` — without this, Logic Apps shows green even when critical actions failed |

### Step 4 — Post-deployment requirements (always emit)

Every generated playbook MUST list in `metadata.postDeployment`:
- Exact RBAC role(s) for the Logic App MSI on the Sentinel workspace (`Microsoft Sentinel Responder` minimum)
- Any managed-connector OAuth sign-in steps (Teams, ServiceNow, Jira, Slack, SIGNL4, GitHub, Okta)
- Key Vault access policy / RBAC if using `keyvault` connection
- App Registration permissions if using HTTP + OAuth2 for Graph / MDE / Azure AD
- Automation-rule creation reminder

---

## Anti-Hallucination Rules

### Rule 1 — Never invent identifiers (closed lists)

**`apiVersion`** — use ONLY:
- `Microsoft.Logic/workflows` → `"2017-07-01"`
- `Microsoft.Web/connections` → `"2016-06-01"`
- `Microsoft.Web/customApis` → `"2016-06-01"`
- `Microsoft.KeyVault/vaults` / `.../secrets` / `.../accessPolicies` → `"2019-09-01"`
- `Microsoft.OperationalInsights/workspaces/tables` → `"2022-10-01"`
- `Microsoft.Insights/dataCollectionEndpoints` / `dataCollectionRules` → `"2022-06-01"`
- `Microsoft.Authorization/roleAssignments` → `"2022-04-01"`

**Schemas** — use verbatim:
- ARM: `"https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"`
- Workflow definition: `"https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#"`

**ManagedApi IDs** — use ONLY: `azuresentinel`, `azuread`, `teams`, `office365`, `office365users`, `keyvault`, `azuremonitorlogs`, `azureloganalyticsdatacollector`, `service-now`, `jira`, `okta`, `slack`, `signl4`, `github`, `azurefunctions`, `azureblob`, `eventhubs`, `zendesk`, `azureautomation`, `outlook`

**Sentinel paths** — use ONLY: `/incident-creation`, `/subscribe`, `/entity/{kind}`, `/entities/account`, `/entities/host`, `/entities/ip`, `/entities/url`, `/entities/filehash`, `/entities/file`, `/Incidents`, `/Incidents/Comment`, `/Incidents/Alerts`

**Entity response keys** — exactly: `Accounts`, `Hosts`, `IPs`, `URLs`, `FileHashes`, `Files`

**Entity property names:**

| Entity | Correct | Common bug |
|---|---|---|
| Account | `accountName`, `upnSuffix`, `AadUserId`, `ntDomain`, `displayName`, `sid` | `username` ❌ |
| Host | `HostName`, `FQDN`, `DnsDomain`, `OSFamily`, `additionalData.MdatpDeviceId` | `Hostname` ❌ |
| IP | `Address` | `IPAddress` ❌, `ip` ❌ |
| URL | `Url` | `URL` ❌, `url` ❌ |
| FileHash | `Value`, `Algorithm` | `hash` ❌, `HashValue` ❌ |
| File | `Name`, `Directory`, `FileHashes` | — |

### Rule 2 — Never invent third-party API endpoints

For CrowdStrike, Okta, TheHive, Tanium, VirusTotal, Recorded Future, MDE, Graph, Zscaler, Carbon Black, Cisco — use ONLY endpoints documented in the integrations reference or provided by the user. If not documented, say so and ask for the API spec.

### Rule 3 — Never skip required ARM boilerplate

Every emitted template MUST include:
- Top-level: `$schema`, `contentVersion`, `metadata`, `parameters`, `variables`, `resources`, `outputs`
- `metadata` with: `title`, `description`, `prerequisites`, `entities`, `tags`, `support`, `author`, `postDeployment`, `releaseNotes`, `lastUpdateTime`
- One `Microsoft.Web/connections` resource per managed API used
- Every connection in workflow's `dependsOn` AND `$connections.value`
- Logic App `identity: { "type": "SystemAssigned" }` for any MSI connection

### Rule 4 — Never write deployment-breaking structures

- ❌ Base URL hardcoded in `Http` action `uri` when an ARM template `variables('BaseUrl')` is defined — but NEVER write `variables('BaseUrl')` directly inside a runtime `@{...}` expression either (see "ARM variables vs workflow variables" below). Reference `parameters('BaseUri')` directly (parameters ARE valid inside `@{...}`), or bake the ARM variable in at deploy time via the escaped-`concat` pattern.
- ❌ `InitializeVariable` inside `Foreach` / `Until` / `Condition` → must be at workflow top level
- ❌ First action missing `"runAfter": {}` — empty object literal is required
- ❌ Accessing `@body('HTTP_...')?['field']` without `ParseJson` on a JSON-string response
- ❌ `kind: "V1"` missing from `azuresentinel` connection resource
- ❌ `connectionName` value not matching `variables('<ConnectionName>')`
- ❌ Hardcoded subscription/tenant/resourceGroup IDs — use `subscription().subscriptionId`, `subscription().tenantId`, `resourceGroup().name`
- ❌ Plain `string` parameter for any API key / client secret / token — use `securestring`
- ❌ User-provided values in URL paths without `encodeURIComponent(...)`
- ❌ `Terminate` `runAfter` includes `"Skipped"` — causes Terminate to fire on the success path when the error-path action was bypassed
- ❌ Block/action name ending in `_URL`/`_url` — fails template validation; use `_Endpoint`/`_Uri`/`_Address`
- ❌ `trim()` on PlaybookName — breaks resource naming

### Rule 5 — Never silently fabricate a value

If a deployment-time value (team channel ID, ServiceNow URL, watchlist name, Key Vault name) is needed and not provided, declare it as an ARM `parameter` with a clear `metadata.description`. Never use `"<your-channel-id>"` inside the workflow definition.

### Rule 6 — Never mix up ARM template variables with workflow (runtime) variables

Two completely different expression languages live in the same file, evaluated at different times:

| | ARM template expressions | Logic Apps workflow expressions |
|---|---|---|
| Syntax | `[concat(...)]`, `[variables('X')]` — string starts with `[` | `@{concat(...)}`, `@variables('X')` — string starts with `@` |
| Evaluated | Once, at deployment time, by ARM | Every run, at execution time, by the Logic Apps engine |
| `variables('X')` refers to | The top-level `"variables": {}` block of the ARM template | A workflow variable created by an `InitializeVariable` action inside the flow |

**The bug:** writing `variables('BaseUrl')` inside an `@{...}` runtime expression when `BaseUrl` was only ever declared as an ARM template variable (not initialized in the workflow via `InitializeVariable`). ARM does not touch this string — it doesn't start with `[` — so it's passed through literally into the deployed definition. At runtime the Logic Apps engine looks for a workflow variable named `BaseUrl`, doesn't find one, and the run fails:

```
The variable 'BaseUrl' must be initialized before it can be used inside action 'X'. (Code: InvalidVariableOperation)
```

This is deceptive because deployment/template validation passes — the error only surfaces when the flow actually runs.

❌ Wrong (mixes ARM variable name into a runtime expression):
```json
"uri": "@{concat(variables('GTIBaseUrl'), '/api/v3/collections/vulnerability--', toLower(triggerBody()?['cveId']))}"
```

✅ Fix option A — bake the ARM variable's value into the string at deploy time with an ARM `[concat(...)]` expression, escaping embedded single quotes by doubling them (`''`):
```json
"uri": "[concat('@{concat(''', variables('GTIBaseUrl'), ''', ''/api/v3/collections/vulnerability--'', toLower(triggerBody()?[''cveId'']))}')]"
```
This evaluates at deploy time to `@{concat('https://www.virustotal.com', '/api/v3/collections/vulnerability--', toLower(triggerBody()?['cveId']))}` — a runtime expression with the base URL as a plain string literal, no variable lookup.

✅ Fix option B (simpler when there's no reason to keep the value ARM-side) — declare it as an ARM `parameter` instead of an ARM `variable`. Parameters ARE valid inside `@{...}` runtime expressions:
```json
"uri": "@{concat(parameters('BaseUrl'), '/api/v3/...')}"
```

✅ Fix option C — if the value genuinely needs to be a *workflow* variable (e.g. it can change during a run), add an `InitializeVariable` action for it before first use, seeded from the ARM variable/parameter:
```json
"Initialize_BaseUrl": {
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "BaseUrl", "type": "string", "value": "[variables('GTIBaseUrl')]" }] },
  "runAfter": {}
}
```

Prefer option A when the value is a fixed constant (single source of truth in the ARM `variables` block, no extra workflow action). Use option C only when the value must be mutable at runtime.

---

## ARM Template Skeleton

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "metadata": {
    "title": "Playbook-Name",
    "description": "What this playbook does",
    "prerequisites": ["Pre-req 1"],
    "entities": ["Account"],
    "tags": ["Microsoft Sentinel", "Incident"],
    "support": { "tier": "community" },
    "author": { "name": "Your Name" },
    "postDeployment": [
      "Grant the Logic App Managed Identity 'Microsoft Sentinel Responder' on the Sentinel workspace"
    ],
    "releaseNotes": [{ "version": "1.0.0", "title": "Initial version", "notes": ["Initial release"] }],
    "lastUpdateTime": "2026-06-29T00:00:00.000Z"
  },
  "parameters": {
    "PlaybookName": { "defaultValue": "My-Playbook", "type": "string" }
  },
  "variables": {
    "azuresentinel": "[concat('azuresentinel-', parameters('PlaybookName'))]"
  },
  "resources": [
    { "/* Microsoft.Web/connections — one per API */" },
    { "/* Microsoft.Logic/workflows — the playbook logic */" }
  ],
  "outputs": {}
}
```

`metadata.entities` valid values: `Account`, `Host`, `Ip`, `Url`, `File`, `FileHash`, `Process`, `Mailbox`, `MailMessage`, `CloudApplication`, `DnsResolution`, `RegistryKey`, `RegistryValue`, `SecurityGroup`

---

## Trigger Types

### Incident Trigger (most common)

```json
"triggers": {
  "Microsoft_Sentinel_incident": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
      "path": "/incident-creation"
    }
  }
}
```

**Key trigger body expressions:**

| Field | Expression |
|-------|-----------|
| Incident ARM ID (use as `incidentArmId`) | `@triggerBody()?['object']?['id']` |
| Incident title | `@triggerBody()?['object']?['properties']?['title']` |
| Severity | `@triggerBody()?['object']?['properties']?['severity']` |
| Status | `@triggerBody()?['object']?['properties']?['status']` |
| Incident number | `@triggerBody()?['object']?['properties']?['incidentNumber']` |
| Incident URL | `@triggerBody()?['object']?['properties']?['incidentUrl']` |
| Description | `@triggerBody()?['object']?['properties']?['description']` |
| Related entities | `@triggerBody()?['object']?['properties']?['relatedEntities']` |
| Alerts (for Custom Details) | `@triggerBody()?['object']?['properties']?['alerts']` |
| Tactics | `@triggerBody()?['object']?['properties']?['tactics']` |
| Labels | `@triggerBody()?['object']?['properties']?['labels']` |
| Workspace subscription | `@triggerBody()?['workspaceInfo']?['SubscriptionId']` |
| Workspace resource group | `@triggerBody()?['workspaceInfo']?['ResourceGroupName']` |
| Update-trigger changed fields | `@triggerBody()?['incidentUpdates']?['updatedFields']` |

### Alert Trigger

```json
"triggers": {
  "Microsoft_Sentinel_alert": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
      "path": "/subscribe"
    }
  }
}
```

Alert body: `@triggerBody()?['SystemAlertId']`, `@triggerBody()?['AlertSeverity']`, `@triggerBody()?['AlertDisplayName']`

### Entity Trigger

```json
"triggers": {
  "Microsoft_Sentinel_entity": {
    "type": "ApiConnectionWebhook",
    "inputs": {
      "body": { "callback_url": "@{listCallbackUrl()}" },
      "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
      "path": "/entity/@{encodeURIComponent(triggerBody()?['Entity']?['kind'])}"
    }
  }
}
```

Entity body: `@triggerBody()?['Entity']?['kind']`, `@triggerBody()?['Entity']?['properties']?['address']`, etc. **No incident context** — cannot add incident comments.

### Recurrence Trigger

```json
"triggers": {
  "Recurrence": {
    "type": "Recurrence",
    "recurrence": { "frequency": "Hour", "interval": 6, "timeZone": "UTC" }
  }
}
```

Frequency values: `Second`, `Minute`, `Hour`, `Day`, `Week`, `Month`

### HTTP Trigger (Manual / API-callable)

```json
"triggers": {
  "manual": {
    "type": "Request", "kind": "Http",
    "inputs": { "schema": { "type": "object", "properties": { "incidentId": { "type": "string" } } } }
  }
}
```

---

## Connection Declarations

### Pattern: Variable + Resource + `$connections` wiring

**1. Variable:** `"azuread": "[concat('azuread-', parameters('PlaybookName'))]"`

**2. Resource:**
```json
{
  "type": "Microsoft.Web/connections", "apiVersion": "2016-06-01",
  "name": "[variables('azuread')]", "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]" }
  }
}
```

**3. `$connections` wiring:**
```json
"azuread": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuread'))]",
  "connectionName": "[variables('azuread')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuread')]"
}
```

**4. `dependsOn` entry:** `"[resourceId('Microsoft.Web/connections', variables('azuread'))]"`

### azuresentinel — ALWAYS MSI + Alternative + kind V1

```json
/* Resource — note parameterValueType and kind */
{
  "type": "Microsoft.Web/connections", "apiVersion": "2016-06-01",
  "name": "[variables('azuresentinel')]", "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "customParameterValues": {},
    "parameterValueType": "Alternative",
    "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuresentinel')]" }
  }
}

/* $connections wiring — ALWAYS include connectionProperties */
"azuresentinel": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('azuresentinel'))]",
  "connectionName": "[variables('azuresentinel')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azuresentinel')]",
  "connectionProperties": { "authentication": { "type": "ManagedServiceIdentity" } }
}
```

### keyvault — MSI + alternativeParameterValues

```json
/* Resource */
{
  "type": "Microsoft.Web/connections", "apiVersion": "2016-06-01",
  "name": "[variables('keyvault')]", "location": "[resourceGroup().location]",
  "kind": "V1",
  "properties": {
    "displayName": "[parameters('PlaybookName')]",
    "parameterValueType": "Alternative",
    "alternativeParameterValues": { "vaultName": "[parameters('KeyVaultName')]" },
    "customParameterValues": {},
    "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/keyvault')]" }
  }
}

/* $connections wiring */
"keyvault": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('keyvault'))]",
  "connectionName": "[variables('keyvault')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/keyvault')]",
  "connectionProperties": { "authentication": { "type": "ManagedServiceIdentity" } }
}
```

**Key Vault gotchas:**
| Error | Cause | Fix |
|---|---|---|
| `InvalidApiConnectionApiReference` / ParameterValues should be null | Used `parameterValues` on KV connection | Remove `parameterValues`; use `alternativeParameterValues` + `parameterValueType: "Alternative"` |
| `WorkflowManagedIdentityConfigurationInvalid` | Missing `connectionProperties.authentication` in `$connections` | Add `connectionProperties: { authentication: { type: "ManagedServiceIdentity" } }` |
| `authentication not valid on ApiConnectionPropertiesDefinition` | Added `authentication` to `Microsoft.Web/connections` resource | Remove it — it belongs only in Logic App `$connections` wiring |

### ManagedApi IDs Quick Reference

| Service | ID | Auth |
|---------|---|------|
| Microsoft Sentinel | `azuresentinel` | MSI (Alternative) |
| Azure AD | `azuread` | OAuth |
| Key Vault | `keyvault` | MSI (Alternative) |
| Office 365 | `office365` | OAuth |
| Microsoft Teams | `teams` | OAuth |
| Log Analytics (query) | `azuremonitorlogs` | OAuth |
| Log Analytics (ingest) | `azureloganalyticsdatacollector` | Workspace ID/Key |
| ServiceNow | `service-now` | Basic/OAuth |
| Zendesk | `zendesk` | OAuth/API Token |
| Jira | `jira` | OAuth |
| Okta | `okta` | API Token |
| Slack (managed) | `slack` | OAuth |
| GitHub | `github` | OAuth |
| SIGNL4 | `signl4` | OAuth |
| Azure Functions | `azurefunctions` | MSI / Function Key |

---

## Action Types Reference

### Entity Extraction

```json
"Entities_-_Get_Accounts": {
  "runAfter": {},
  "type": "ApiConnection",
  "inputs": {
    "body": "@triggerBody()?['object']?['properties']?['relatedEntities']",
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post", "path": "/entities/account"
  }
}
```

Loop input: `@body('Entities_-_Get_Accounts')?['Accounts']`
Item fields: `items('For_each')?['accountName']`, `?['AadUserId']`, `?['upnSuffix']`

Other paths: `/entities/host` → `?['Hosts']`, `/entities/ip` → `?['IPs']`, `/entities/url` → `?['URLs']`, `/entities/filehash` → `?['FileHashes']`

### Add Comment to Incident

```json
"Add_comment_to_incident_(V3)": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "message": "<p><strong>Action completed</strong><br>@{variables('ResultSummary')}</p>"
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post", "path": "/Incidents/Comment"
  }
}
```

### Update Incident

```json
"Update_incident": {
  "type": "ApiConnection",
  "inputs": {
    "body": {
      "incidentArmId": "@triggerBody()?['object']?['id']",
      "severity": "High",
      "status": "Active",
      "tagsToAdd": { "TagsToAdd": [{ "Tag": "AutoContained" }] }
    },
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "put", "path": "/Incidents"
  }
}
```

Close incident: same PUT with `"status": "Closed"` and `"classification": { "ClassificationAndReason": "FalsePositive - IncorrectAlertLogic", "ClassificationReasonText": "..." }`

Classification options: `BenignPositive - SuspiciousButExpected`, `FalsePositive - InaccurateData`, `FalsePositive - IncorrectAlertLogic`, `TruePositive - SuspiciousActivity`, `Undetermined`

### HTTP Action (External API)

```json
"HTTP_-_Call_External_API": {
  "type": "Http",
  "inputs": {
    "method": "GET",
    "uri": "https://api.example.com/v1/resource/@{encodeURIComponent(variables('resourceId'))}",
    "headers": {
      "User-Agent": "azure-sentinel-playbook/1.0",
      "Authorization": "Bearer @{body('Get_Secret')?['value']}",
      "Content-Type": "application/json"
    },
    "retryPolicy": { "type": "exponential", "count": 3, "interval": "PT10S", "minimumInterval": "PT10S", "maximumInterval": "PT1H" }
  }
}
```

### Key Vault Get Secret

```json
"Get_Secret": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['keyvault']['connectionId']" } },
    "method": "get",
    "path": "[concat('/secrets/@{encodeURIComponent(''', parameters('KeyVaultSecretName'), ''')}/value')]"
  }
}
```

Access value: `@body('Get_Secret')?['value']`
Mask: add `"runtimeConfiguration": { "secureData": { "properties": ["inputs", "outputs"] } }`

### OAuth2 Client Credentials (App Registration)

```json
"HTTP_-_Authenticate": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "[concat('https://login.microsoftonline.com/', subscription().tenantId, '/oauth2/v2.0/token')]",
    "headers": { "Content-Type": "application/x-www-form-urlencoded" },
    "body": "[concat('grant_type=client_credentials&client_id=', parameters('ClientId'), '&client_secret=@{body(''Get_Client_Secret'')?[''value'']}&scope=https://graph.microsoft.com/.default')]"
  }
}
```

Scope by API: MDE → `https://api.securitycenter.microsoft.com/.default`, Graph → `https://graph.microsoft.com/.default`, ARM → `https://management.azure.com/.default`

Then: `@body('Parse_JSON_-_Token')?['access_token']`

### Variables

```json
"Initialize_variable": {
  "type": "InitializeVariable",
  "inputs": { "variables": [{ "name": "ResultSummary", "type": "string", "value": "" }] }
}
```

Types: `string`, `integer`, `float`, `boolean`, `array`, `object`
Update inside loops: `SetVariable`, `AppendToStringVariable`, `AppendToArrayVariable`, `IncrementVariable` (never `SetVariable` to self-reference — use `IncrementVariable`)

### Foreach Loop

```json
"For_each": {
  "type": "Foreach",
  "foreach": "@body('Entities_-_Get_Accounts')?['Accounts']",
  "actions": { "Process_Account": { "runAfter": {}, "type": "..." } },
  "runAfter": { "Entities_-_Get_Accounts": ["Succeeded"] },
  "runtimeConfiguration": { "concurrency": { "repetitions": 1 } }
}
```

Use `repetitions: 1` when: writing to shared variables, calling rate-limited APIs, needing deterministic order.

### Condition (If/Else)

```json
"Condition": {
  "type": "If",
  "expression": {
    "and": [{ "equals": ["@triggerBody()?['object']?['properties']?['severity']", "High"] }]
  },
  "actions": { /* true branch */ },
  "else": { "actions": { /* false branch */ } }
}
```

Operators: `equals`, `not`, `greater`, `greaterOrEquals`, `less`, `lessOrEquals`, `contains`, `startsWith`, `endsWith`

### Switch

```json
"Switch": {
  "type": "Switch",
  "expression": "@triggerBody()?['object']?['properties']?['severity']",
  "cases": {
    "High": { "case": "High", "actions": { /* ... */ } },
    "Medium": { "case": "Medium", "actions": { /* ... */ } }
  },
  "default": { "actions": {} }
}
```

### Until Loop (Async Polling / Explicit 429 retry)

```json
"Until_-_Wait_for_Completion": {
  "type": "Until",
  "expression": "@equals(variables('IsComplete'), true)",
  "limit": { "count": 60, "timeout": "PT1H" },
  "actions": {
    "Wait_10_Seconds": {
      "runAfter": {},
      "type": "Wait",
      "inputs": { "interval": { "count": 10, "unit": "Second" } }
    },
    "Check_Status": {
      "runAfter": { "Wait_10_Seconds": ["Succeeded"] },
      "type": "Http",
      "inputs": { "method": "GET", "uri": "...", "headers": { "Authorization": "..." } }
    }
  }
}
```

Initialize before: `IsComplete` (boolean = false), `ActionId` (string = "")
Always set both `limit.count` AND `limit.timeout`. First inner action MUST be `Wait`.
Use `IncrementVariable` (not `SetVariable`) for loop counters to avoid self-reference errors.

### Scope (Grouped Error Handling)

```json
"Try_Scope": { "type": "Scope", "actions": { /* HTTP actions */ } },
"Catch_Scope": {
  "type": "Scope",
  "actions": { "Log_Error": { "runAfter": {}, "type": "Compose", "inputs": "Error: @{result('Try_Scope')}" } },
  "runAfter": { "Try_Scope": ["Failed", "TimedOut", "Skipped"] }
}
```

Check scope result: `@result('Try_Scope')[0]['status']` → `Succeeded` | `Failed` | `TimedOut` | `Skipped`

### Terminate (Fail the Run Explicitly)

Without `Terminate`, Logic Apps marks a run as **Succeeded** even when critical actions failed — run history shows green but nothing happened.

```json
"Terminate_-_API_Error": {
  "runAfter": { "<Failed_Action>": ["Failed", "TimedOut"] },
  "type": "Terminate",
  "inputs": {
    "runStatus": "Failed",
    "runError": {
      "code": "@{variables('APIStatusCode')}",
      "message": "@{concat('API error. Status: ', variables('APIStatusCode'))}"
    }
  }
}
```

**Cancelling on a prerequisite failure (e.g. Get Secret):**
```json
"Terminate_Secret_Failed": {
  "type": "Terminate",
  "inputs": { "runStatus": "Cancelled" },
  "runAfter": { "Get_Secret": ["Failed", "TimedOut", "Skipped"] }
},
"Next_Action": {
  "runAfter": { "Get_Secret": ["Succeeded"] },
  ...
}
```
`runStatus: "Cancelled"` is correct for prerequisite failures (missing config, secret not found). `runStatus: "Failed"` + `runError` is for unexpected runtime errors. **`Cancelled` does NOT support `runError` properties.**

**runAfter discipline — critical:**
- NEVER include `"Skipped"` in a Terminate's `runAfter` when the preceding action can be bypassed on the success path — this causes Terminate to fire even when everything succeeded
- Wire Terminate to `["Failed", "TimedOut"]` on the failed action (direct), OR to `["Succeeded", "Failed"]` on a notification action that runs only on failure path

### Nested Logic App (Workflow Call)

```json
"Call_Auth_Helper": {
  "runAfter": {},
  "type": "Workflow",
  "inputs": {
    "host": {
      "triggerName": "manual",
      "workflow": {
        "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Logic/workflows/', parameters('BasePlaybookName'))]"
      }
    },
    "body": {}
  },
  "runtimeConfiguration": { "secureData": { "properties": ["inputs", "outputs"] } }
}
```

### Alert Custom Details Extraction

**NEVER** read custom details from `triggerBody()?['object']?['properties']?['additionalData']` — that path only holds entity fields. Custom Details are per-alert and require a two-level loop:

```json
"For_each_-_Alert": {
  "type": "Foreach",
  "foreach": "@triggerBody()?['object']?['properties']?['alerts']",
  "runtimeConfiguration": { "concurrency": { "repetitions": 1 } },
  "actions": {
    "Parse_JSON_-_Alert_Custom_Details": {
      "runAfter": {},
      "type": "ParseJson",
      "inputs": {
        "content": "@items('For_each_-_Alert')?['properties']?['additionalData']?['Custom Details']",
        "schema": { "type": "object", "properties": { "<your_key>": { "type": "array", "items": { "type": "string" } } } }
      }
    }
  }
}
```

### Pagination Pattern (Until loop)

```json
"Initialize_variable_-_Offset": { "type": "InitializeVariable", "inputs": { "variables": [{ "name": "Offset", "type": "integer", "value": 0 }] } },
"Initialize_variable_-_TotalResults": { "type": "InitializeVariable", "inputs": { "variables": [{ "name": "TotalResults", "type": "integer", "value": 1 }] } },
"Until_-_All_Pages_Fetched": {
  "type": "Until",
  "expression": "@greaterOrEquals(variables('Offset'), variables('TotalResults'))",
  "limit": { "count": 100, "timeout": "PT2H" },
  "actions": {
    "HTTP_-_Fetch_Page": { "runAfter": {}, "type": "Http", "inputs": { "method": "GET", "uri": "https://api.example.com/data?limit=100&offset=@{variables('Offset')}" } },
    "Set_TotalResults": { "type": "SetVariable", "inputs": { "name": "TotalResults", "value": "@body('Parse_Page')?['total']" } },
    "Increment_Offset": { "type": "IncrementVariable", "inputs": { "name": "Offset", "value": 100 } }
  }
}
```

### KQL Query

```json
"Run_query_and_list_results": {
  "type": "ApiConnection",
  "inputs": {
    "body": "SecurityEvent | where TimeGenerated > ago(1h) | limit 10",
    "host": { "connection": { "name": "@parameters('$connections')['azuremonitorlogs']['connectionId']" } },
    "method": "post", "path": "/queryData",
    "queries": {
      "subscriptions": "@triggerBody()?['workspaceInfo']?['SubscriptionId']",
      "resourcegroups": "@triggerBody()?['workspaceInfo']?['ResourceGroupName']",
      "resourcetype": "Log Analytics Workspace",
      "resourcename": "[parameters('WorkspaceName')]",
      "timerange": "Last 24 hours"
    }
  }
}
```

Access results: `@body('Run_query_and_list_results')?['value']`
HTML table for comment: use `"path": "/visualizeQuery"` + `"visType": "Html Table"` → `@{base64ToString(body(...)?['attachmentContent'])}`

### Teams Adaptive Card with Wait-for-Response

```json
"Post_Adaptive_Card_and_Wait": {
  "type": "ApiConnectionWebhook",
  "inputs": {
    "body": {
      "body": { "messageBody": "@{outputs('Compose_-_Adaptive_Card')}" },
      "notificationUrl": "@{listCallbackUrl()}"
    },
    "host": { "connection": { "name": "@parameters('$connections')['teams']['connectionId']" } },
    "method": "post",
    "path": "/v1.0/teams/conversation/gatherinput/poster/Flow bot/location/@{encodeURIComponent('Channel')}/$subscriptions",
    "queries": { "groupId": "[parameters('TeamId')]", "channelId": "[parameters('ChannelId')]" }
  }
}
```

Access response: `@body('Post_Adaptive_Card_and_Wait')?['data']?['analystAction']`
Analyst identity: `@body('Post_Adaptive_Card_and_Wait')?['responder']?['userPrincipalName']`

---

## `runAfter` Dependency Pattern

Every action (except the first) must declare `runAfter`. The first action uses `"runAfter": {}`.

```json
"Second_Action": { "runAfter": { "First_Action": ["Succeeded"] } },
"Cleanup_Action": { "runAfter": { "Second_Action": ["Succeeded", "Failed"] } }
```

Status values: `Succeeded`, `Failed`, `Skipped`, `TimedOut`

---

## Playbook Categories

| Category | Entity | Connections | Pattern |
|----------|--------|-------------|---------|
| Identity Response | Account | azuresentinel, azuread / keyvault | Disable user, revoke sessions, force MFA |
| Endpoint Response | Host | azuresentinel, keyvault (MDE/CrowdStrike API) | Isolate/contain machine |
| IP Enrichment | Ip | azuresentinel, azuremonitorlogs + HTTP | TI lookup, RFC1918 filter, custom table |
| Email Notification | — | azuresentinel, office365 | HTML-formatted incident email |
| Chat Notification | — | azuresentinel, teams / HTTP Slack | Adaptive card or simple message |
| Interactive Approval | — | azuresentinel, teams | Adaptive card + wait for response |
| Ticketing | — | azuresentinel, service-now / jira / zendesk | Create/update ticket, bi-directional sync |
| Watchlist Update | — | azuresentinel, azuremonitorlogs | Add/refresh watchlist entries |
| Watchlist Auto-Triage | Ip | azuresentinel, azuremonitorlogs | Check entity against watchlist, auto-close if known-safe |
| Blocking | Ip / Host | azuresentinel + HTTP (NSG/Firewall API) | Block IP via REST API |
| SOAR Integration | — | azuresentinel + HTTP (TheHive/D3/XSOAR) | Create case with observables |
| Async Remediation | Host | azuresentinel, keyvault + HTTP (Tanium/SSM) | Issue action, poll Until complete |
| Threat Intel Ingestion | — | azuresentinel (Recurrence) | Scheduled fetch + paginate + watchlist |
| Sub-playbook (Shared Auth) | — | Logic App Workflow call | Shared credential/token helper (OAuth2 sub-playbook) |
| Custom Connector | Host / Ip | azuresentinel + `Microsoft.Web/customApis` | Carbon Black, Cisco ISE, Cisco Umbrella |

---

## Severity Mapping

| Sentinel Severity | ServiceNow Urgency/Impact | Jira Priority | PagerDuty Severity |
|-------------------|--------------------------|---------------|-------------------|
| High | 1 | Highest (1) | critical |
| Medium | 2 | High (2) | error |
| Low | 3 | Medium (3) | warning |
| Informational | 4 | Low (4) | info |

Use a `Switch` action to set a `TicketPriority` variable before creating any external ticket.

---

## Security Rules

1. **NEVER pass credentials as ARM parameters** — always use a `keyvault` connection + `Get_Secret` actions at runtime
2. **ALWAYS use MSI** for `azuresentinel` and `keyvault` connections
3. **ALWAYS add `Microsoft Sentinel Responder`** role assignment instruction in `postDeployment` metadata
4. **ALWAYS add `Key Vault Secrets User`** role assignment instruction when a `keyvault` connection is used
5. **Validate HTTP status codes** before trusting response bodies — check `outputs('HTTP_action')['statusCode']`
6. **READ the user-supplied API spec** before deciding on auth — never assume static API key if spec shows OAuth2

---

## Pre-Flight Validation Checklist

Before emitting any ARM template, walk every item. Fix before output — never show a half-validated template.

**ARM structure**
- [ ] `$schema`, `contentVersion`, all required `metadata` fields present
- [ ] `metadata.entities` lists every entity kind touched (Pascal-Case)
- [ ] Every secret parameter uses `securestring`

**Connections**
- [ ] One `Microsoft.Web/connections` resource per managed API used
- [ ] `azuresentinel` connection has `kind: "V1"`, `parameterValueType: "Alternative"`, `customParameterValues: {}`
- [ ] `keyvault` uses `parameterValueType: "Alternative"` + `alternativeParameterValues.vaultName`
- [ ] Every connection is in workflow's `dependsOn`
- [ ] Every connection is in `$connections.value` with correct `connectionId`, `connectionName`, `id`
- [ ] MSI connections include `connectionProperties.authentication.type: "ManagedServiceIdentity"` in `$connections.value`

**Workflow**
- [ ] `identity: { "type": "SystemAssigned" }` present
- [ ] `$connections` parameter declared as `{ "defaultValue": {}, "type": "Object" }`
- [ ] Workflow `tags` include `hidden-SentinelTemplateName` and `hidden-SentinelTemplateVersion`

**Actions**
- [ ] First action has `"runAfter": {}` (empty object literal)
- [ ] No `InitializeVariable` inside any `Foreach`, `Until`, OR `Condition` — ALWAYS at top-level `actions`
- [ ] Every `Http` action has a `User-Agent` header with version matching metadata version
- [ ] Every `Http` `uri` that has a base URL uses a `variables()`/`parameters()` reference — no literal `https://...` hardcoded when a variable is defined
- [ ] `Get_Secret` (or any other critical prerequisite) is followed by `Terminate` on `["Failed", "TimedOut", "Skipped"]`; downstream actions run only on `["Succeeded"]`
- [ ] `Terminate` with `runStatus: "Cancelled"` has NO `runError` block
- [ ] Every HTTP-string response is `ParseJson`'d before `@body()` field access
- [ ] Every `Until` has `limit.count` AND `limit.timeout`; first inner action is `Wait`
- [ ] Every `Foreach` writing shared variables has `concurrency.repetitions: 1`
- [ ] Every nested `Workflow` call has `secureData.properties: ["inputs","outputs"]`
- [ ] Error-path `Terminate` actions do NOT include `"Skipped"` in `runAfter`

**Identifiers**
- [ ] Every `apiVersion` from the closed list (§ Anti-Hallucination Rules)
- [ ] Every managedApi ID from the closed list
- [ ] Every Sentinel path from the closed list
- [ ] Every entity property name from the closed list

**Parameters**
- [ ] No third-party credentials as ARM parameters of any type
- [ ] No `defaultValue: ""` on workflow-level `String` parameters
- [ ] No hardcoded subscription/tenant/resource-group IDs

---

## Verify first (MCP)
Run `run_one_check("check_playbook", <solution>)` (validates ARM schema, parameters, metadata).

## Live test on Azure (dev loop)
Deploy & run against the workspace (full loop: **sentinel-azure-devtest**):
`deploy_arm_template(template_path=<azuredeploy.json>, parameters={PlaybookName:...}, mode="validate"→"create")`
→ `list_playbooks()` / `get_playbook(name)` → `trigger_playbook(name, trigger_name="manual", body={...})`
→ `get_playbook_runs(name)` (status Succeeded / error). Common failure: **unauthorized API connections**
(authorize once in the portal). Fix here → redeploy → re-trigger.

### Deploying secrets (e.g. API keys)
Playbook params don't support `secureString`-from-input safely — pass secret params via a **Key Vault
reference** in a params file (`{"reference":{"keyVault":{"id":"<vault>"},"secretName":"<name>"}}`), never
inline. Non-secret params (PlaybookName, URLs) pass directly. The referenced vault **must** have
`enabledForTemplateDeployment=true` (`deploy_arm_template` enforces this). One secret → one param.

### Debugging a failed run (drill-down)
`get_playbook_runs` shows the run status; a top-level *"An action failed. No dependent actions
succeeded."* is just the **cascade** — find the real cause by listing the run's **actions**:
`az rest GET .../workflows/<name>/runs/<runId>/actions?api-version=2019-05-01`. The first **Failed**
action is the culprit; downstream actions show `Skipped` (`runAfter` not satisfied). Fetch that action's
`outputsLink.uri` for the HTTP status/body.

### Common live errors → fix

| Symptom (in run/action) | Root cause | Fix |
|---|---|---|
| HTTP action **401 Unauthorized**, downstream actions Skipped | Invalid/expired key, wrong auth-header format (`Token` vs `Bearer`), wrong base URL | Verify secret, auth header format, base URL; re-trigger |
| HTTP action **403** / connection error referencing a connection | API connection not authorized | Portal → Logic App → API connections → Edit → **Authorize** → Save |
| DCE POST **403** `does not have access to ingest data for the data collection rule` | Logic App MSI missing `Monitoring Metrics Publisher` role on DCR | Add `Microsoft.Authorization/roleAssignments` to ARM (see DCE/DCR section). Wait 1–3 min after deploy |
| DCE POST **403** immediately after fresh deploy | RBAC not yet propagated | Wait 1–3 minutes, then re-trigger |
| Run `Failed`, top action says "no dependent actions succeeded" | A nested action failed | Drill into `/runs/<id>/actions` — fix the first `Failed` action, not the cascade |
| Trigger present but no runs | Manual/Request trigger (won't auto-run) or Recurrence not yet fired | `trigger_playbook(name)` to test now |
| `ParseJson` fails: "Required property 'content' expects a value but got null" | Reading alert Custom Details from incident-level `additionalData` | Loop over `alerts`, then `ParseJson` each alert's `additionalData['Custom Details']` |
| `BadRequest: $connections value is invalid` | `connectionName` in `$connections.value` doesn't match connection resource name | Set `connectionName` to `variables('<ConnectionVariable>')` everywhere |
| `InvalidVariableInitialization` at deploy | `InitializeVariable` nested inside a `Condition` (If) action | Move ALL `InitializeVariable` to top-level `actions` |
| Playbook ends as Succeeded despite API failure | No `Terminate` action on error path | Add `Terminate` with `runStatus: "Failed"` on every critical failure path |
| Terminate fires on success path | `Terminate` `runAfter` includes `"Skipped"` | Remove `"Skipped"` from Terminate's `runAfter` |
| `Terminate` with `runStatus: "Cancelled"` — deploy error `WorkflowRunActionInputsInvalidProperty` | `runError.code`/`runError.message` set on a Cancelled terminate — these properties are only valid for `"Failed"` status | Remove `runError` entirely; `runStatus: "Cancelled"` takes no error properties |
| Get Secret fails — playbook continues silently with blank API key | No `Terminate` after `Get_Secret` failure path | Add `Terminate_Secret_Failed` with `runStatus: "Cancelled"` immediately after `Get_Secret`; wire downstream actions to `Get_Secret: ["Succeeded"]` only |
| `Variable 'X' is not initialized` | `InitializeVariable` inside a loop | Initialize all variables at top level, before any loop |
| `The variable 'X' must be initialized before it can be used inside action 'Y'. (Code: InvalidVariableOperation)` — fails only at run time, deploy/validate passes | `variables('X')` referenced inside an `@{...}` runtime expression, but `X` was only ever declared as an ARM template `variables` entry, never created via a workflow `InitializeVariable` action — see Rule 6 | Bake the ARM variable's value in at deploy time with an ARM `[concat(...)]` expression (escape embedded quotes as `''`), or reference an ARM `parameter` instead (valid at runtime), or add an `InitializeVariable` action seeded from the ARM variable |
| Foreach runs in parallel when serial was needed | Default concurrency is parallel (50) | Add `runtimeConfiguration.concurrency.repetitions: 1` |
| Until loop runs forever | No `limit` set | Always set both `count` and `timeout` |
| `SetVariable` self-reference error `WorkflowRunActionInputsInvalidProperty` | Updating a variable using its own current value in a `SetVariable` action (e.g. `@if(less(variables('X'), 10), mul(variables('X'), 2), 10)`) | Add a `Compose` action first to compute the new value, then `SetVariable` using `@outputs('Compose_action_name')` |
| `RoleAssignmentUpdateNotPermitted` on re-deploy | Role assignment GUID is stable but Logic App was deleted + recreated, giving it a new identity — ARM can't update the existing assignment's `principalId` | Add a `RoleAssignmentGuid` parameter with `defaultValue: "[newGuid()]"` and use it as the role assignment `name` — each deploy mints a fresh GUID, creating a new assignment rather than updating the old one |
| `reference()` not allowed in role assignment `name` | ARM only supports `reference()` in resource `properties`, not in `name` | Use a `newGuid()` parameter or a `guid()` seeded from static values; never call `reference()` inside a resource `name` expression |

---

## Team playbook checklist
1. **Mandatory fields only in the response schema** — include only the API's mandatory fields in `required`; optional fields stay optional.
2. **No hardcoded values in playbook parameters** before saving the template.
3. **Secrets from Key Vault, not parameters** — never take passwords/secret keys via input parameters.
4. **No hardcoded API connection parameters** (endpoints/keys/connection ids).
5. **Metadata filled properly** — title/description/prerequisites/author/lastUpdateTime/releaseNotes.
6. **No static URLs/creds in mainTemplate** — use parameters/variables.
7. **User-Agent header in every HTTP call** — include on ALL `Http` actions (API calls, DCE ingestion, auth calls). Use version matching the playbook metadata version (e.g. `"azure-sentinel-gti-playbook/1.0.0"` for a 1.0.0 playbook). Never omit on ingestion actions.
8. **No `trim()` on the PlaybookName parameter** — breaks resource naming/deploy.
9. **No block/action name ending in `_URL`/`_url`** — fails mainTemplate validation.
10. **No `defaultValue: ""` on workflow-level `String` parameters** — omit `defaultValue` if no real default exists.

---

## DCE / DCR / Log Ingestion API

Embed DCE + DCR + custom table as ARM resources so they auto-create on deploy.

### Resource name length
DCE/DCR names are capped at **44 chars**. Always use `uniqueString()`:
```json
"variables": {
  "DCEName": "[concat('GTI-DCE-', uniqueString(parameters('PlaybookName')))]",
  "DCRName": "[concat('GTI-DCR-', uniqueString(parameters('PlaybookName')))]"
}
```

### Deployment order (dependsOn matters)
1. `Microsoft.OperationalInsights/workspaces/tables` — table must exist before DCR
2. `Microsoft.Insights/dataCollectionEndpoints` (DCE)
3. `Microsoft.Insights/dataCollectionRules` — dependsOn both table + DCE
4. `Microsoft.Logic/workflows` — dependsOn DCR
5. `Microsoft.Authorization/roleAssignments` — dependsOn DCR + Logic App

```json
{
  "type": "Microsoft.OperationalInsights/workspaces/tables",
  "apiVersion": "2022-10-01",
  "name": "[concat(parameters('WorkspaceName'), '/MyTable_CL')]",
  "properties": { "schema": { "name": "MyTable_CL", "columns": [ /* columns */ ] } }
},
{
  "type": "Microsoft.Insights/dataCollectionEndpoints",
  "apiVersion": "2022-06-01",
  "name": "[variables('DCEName')]",
  "location": "[resourceGroup().location]",
  "properties": { "networkAcls": { "publicNetworkAccess": "Enabled" } }
},
{
  "type": "Microsoft.Insights/dataCollectionRules",
  "apiVersion": "2022-06-01",
  "name": "[variables('DCRName')]",
  "dependsOn": [
    "[resourceId('Microsoft.Insights/dataCollectionEndpoints', variables('DCEName'))]",
    "[resourceId('Microsoft.OperationalInsights/workspaces/tables', parameters('WorkspaceName'), 'MyTable_CL')]"
  ],
  "properties": {
    "dataCollectionEndpointId": "[resourceId('Microsoft.Insights/dataCollectionEndpoints', variables('DCEName'))]",
    "streamDeclarations": { "Custom-MyTable_CL": { "columns": [ /* same columns */ ] } },
    "destinations": { "logAnalytics": [{ "workspaceResourceId": "[resourceId('Microsoft.OperationalInsights/workspaces', parameters('WorkspaceName'))]", "name": "LAWorkspace" }] },
    "dataFlows": [{ "streams": ["Custom-MyTable_CL"], "destinations": ["LAWorkspace"], "transformKql": "source", "outputStream": "Custom-MyTable_CL" }]
  }
}
```

### Bake DCE ingestion URI at deploy time (ARM reference())

```json
"DCEIngestionUri": {
  "type": "String",
  "defaultValue": "[concat(reference(resourceId('Microsoft.Insights/dataCollectionEndpoints', variables('DCEName'))).logsIngestion.endpoint, '/dataCollectionRules/', reference(resourceId('Microsoft.Insights/dataCollectionRules', variables('DCRName'))).immutableId, '/streams/Custom-MyTable_CL?api-version=2023-01-01')]"
}
```

### Log Ingestion API — use built-in MSI auth (NOT IMDS token)

**Always** use `authentication.type: ManagedServiceIdentity` directly. Never fetch the token manually from `169.254.169.254` — it is flaky and adds an extra network hop.

```json
"Ingest_Result": {
  "type": "Http",
  "inputs": {
    "method": "POST",
    "uri": "@parameters('DCEIngestionUri')",
    "headers": { "Content-Type": "application/json" },
    "body": "@variables('BatchArray')",
    "authentication": { "type": "ManagedServiceIdentity", "audience": "https://monitor.azure.com/" },
    "retryPolicy": { "type": "exponential", "count": 3, "interval": "PT10S", "minimumInterval": "PT10S", "maximumInterval": "PT1H" }
  }
}
```

### RBAC — Monitoring Metrics Publisher on DCR

Without this role the DCE POST returns **403**. Add as ARM resource:

```json
"variables": {
  "MonitoringMetricsPublisherRoleId": "3913510d-42f4-4e42-8a64-420c390055eb",
  "RoleAssignmentName": "[guid(resourceId('Microsoft.Insights/dataCollectionRules', variables('DCRName')), resourceId('Microsoft.Logic/workflows', parameters('PlaybookName')), '3913510d-42f4-4e42-8a64-420c390055eb')]"
}

{
  "type": "Microsoft.Authorization/roleAssignments",
  "apiVersion": "2022-04-01",
  "name": "[variables('RoleAssignmentName')]",
  "scope": "[resourceId('Microsoft.Insights/dataCollectionRules', variables('DCRName'))]",
  "dependsOn": [
    "[resourceId('Microsoft.Insights/dataCollectionRules', variables('DCRName'))]",
    "[resourceId('Microsoft.Logic/workflows', parameters('PlaybookName'))]"
  ],
  "properties": {
    "roleDefinitionId": "[subscriptionResourceId('Microsoft.Authorization/roleDefinitions', variables('MonitoringMetricsPublisherRoleId'))]",
    "principalId": "[reference(resourceId('Microsoft.Logic/workflows', parameters('PlaybookName')), '2017-07-01', 'Full').identity.principalId]",
    "principalType": "ServicePrincipal"
  }
}
```

> RBAC propagation takes 1–3 minutes after deploy — a 403 immediately after deploy is normal; wait and retry.

### ARM object keys cannot be dynamic expressions

`streamDeclarations` keys must be string literals. Use fixed stream name as key:
```json
"streamDeclarations": { "Custom-MyTable_CL": { "columns": [...] } },
"dataFlows": [{ "streams": ["Custom-MyTable_CL"], "outputStream": "[concat('Custom-', parameters('TableName'))]" }]
```

### DCR transformKql rules

**Column name limit — 60 characters max.** Any output column name longer than 60 chars causes `InvalidTransformQuery` at deploy time (error cites `Invalid output property '<name>' at index N. Must be non-null with length between 0 and 60`). Shorten long nested names with abbreviations (e.g. `contributing_factors` → `cf`, matching `attributes_gti_cf_safebrowsing_verdict` in `GTIURLScanEnrichment`).
- **Before finalizing any DCR transformKql/table schema, mechanically check every output column name's length** — don't eyeball it. A prefix like `attributes_gti_assessment_contributing_factors_` is 49 chars on its own; any child field name appended to it (even short ones like `_legitimate_software`) blows past 60. This bit both `GTIFileScanEnrichment` and `GTIFileScanBlobEnrichment` on first pass — apply the same `_cf_` abbreviation used in the URL-scan table any time `contributing_factors` (or another long nested key) is being flattened.

**Bracket notation required for all dynamic property access.** The DCR KQL engine does not support dot notation (`json_obj.fieldname`) on dynamic columns created via `parse_json()`. Always use bracket notation:
```kql
// ❌ fails with "no viable alternative at input '.fieldname'"
tostring(json_attributes.title)

// ✓ correct
tostring(json_attributes['title'])
tostring(parse_json(attributes)['title'])
```

**Avoid intermediate extended columns where possible.** If the total number of `extend` items (counted cumulatively across all pipe stages) is large, prefer fully inline `parse_json()` calls to avoid hitting DCR extend limits:
```kql
// ✓ inline — no intermediate variable needed
| extend attributes_url = tostring(parse_json(attributes)['url']),
         attributes_title = tostring(parse_json(attributes)['title'])
```

**Reserved/special field names need bracket notation.** Field names that coincide with KQL keywords (`title`, `type`, `sha256`, etc.) always require bracket notation in `parse_json()` access.

**`project-away` can only reference columns that actually exist in the query at that point — not the table schema.** Deploy-time error: `SemanticError:0x00000006 ... Undefined symbol: <column> (Code: InvalidTransformQuery, Target: properties.dataFlows[0])`. This happens when the workspace table schema declares an intermediate dynamic column (e.g. `attributes_gti_assessment`, `attributes_threat_severity`) that you intend to drop from the final output, but the `transformKql` never actually creates a column under that exact name — it only created a `json_`-prefixed temp var (`json_attributes_gti_assessment`) and flattened leaf fields (`attributes_gti_assessment_verdict_value`). Adding the un-created name to `project-away` fails because KQL resolves `project-away` targets against the live query schema, not your target table's schema.
- **Fix:** only put a name in `project-away` if an earlier `extend`/`parse_json` in the *same query* actually produced a column with that exact name. If the table schema still lists the never-populated column, that's fine — Log Ingestion API leaves undeclared/unproduced table columns as `null`; it does not require every table column to be written by every transform.
- **Before adding anything to `project-away`,** grep the query's own `extend` chain for that literal name — don't assume a name in the target schema implies it was created mid-query.

**Rename a raw `type` (or other reserved-word) column in the OUTPUT table schema — keep it as-is in the input stream.** When the raw API object being ingested has a top-level `type` field (e.g. GTI/VirusTotal's `data.type`), don't carry it into the custom table under that name — `type` is a soft-reserved/ambiguous column name in Log Analytics tooling and collides with KQL's own `type` semantics in some contexts. The fix, consistently applied across the GTI playbooks:
- **DCR `streamDeclarations` (input)** — keep the column named `type`, matching the literal field name the ingested JSON sends. Don't rename here; this must match the payload.
- **`transformKql`** — add an `extend` mapping it to a domain-specific name: `<Entity>Type = tostring(type)` (e.g. `UrlType` for the URL-scan table, `FileType` for the file-scan table), then add the raw `type` to the final `project-away` list so it doesn't also appear under its original name in the output.
- **Workspace table schema (output)** — declare the renamed column (`UrlType`, `FileType`, etc.), never `type`.

```json
// streamDeclarations — raw input shape, unchanged
{ "name": "type", "type": "string" }
```
```kql
// transformKql
| extend TimeGenerated = now(), FileType = tostring(type), ...
| project-away ..., type
```
```json
// workspace table schema — renamed output column
{ "name": "FileType", "type": "string" }
```
Apply the same pattern any time a new GTI table ingests a raw API object whose top-level field names collide with a KQL/table-tooling keyword — check `id`, `type`, `name`, and similar generic keys first.

### Single dict response → wrap with createArray() for DCE

DCE requires an array body. If the API returns a single object `{}`, wrap it: `"@createArray(body('Call_API')['data'])"`.

---

## Logic App variable rules

### InitializeVariable must be top-level — never inside ForEach, Until, or Condition

Logic Apps engine rejects `InitializeVariable` anywhere except the root `actions` object. Fix: move all `InitializeVariable` actions above any loop or scope; use `SetVariable` inside loops/scopes to update them.

### No `variables` block in workflow definition

Logic App `properties.definition` does NOT support a `"variables": {}` block. Use `InitializeVariable` actions instead.

---

## Session Learnings (GTI URL Scan Playbook Suite — 2026-07)

### Terminate is forbidden inside Foreach loops

`Terminate` actions cause `InvalidWorkflowRunAction` if placed anywhere inside a `Foreach` loop, even when nested inside a `Scope` that is itself inside the `Foreach`. The restriction applies at ANY nesting depth beneath a Foreach.

**Fix:** Replace every `Terminate` inside a Foreach with `SetVariable HasError = true` + `AppendToStringVariable ErrorMessage`. After the Foreach, use `Check_For_Error → Terminate_On_Error` at the root level (where Terminate IS valid). A `Catch_Scope` at the Foreach action level handles unexpected scope failures.

### Get_Incident via azuresentinel connector — correct operation

The `azuresentinel` managed connector's **Get Incident** operation uses:
```json
{
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post",
    "body": { "incidentArmId": "@triggerBody()?['incidentArmId']" },
    "path": "/Incidents"
  }
}
```
- `method: post`, `path: /Incidents` — NOT `GET /Cases/...` or `GET /Incidents/subscriptions/...`
- `GET /Cases/@{encodeURIComponent(...)}` causes "Operation Id cannot be determined from definition and swagger"
- `GET /Incidents/subscriptions/.../incidents/...` also fails — same swagger mismatch error
- Alternative: use an `Http` action calling `https://management.azure.com{armId}?api-version=2023-02-01` with MSI auth to bypass the connector entirely

### Add comment to incident — correct path and body

```json
{
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['azuresentinel']['connectionId']" } },
    "method": "post",
    "body": {
      "incidentArmId": "@triggerBody()?['incidentArmId']",
      "message": "<p class=\"editor-paragraph\">...</p>"
    },
    "path": "/Incidents/Comment"
  }
}
```
- Wrap message in `<p class="editor-paragraph">` (Censys/GTI reference pattern)
- `path: /Incidents/Comment` — not `/Incidents/{id}/comments`

### Entity trigger path for URL entities

```json
"path": "/entity/@{encodeURIComponent('UrlEntity')}"
```
- GTI solution uses `'UrlEntity'` (not `'URL'`, not `'Url'`, not `'/entities/url'`)
- IP entities use `'IP'`, account entities use `'Account'`, host entities use `'Host'`
- `callback_url` uses `@{listCallbackUrl()}` (not `@listCallbackUrl()`) — keep braces

### Sub-playbook (Workflow) call pattern with secureData

```json
{
  "type": "Workflow",
  "inputs": {
    "host": {
      "triggerName": "manual",
      "workflow": {
        "id": "[concat('/subscriptions/', subscription().subscriptionId, '/resourceGroups/', resourceGroup().name, '/providers/Microsoft.Logic/workflows/', parameters('GTIAddCommentPlaybookName'))]"
      }
    },
    "body": { ... }
  },
  "runtimeConfiguration": { "secureData": { "properties": ["inputs", "outputs"] } }
}
```
- Caller passes sensitive data (API responses, secrets) → always add `secureData`
- Sub-playbook MUST have HTTP `Request` trigger + `Response` action
- Sub-playbook trigger schema should declare required fields with correct types

### Passing raw API response to sub-playbook instead of pre-formatting

Pass `body('Get_URL_Report')` as `scanResponse` (object) to the comment sub-playbook. Format HTML inside the sub-playbook using a `Compose` action. Benefits:
- Caller stays clean — no long pre-formatted HTML strings
- Comment format can be updated in one place (sub-playbook)
- Compose output used in Add_Comment: `@{outputs('Compose_Comment')}`

### Dark-mode compatible HTML tables for incident comments

Avoid subtle tints (`#FAFAFA`, `#E3F2FD`) — they blend into dark portal backgrounds and become unreadable. Use:
- Data rows: explicit `background-color:#ffffff` / `#f2f2f2` with `color:#1a1a1a`
- Section headers: dark solid bg (`#37474F`) with `color:#ffffff`
- Row separators: `border-bottom:1px solid #dddddd`
- Outer table: `border:1px solid #cccccc`
- This makes the table a self-contained card regardless of portal theme

### context_attributes path in GTI URL scan response

`context_attributes` is at `data.context_attributes`, NOT `data.attributes.context_attributes`:
```
scanResponse.data.context_attributes.shared_with_me  ✓
scanResponse.data.context_attributes.role            ✓
scanResponse.data.attributes.context_attributes...   ✗ (wrong — does not exist)
```

### Trailing comma in releaseNotes array causes ARM parse failure

ARM templates are strict JSON — no trailing commas. Error message: "Value expected at position N". Common location: last item in `releaseNotes`, `notes`, `tags` arrays.

### DCE/DCR naming collision prevention

If two playbooks in the same resource group share identical `uniqueString()` inputs (e.g. same PlaybookName), their DCE/DCR names clash on re-deploy. Use a discriminator prefix: `GTI-DCE-Entity-` vs `GTI-DCE-` to avoid conflicts between incident and entity enrichment playbooks.

### azureblob `Get_Blob_Content` needs the `/v2/datasets/...` route for a dynamic storage account

Error: `Operation details error — Unable to initialize operation details for swagger based operation - Get_Blob_Content. Error details - Operation Id cannot be determined from definition and swagger.`

Cause: the **V1** `azureblob` swagger operations (`/datasets/{datasetName}/files/...`) only resolve `datasetName` as the literal `default` — they don't support a dynamic/expression value there. If a `storageAccountName` (or similar) taken from `triggerBody()` is substituted into that V1 path's `datasetName` segment, Logic Apps can't match the operation against the swagger and throws the error above.

**Fix: use the V2 operation set instead — its route is `/v2/datasets/{datasetName}/...` and DOES support a dynamic `datasetName`.** This is confirmed in published Microsoft Sentinel solutions (`Solutions/Intel471/Playbooks/Intel471-ImportMalwareIntelligenceToSentinel`, `...ToGraphSecurity`), which read blob content from a *parameterized* storage account this way:
```json
"path": "/v2/datasets/@{encodeURIComponent(encodeURIComponent(parameters('StorageAccountName')))}/files/@{encodeURIComponent(encodeURIComponent(<blob path>))}/content"
```
`datasetName` in the V2 route is just which account/dataset to target for that call, and it resolves correctly as a live expression, unlike V1.

**Practical picks confirmed working across both playbook shapes:**
- **HTTP/Request-triggered playbook** (workbook posts `storageAccountName`/`containerName`/`blobPath`): `datasetName = triggerBody()?['storageAccountName']`, id = `concat('/', containerName, '/', blobPath)`.
- **Blob-triggered playbook** (`When_a_blob_is_added_or_modified`): `datasetName = parameters('StorageAccountName')` (add it as a workflow parameter defaulted from the ARM template parameter — the trigger doesn't emit the account name itself), id = `triggerBody()?['Path']` (already starts with `/`, not `['Id']`).

**Don't rewrite `Get_Blob_Content` as a raw `Http` + MSI action to work around this** — that's a bigger, unnecessary redesign (it also means re-implementing binary content handling / blob-name encoding by hand) when the V2 route on the existing `ApiConnection` action solves it directly.

**Trigger itself stays on the V1/legacy route.** `When_a_blob_is_added_or_modified` (`/datasets/default/triggers/batch/onupdatedfile`) is unaffected by this — only content/file-manipulation *actions* (`Get_Blob_Content`, `Create_blob`, etc.) need the `/v2/` route when the account is dynamic.

### azureblob connector DOES support Managed Identity auth — no portal OAuth sign-in required

The Azure Portal's connector picker offers a **"Logic App Managed Identity"** authentication type when creating an `azureblob` connection (alongside the older interactive-sign-in / access-key options) — confirmed by inspecting a manually-created connection's deployed JSON. Bake this into the ARM template so the playbook needs zero manual portal authorization step, matching the `keyvault`/`azuresentinel` pattern:

```json
// Microsoft.Web/connections resource — plain, exactly like the OAuth version, NO parameterValueType
{
  "type": "Microsoft.Web/connections", "apiVersion": "2016-06-01",
  "name": "[variables('AzureBlobConnectionName')]", "location": "[resourceGroup().location]", "kind": "V1",
  "properties": {
    "displayName": "[variables('AzureBlobConnectionName')]",
    "customParameterValues": {},
    "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azureblob')]" }
  }
}
```
```json
// $connections wiring — the ONLY place the MSI override lives for this connector
"azureblob": {
  "connectionId": "[resourceId('Microsoft.Web/connections', variables('AzureBlobConnectionName'))]",
  "connectionName": "[variables('AzureBlobConnectionName')]",
  "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azureblob')]",
  "connectionProperties": { "authentication": { "type": "ManagedServiceIdentity" } }
}
```
**Do NOT add `"parameterValueType": "Alternative"` to the `azureblob` connection resource** — unlike `keyvault`/`azuresentinel`, `azureblob`'s API definition doesn't declare a parameter set under that mechanism, so ARM rejects it at deploy time:
```
The API connection '<name>' has invalid inputs. Parameter value type cannot be set to 'Alternative' because
managed identity is not supported in the API definition's connection parameters. (Code: InvalidApiConnectionAlternativeParameters)
```
Leaving the resource with just plain `customParameterValues: {}` isn't right either — deploying the Logic App then fails at a different layer:
```
The workflow connection parameter 'azureblob' is not valid. The API connection '<name>' is not configured
to support managed identity. (Code: WorkflowManagedIdentityConfigurationInvalid)
```
**The actual fix — `azureblob` uses a differently-named parameter set, `parameterValueSet` (not `parameterValueType`/`alternativeParameterValues`):**
```json
// Microsoft.Web/connections resource
"properties": {
  "displayName": "[variables('AzureBlobConnectionName')]",
  "customParameterValues": {},
  "parameterValueSet": { "name": "managedIdentityAuth", "values": {} },
  "api": { "id": "[concat('/subscriptions/', subscription().subscriptionId, '/providers/Microsoft.Web/locations/', resourceGroup().location, '/managedApis/azureblob')]" }
}
```
Confirmed by fetching a manually portal-created MSI `azureblob` connection's live properties (`az resource show --ids <connection resource id> --api-version 2016-06-01`) — its `properties.parameterValueSet` was exactly `{ "name": "managedIdentityAuth", "values": {} }`, not a `parameterValueType`/`alternativeParameterValues` pair. The `$connections` wiring still needs its own `connectionProperties.authentication.type: "ManagedServiceIdentity"` as usual — both the resource's `parameterValueSet` AND the wiring's `connectionProperties` are required together.

**Lesson: different connectors expose MSI through structurally different properties on the connection resource** — `keyvault`/`azuresentinel` via `parameterValueType: "Alternative"` (+ optional `alternativeParameterValues`), `azureblob` via `parameterValueSet: { name: "<connector-specific-name>", values: {} }`. Don't assume one connector's pattern generalizes to another; if an MSI-auth deploy error mentions "alternative"/"parameter value type"/"managed identity is not supported", the fastest way to get the exact required shape is to have the user create one connection of that type via the Azure Portal with the MSI option, then fetch it directly with `az resource show --ids <connection-id> --api-version 2016-06-01` and mirror its `properties` verbatim — don't keep guessing property names.

**This changes the RBAC story back to what "Storage Blob Data Reader" prerequisite text implies:** since the connection now authenticates as the Logic App's managed identity, that RBAC grant is real and required (not vestigial) — state it in both `prerequisites` and `postDeployment`, and drop any "authorize the connection in the portal" instruction since there's nothing to authorize interactively anymore. Applies to both the content-fetch `ApiConnection` action and, in a blob-triggered playbook, the `When_a_blob_is_added_or_modified` trigger sharing the same connection.

### Check blob size via "Get blob metadata (V2)", not by measuring downloaded content

Don't compute file size with `length(body('Get_Blob_Content'))` in an HTTP/Request-triggered playbook that has to look the blob up by path — that pattern only reveals the size *after* the full content is already downloaded, and reads oddly since the size is available for free without touching content. Add a lightweight metadata call first (same V2 route as content, minus `/content`) and branch on its `Size` field:
```json
"Get_Blob_Metadata": {
  "type": "ApiConnection",
  "inputs": {
    "host": { "connection": { "name": "@parameters('$connections')['azureblob']['connectionId']" } },
    "method": "get",
    "path": "/v2/datasets/@{encodeURIComponent(encodeURIComponent(<storageAccountName>))}/files/@{encodeURIComponent(encodeURIComponent(<blob id/path>))}"
  }
}
```
```
// large/small file branch
"@greater(body('Get_Blob_Metadata')?['Size'], 33554432)"
```
Chain it before `Get_Blob_Content` (`runAfter: { "Get_Blob_Metadata": ["Succeeded"] }`) — content still needs downloading either way for the upload step, but the size decision no longer depends on it.

**Skip this for a blob-*triggered* playbook** (`When_a_blob_is_added_or_modified`) — its trigger payload already includes `Size` natively (`triggerBody()?['Size']`), so a separate metadata call would be redundant there.
